/********************************************************************

    Desktop Sidebar - http://www.desktopsidebar.com

    This is definition of Desktop Sidebar C++ API.

    Desktop Sidebar is able to load plugins which implement interface IPlugin. 
    When plugin is loaded it receives pointer to ISidebar interface and all 
    functionality exposed by Sidebar to plugins is accessibly by this interface. 
    
    For convince of C++ users we provide wrappers for all IDispatch interfaces 
    in order to avoid dealing with BSTR and all similar COM details. 
    Plugin�s developers should be able to use C++ types like std::string 
    
    Please send comments and requests to: damian@desktopsidebar.com

********************************************************************/
#ifndef INC_DSIDEBAR_H
#define INC_DSIDEBAR_H

#include "dsidebaridl.h"

#ifndef INITGUID
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <gdiplus.h>
#include <commctrl.h>
#include <assert.h>

namespace ds {

class CTranslator;
class CPanelParent;
class CSkinElement;
class CSkinManager;
class CAlertManager;
class CUpdateUI;
class CCommandManager;
class CGlobalSettings;
class CXmlNode;
class CXmlBuilder;
class CPanelConfig;
class CControl;
class CTextOutput;
class CTextOutputParent;
class CListRow;
class CListOutput;
class CListOutputParent;
class CMarqueeOutput;
class CMarqueeOutputParent;
class CSkinButton;
class CSkinSlider;
class CSkinProgressBar;
class CBarChart;
class CBarChartParent;
class CDetailsWnd;
class CDetailsWndParent;
class CTextDetailsWnd;
class CLinkDetailsWnd;
class CHTMLDetailsWnd;
class CWebBrowserDetailsWnd;
class CControlFactory;
class CSidebar;

template <class T> 
class CPtrHolder {
public:
    
    CComPtr<T> m_ptr;

    CPtrHolder(T* ptr)
        :m_ptr(ptr){}

    void Release()
    {
        m_ptr.Release();
    }
    operator T*() const
    {
        return m_ptr;
    }
    bool operator!() const
    {
        return m_ptr==NULL;
    }
};

/*
This interface allows plugins to use internationalization features of Desktop Sidebar. 
Plugin can store all text messages in external xml files separately for each language 
and use methods of this interface to access to these strings.
*/
class CTranslator : public CPtrHolder<ITranslator> {
public:

    CTranslator(CComPtr<ITranslator> translator);

    std::string TranslateCommand(const std::string& text) const;
    void TranslateMenu(HMENU hMenu) const;
    void TranslateDialog(HWND hDlg, const std::string& name) const;
    std::string GetDialogCaption(const std::string& name) const;

    std::string date2string(const SYSTEMTIME& time, const std::string& format) const;
    std::string date2string(const SYSTEMTIME& time, DWORD flags) const;

    std::string msg(int id) const;	
    std::string msg(const char* id) const;	
    std::string msg(const std::string& id) const;	
};

class CMsgBuilder {
public:

    CMsgBuilder(const std::string& text);
    
    void push_back(const std::string& param);
    std::string str() const;

private:
    std::string m_text;
    std::vector<std::string> m_params;
};

template <class T> 
CMsgBuilder& operator<<(CMsgBuilder& stream, T param);

/*
This interface allows plugins to use skin subsystem of Desktop Sidebar. 
Appearance of panel�s elements should be define in xml skin file and plugin 
should use ISkinElement to paint items. 

Interface IGraphics is used to pass handle of display device context (HDC) to 
Drawing code in implementation of ISkinElement
*/

class CGraphics : public CPtrHolder<IGraphics> {
public:

    CGraphics(CComPtr<IGraphics> parent);

    void Takeover(HDC hdc);
    Gdiplus::Graphics& Get() const;
};

class CPanelParent : public CPtrHolder<IPanelParent> {
public:

    CPanelParent();
    CPanelParent(CComPtr<IPanelParent> parent);

    void ActivatePanel(int panelCookie);
    void SetCaption(int panelCookie, const std::string& caption);
    void DrawBackground(CGraphics graphics, int panelCookie);
    void DrawBackground(CGraphics graphics, int panelCookie, const RECT& rc);
    void DrawControlBackground(CGraphics graphics, int panelCookie, HWND control);
    void ArrangePanels();
    void InvalidatePanel(HWND hwnd, const RECT* rc, BOOL bErase);
    
};


/*
This interface allows panel to display graphical elements defined in skin file
*/
class CSkinElement : public CPtrHolder<ISkinElement> {
public:

    CSkinElement(CComPtr<ISkinElement> ptr);

    void DrawText(
        CGraphics graphics, 
        const RECT& rect, 
        const std::string&  text,
        int* tabs=0,
        int tabsCount=0,
        bool rightToLeft=false);
    void DrawText(
        CGraphics graphics, 
        const RECT& rect, 
        const std::wstring&  text,
        int* tabs=0,
        int tabsCount=0,
        bool rightToLeft=false);
    void DrawMultilineText(
        CGraphics graphics, 
        const RECT& rect, 
        const std::string&  text,
        bool rightToLeft=false);
    void DrawMultilineText(
        CGraphics graphics, 
        const RECT& rect, 
        const std::wstring&  text,
        bool rightToLeft=false);

    void DrawRect(
        CGraphics graphics, 
        const RECT& rect, 
        const CPanelParent& parent=CPanelParent(0),
        int cookie=0);
    void Fill(
        CGraphics graphics, 
        const RECT& rect);
    void Fill(
        CGraphics graphics, 
        const RECT& skinRect, 
        const RECT& targetRect);
    void Outline(
        CGraphics graphics, 
        const RECT& rect);

    bool IsHollow() const;
    ETextAlign GetAlign() const;
    ETextVAlign GetVAlign() const;
    Gdiplus::Color GetOutlineColor() const;
    EOutlineStyle GetOutlineStyle() const;
    int GetOutlineWidth()  const;

    EFillStyle GetFillStyle() const;
    Gdiplus::Color GetFillColor() const;
    Gdiplus::Color GetFillColor2() const;
    int GetMetrics(const std::string&  metrics) const;
    SIZE GetSize(const std::string&  metrics) const;
    POINT GetPoint(const std::string&  metrics) const;
    RECT GetTextMargin() const;
    
    SIZE GetImageSize() const;
    std::string GetImagePath() const;	
    void GetImageMargins(int* left, int* top, int* right, int*  bottom) const;    
    RECT GetImageMargins() const;    
    RECT GetImageMarginsR() const;    
    
    std::wstring GetFontFamily() const;
    std::string GetFontFamilyA() const;
    int GetFontSize() const;
    EFontStyle GetFontStyle() const;
    LOGFONT GetLogFont() const;
    Gdiplus::Color GetTextColor() const;
    int GetFontHeight() const;
    SIZE GetTextSize(const std::string&  text) const;
    SIZE GetTextSize(const std::wstring&  text) const;
    int GetTextHeight(const std::string&  text, int width) const;
    int GetTextHeight(const std::wstring&  text, int width) const;

    bool IsDefined() const;
};


class CSkinElementCreate : public CPtrHolder<ISkinElementCreate> {
public:

    CSkinElementCreate(CComPtr<ISkinElementCreate> ptr);

    void SetOutlineStyle(EOutlineStyle outline);
    void SetOutlineColor(Gdiplus::Color color);
    void SetOutlineWidth(int width);
    
    void SetFillStyle(EFillStyle fill);
    void SetFillColor(Gdiplus::Color color);
    void SetFillColor2(Gdiplus::Color color);
    void SetImagePath(const std::string& path);    
    void SetImagePath(const std::wstring& path);    
    void SetImagePathA(const std::string& path);    
    void SetImageMargins(int left, int top, int right, int bottom);    
    void SetImageMargins(const RECT& margins);    
    void SetImageMarginsR(const RECT& margins);    
    
    void SetFontFamily(const std::string& name );
    void SetFontFamily(const std::wstring& name );
    void SetFontFamilyA(const std::string& name );
    void SetFontFamilyW(const std::wstring& name );
    void SetFontSize(int size );
    void SetFontStyle(EFontStyle style);
    void SetTextColor(Gdiplus::Color color);
    void SetAlign(ETextAlign align);
    void SetVAlign(enum ETextVAlign align);
};

/*
This interface allows plugin to get skin element with given id from skin 
which is chosen by user in �Options� dialog.
*/
class CSkinManager : public CPtrHolder<ISkinManager> {
public:

    CSkinManager(CComPtr<ISkinManager> ptr);

    CSkinElement Get(int elementId, ESkinState state=Normal) const;
    CSkinElement GetCustom(const std::string& elementId, ESkinState state=Normal) const;
    int Name2Id(const std::string& elementId) const;
    CSkinElementCreate Create(int elementId, ESkinState state=Normal);
    int Insert(
        CSkinElementCreate normal, 
        CSkinElementCreate hover=CSkinElementCreate(0), 
        CSkinElementCreate pressed=CSkinElementCreate(0),
        CSkinElementCreate undocked=CSkinElementCreate(0));
};


/* 
Plugins are able to display small non-intrusive window, typically in right bottom corner 
of screen with notification about various events. Plugin should implement IAlert interface 
and then use IAlertManager to display window
*/ 
class CAlertManager : public CPtrHolder<IAlertManager> { 
public:

    CAlertManager(CComPtr<IAlertManager> ptr);

    void ShowAlert(HWND hwnd, IAlert* alert);
};

class CUpdateUI : public CPtrHolder<IUpdateUI> {
public:

    CUpdateUI(CComPtr<IUpdateUI> ptr);
    
    void Remove();
    void SetEnabled(bool enable);
    void SetChecked(bool checked);
};

/* 

Menus, toolbars and shortcuts can be defined in plugin xml configuration file and 
this interface allows to create menus and toolbars on base of these defintions 
*/ 
class CCommandManager : public CPtrHolder<ICommandManager> {
public:
    
    CCommandManager(CComPtr<ICommandManager> ptr);

    int RegisterCommandTarget(const std::string& name, ICommandTarget* pTarget);
    void UnregisterCommandTarget(int cookie);

    void AppendMenu(HMENU hMenu, const std::string& name);
    void UpdateMenu(ICommandTarget* pGroup, ICommandTarget* pPanel, HMENU hMenu);

    void SetupToolbar(HWND hwndToolbar, const std::string& name);
    void UpdateToolbar(ICommandTarget* pGroup, ICommandTarget* pPanel, HWND hwndToolbar);

    void DispatchCommand(ICommandTarget* pGroup, ICommandTarget* pPanel, int cmdId);
    void DispatchCommandUpdate(
        bool* enabled, 
        bool* checked, 
        ICommandTarget* pGroup, 
        ICommandTarget* pPanel, 
        int cmdId);

    int GetCommandId(const std::string& cmdName) const;
    int GetCommandImage(const std::string& cmdName) const;
    std::string GetCommandName(int id) const;
    std::string GetCommandProc(const std::string& cmdName) const;
    
    HBITMAP GetImages() const;
    int GetToolbarOffset(const std::string& toolbarId) const;
};

/* 
Plugins can receive notification about commands selected by user in menus,
toolbars or with keyboard shortcuts. To receive such notification plugin have to 
implement ICommandTarget interface and then register this interface with ICommandManager 
*/ 
class CCommandTargetBase {
public:
    virtual bool onCommand(const std::string& name)=0;
    virtual bool onUpdateCommand(const std::string& name, CUpdateUI* pCmdUI)=0;
    virtual bool onPrivateCommand(int id);
    virtual bool onUpdatePrivateCommand(int id, CUpdateUI* pCmdUI);
    virtual bool getPrivateCommandImage(int id, int* image);
};

template <class T>
class CCommandTargetImplBase : public CCommandTargetBase {
public:
    typedef void (T::* command_handler_t)();
    typedef void (T::* command_update_t)(CUpdateUI* pUpdateUI) const;
    struct CEntry
    {
        command_handler_t m_handler;
        command_update_t m_update;

        CEntry(
            command_handler_t handler,
            command_update_t update) 
          : m_handler(handler),m_update(update)
        {
        }
    };
    typedef std::map<std::string,CEntry> commands_map_t;
    commands_map_t m_commands;
    T* p_this;

    CCommandTargetImplBase(T* pThis);

    void addCommand(const char * name, 
                    command_handler_t pHandler, 
                    command_update_t pUpdate=0);

    virtual bool onCommand(const std::string& name);
    virtual bool onUpdateCommand(const std::string& name, CUpdateUI* pCmdUI);
};

template <class T>
class CCommandTargetImpl :
    public CCommandTargetImplBase<T>,
    public IDispatchImpl<ICommandTarget, &IID_ICommandTarget, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    CCommandTargetImpl(T* pThis);

    STDMETHOD(OnCommand)(BSTR cmdName);
    STDMETHOD(OnUpdateCommand)(BSTR cmdName, IUpdateUI* pCmdUI);
    STDMETHOD(OnPrivateCommand)(int id);
    STDMETHOD(OnUpdatePrivateCommand)(int id, IUpdateUI* pCmdUI);
    STDMETHOD(GetPrivateCommandImage)(int id, int* image);
};

class CCommandTargetChain :
    public IDispatchImpl<ICommandTarget, &IID_ICommandTarget, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    virtual CCommandTargetBase* chain() const=0; 

    STDMETHOD(OnCommand)(BSTR cmdName);
    STDMETHOD(OnUpdateCommand)(BSTR cmdName, IUpdateUI* pCmdUI);
    STDMETHOD(OnPrivateCommand)(int id);
    STDMETHOD(OnUpdatePrivateCommand)(int id, IUpdateUI* pCmdUI);
    STDMETHOD(GetPrivateCommandImage)(int id, int* image);
};

/*
This interface allows plugin access to global settings of Desktop Sidebar. 
Most of these settings is configured by user in �Options� dialog
*/
class CGlobalSettings : public CPtrHolder<IGlobalSettings> {
public:
    
    CGlobalSettings(CComPtr<IGlobalSettings> ptr);

    int GetInt(EGlobalParam param) const;
    std::string GetString(EGlobalParam param) const;
    std::string GetCodedString(EGlobalParam param) const;


    void Set(EGlobalParam param, int val);
    void Set(EGlobalParam param, const std::string& str);
    void SetCodedString(EGlobalParam param, const std::string& str);
};

/*
Configuration of Desktop Sidebar is stored in xml configuration file.
IXmlNode interface allows plugin to access to this configuration data 
*/
class CXmlNode : public CPtrHolder<IXmlNode> {
public:    

    CXmlNode();
    CXmlNode(CComPtr<IXmlNode> ptr);

    std::string GetNameA() const;
    std::wstring GetNameW() const;
    std::string GetBodyA() const;
    std::wstring GetBodyW() const;
    bool GetAttribute(std::string* retVal, const std::string& name) const;
    bool GetAttribute(std::wstring* retVal, const std::string& name) const;
    std::string GetAttribute(const std::string& name,  const std::string& defValue="") const;
    std::wstring GetAttribute(const std::wstring& name,  const std::wstring& defValue=L"") const;
    std::string GetObligAttributeA(const std::string& name) const;
    std::wstring GetObligAttributeW(const std::string& name) const;
    CXmlNode GetNode(const std::string& path) const;
    
    class iterator : public std::iterator<std::forward_iterator_tag, CXmlNode>
    {
        CComPtr<IXmlNode> m_ptr;
        int m_current;
    public:

        iterator();
        iterator(CComPtr<IXmlNode> ptr);
        iterator(const iterator& other);
        iterator& operator=(const iterator& other);

        CXmlNode operator*() const;

        iterator & operator++();
        iterator operator++(int);

        bool operator==(const iterator & it) const;
        bool operator!=(const iterator & it) const;

        void next();
    };

    iterator begin() const;
    iterator end() const;

    class attribute_iterator : public std::iterator<std::forward_iterator_tag, std::string>
    {
        CComPtr<IXmlNode> m_ptr;
        int m_current;
    public:

        attribute_iterator();
        attribute_iterator(CComPtr<IXmlNode> ptr);
        attribute_iterator(const attribute_iterator& other);
        attribute_iterator& operator=(const attribute_iterator& other);

        std::string operator*() const;

        attribute_iterator& operator++();
        attribute_iterator operator++(int);

        bool operator==(const attribute_iterator & it) const;
        bool operator!=(const attribute_iterator & it) const;

        void next();
    };

    attribute_iterator beginAttributes() const;
    attribute_iterator endAttributes() const;

};

/*
This interface allows plugin to store own data in desktop sidebar 
Configuration file 
*/
class CXmlBuilder : public CPtrHolder<IXmlBuilder> {
public:    

    CXmlBuilder(CComPtr<IXmlBuilder> ptr);

    template <class T>
    void AddAttribute(const std::string& name, const T& value);

    template <class T>
    void AddNDAttribute(const std::string& name, const T& value, const T& defValue=T());
    
    CXmlBuilder AddChild(const std::string& tag);
};

class CControl: public CPtrHolder<IControl> {
public:

    CControl();
    CControl(CComPtr<IUnknown> ptr);
    CControl(CComPtr<IControl> ptr);

    template<typename Control>
    CControl(CComPtr<Control> ptr)
        :CPtrHolder<IControl>(0)
    {
        CComQIPtr<IControl,&IID_IControl> ctrl(ptr);
        m_ptr = ctrl;
        assert(m_ptr != 0);
    }

    void SetDisplay(const bool display);
    bool GetDisplay()const;

    void SetVisible(const bool visible);
    bool GetVisible()const;
};


/*
Desktop Sidebar provides set of skinable controls which can be used by panels
to create their user interface. 
*/

/*
This is callback interface of ITextOutput control. Control notifies panel through 
this interface about various events connected with control
*/

class CTextOutput;
class CTextOutputParent : 
    public IDispatchImpl<ITextOutputParent, &IID_ITextOutputParent, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnDrawBackground)(ITextOutput* textOutput, IGraphics* graphics);
    STDMETHOD(OnClick)(ITextOutput* textOutput, VARIANT_BOOL /*dbclk*/);
    STDMETHOD(OnMouseHover)(ITextOutput* textOutput);
    STDMETHOD(OnMouseLeave)(ITextOutput* textOutput);
    STDMETHOD(OnShowDetails)(ITextOutput* textOutput);

    virtual void OnDrawBackground(CTextOutput& output, CGraphics graphics)=0;
    virtual void OnClick(CTextOutput& /*output*/, bool /*dbclk*/){}
    virtual void OnMouseHover(CTextOutput& /*output*/){}
    virtual void OnMouseLeave(CTextOutput& /*output*/){}
    virtual void OnShowDetails(CTextOutput& /*output*/){}
};

/*
This is equivalent of STATIC from Win32 API
*/

class CTextOutput : public CPtrHolder<ITextOutput> {
public:

    CTextOutput();
    CTextOutput(CComPtr<ITextOutput> ptr);
    
    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        ITextOutputParent* parent,
        bool supportClick,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void SetText(const std::string& text);
    void SetText(const std::wstring& text);
    void SetSkinElement(int skinElement);
    int GetSkinElement() const;
    int GetFitHeight() const;
    int GetFitHeightEx(int width) const;
    void TakeoverDetails(CDetailsWnd details);
    void SetWrap(bool wrap);
    bool GetWrap() const;
    std::string GetText() const;
    void SetParent(ITextOutputParent* parent);
    void SetIdentifier(const int identifier);
    void SetSupportClick(const bool supportClick);
    void SetRightToLeft(const bool rightToLeft);
};

class CListRow : public CPtrHolder<IListRow> {
public:

    CListRow(CComPtr<IListRow> ptr);

    void SetImageSkin(int skinElement);
    void SetTextSkin(int skinElement);
    void SetBackgroundSkin(int skinElement);
    void SetText(const std::string& text);
    void SetText(const std::wstring& text);
    std::wstring GetText() const;
    void SetDetailsText(const std::string& text);
    void SetDetailsText(const std::wstring& text);
    std::wstring GetDetailsText() const;

    int GetUserData(int index) const;
    void SetUserData(int index, int value);
};

class CListOutput;
class CListOutputParent : 
    public IDispatchImpl<IListOutputParent, &IID_IListOutputParent, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnDrawBackground)(IListOutput*  list, IGraphics* graphics);
    STDMETHOD(OnClick)(IListOutput*  list, IListRow* row, VARIANT_BOOL dbclk);
    STDMETHOD(OnHover)(IListOutput*  list, IListRow* row);
    STDMETHOD(OnLeave)(IListOutput*  list, IListRow* row);
    STDMETHOD(OnShowDetails)(IListOutput*  list, IListRow* row);
    STDMETHOD(OnScrolled)(IListOutput*  list);

    virtual void OnDrawBackground(CListOutput& list, CGraphics graphics)=0;
    virtual void OnClick(CListOutput& /*list*/, CListRow* /*row*/, bool /*dbclk*/){}
    virtual void OnHover(CListOutput& /*list*/, CListRow* /*row*/){}
    virtual void OnLeave(CListOutput& /*list*/, CListRow* /*row*/){}
    virtual void OnShowDetails(CListOutput& /*list*/, CListRow* /*row*/){}
    virtual void OnScrolled(CListOutput& /*list*/){}
};

/*
This is equivalent of LISTBOX from Win32 API
*/

class CListOutput: public CPtrHolder<IListOutput> {
public:

    CListOutput();
    CListOutput(CComPtr<IListOutput> ptr);
    
    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        IListOutputParent* parent,
        bool supportAutoScrolling,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd() const;
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void Invalidate();
    void SetSkinElement(int skinElement);
    int GetSkinElement() const;
    void ShowRowSeparator(bool showSeparator);
    void WrapText(bool wrap);
    void SetRightToLeft(bool rightToLeft);
    int GetFitHeight(int width) const;

    CListRow AddRow();
    CListRow InsertRow(int insertBefore);
    CListRow GetRow(size_t index) const;
    int Size() const;
    int GetFirstVisible() const;
    int GetLastVisible() const;
    int GetHoverRow() const;
    void Clear();
    
    RECT GetRowRect(CListRow row) const;
    CListRow GetRowFromPoint(const POINT& pt) const;

    void ScrollToPrev();
    void ScrollToRow(size_t row);
    void ScrollToNext();

    void SetIndent(int image, int text);
    void SetTabs(int* tabs, int tabsCount);
    void SetTab(int index, int values);

    void TakeoverDetails(CDetailsWnd details, CListRow row);

    void SetIdentifier(const int identifier);
    void SetAutoScrolling(const bool supportAutoScrolling);
    void SetMaxFitRows(const int maxFitRows);

    void SetParent(IListOutputParent* parent);
};

class CMarqueeOutput;
class CMarqueeOutputParent : 
    public IDispatchImpl<IMarqueeOutputParent, &IID_IMarqueeOutputParent, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnDrawBackground)(IMarqueeOutput* marquee, IGraphics* graphics);
    STDMETHOD(OnClick)(IMarqueeOutput* marquee, VARIANT_BOOL dbclk);
    STDMETHOD(OnMouseHover)(IMarqueeOutput* marquee);
    STDMETHOD(OnMouseLeave)(IMarqueeOutput* marquee);
    STDMETHOD(OnShowDetails)(IMarqueeOutput* marquee);

    virtual void OnDrawBackground(CMarqueeOutput& output, CGraphics graphics)=0;
    virtual void OnClick(CMarqueeOutput& /*output*/, bool /*dbclk*/){}
    virtual void OnMouseHover(CMarqueeOutput& /*output*/){}
    virtual void OnMouseLeave(CMarqueeOutput& /*output*/){}
    virtual void OnShowDetails(CMarqueeOutput& /*output*/){}
};

class CMarqueeOutput : public CPtrHolder<IMarqueeOutput> {
public:

    CMarqueeOutput();
    CMarqueeOutput(CComPtr<IMarqueeOutput> ptr);
    
    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        IMarqueeOutputParent* parent,
        bool supportClick,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void SetText(const std::string& text);
    void SetText(const std::wstring& text);
    void SetSkinElement(int skinElement);
    int GetSkinElement() const;
    int GetFitHeight() const;
    void SetSpeed(int frequency, int delta);
    void TakeoverDetails(CDetailsWnd details);

    void SetIdentifier(const int identifier);
    void SetSupportClick(const bool supportClick);

    void SetParent(IMarqueeOutputParent* parent);
};

class CSkinButton : public CPtrHolder<ISkinButton> {
public:

    CSkinButton();
    CSkinButton(CComPtr<ISkinButton> ptr);

    bool Init(
        CSkinManager skinManager, 
        ISkinButtonParent* parent,
        int normalSkin, 
        int checkedSkin, 
        int commandId);
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void SetNormalSkin(int skinElement);
    int GetNormalSkin() const;
    void SetCheckedSkin(int skinElement);
    int GetCheckedSkin() const;
    bool IsChecked() const;
    void SetCheck(bool check);
    int GetCommandId() const;
    SIZE GetSize() const;
    void SetStyle(const int style);
    void SetCommandId(const int commandId);

    void SetParent(ISkinButtonParent* parent);
};

class CSkinProgressBar : public CPtrHolder<ISkinProgressBar> {
public:

    CSkinProgressBar();
    CSkinProgressBar(CComPtr<ISkinProgressBar> ptr);
    
    bool Init(
        CSkinManager skinManager, 
        int skinElement,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void SetSkinElement(int skinElement);
    int GetSkinElement() const;
    void SetRange(const int rangeMin, const int rangeMax);
    void SetValue(int value);
    void SetIdentifier(const int identifier);
};

class CSkinSlider : public CPtrHolder<ISkinSlider> {
public:

    CSkinSlider();
    CSkinSlider(CComPtr<ISkinSlider> ptr);

    bool Init(
        CSkinManager skinManager, 
        ISkinSliderParent* parent,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect) const;
    void SetValue(int value);
    void SetRange(int iMin, int iMax);
    void SetIdentifier(const int identifier);
    void SetSkin(const int sliderSkin,const int sliderButtonSkin);
    int GetSliderSkin() const;
    int GetSliderButtonSkin() const;

    void SetParent(ISkinSliderParent* parent);
};

class CBarChart;
class CBarChartParent: 
    public IDispatchImpl<IBarChartParent, &IID_IBarChartParent, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnDrawBackground)(IBarChart* chart, IGraphics* graphics);
    STDMETHOD(OnClick)(IBarChart* chart, VARIANT_BOOL dbclk);
    STDMETHOD(OnMouseHover)(IBarChart* chart);
    STDMETHOD(OnMouseLeave)(IBarChart* chart);
    STDMETHOD(OnShowDetails)(IBarChart* chart);

    virtual void OnDrawBackground(CBarChart& chart, CGraphics graphics)=0;
    virtual void OnClick(CBarChart& /*chart*/, bool /*dbclk*/){}
    virtual void OnMouseHover(CBarChart& /*chart*/){}
    virtual void OnMouseLeave(CBarChart& /*chart*/){}
    virtual void OnShowDetails(CBarChart& /*chart*/){}
};

class CBarChart : public CPtrHolder<IBarChart> {
public:

    CBarChart();
    CBarChart(CComPtr<IBarChart> ptr);
    
    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        IBarChartParent* parent,
        const std::string& label,
        int id=-1);
    int GetId() const;
    
    bool Create(HWND hwndParent, bool visible=true);
    HWND GetHwnd();
    void Close();
    void MoveWindow(int x, int y, int width, int height);
    void ShowWindow(bool show);
    void GetControlRect(RECT* rect)const;
    void SetValue(int value);
    void SetType(int type);
    void SetValueD(double value);
    void SetRangeD(double min,double max);
    void SetLabel(BSTR label);
    void SetLabelA(const std::string& label);
    void GetFitSize(BSTR text, SIZE* sz) const;
    void SetTextPosition(int position);
    void SetChartSize(SIZE size);
    void SetValueType(int showValue, BSTR suffix);
    void SetTextColor(DWORD argb);
    void SetIdentifier(const int identifier);

    void SetSkin(
        const int barChartSkin,
        const int backgroundSkin,
        const int outlineSkin);
    int GetBarChartSkin() const;
    int GetBackgroundSkin() const;
    int GetOutlineSkin() const;

    void TakeoverDetails(CDetailsWnd details);

    void SetParent(IBarChartParent* parent);
};

class CImage : public CPtrHolder<IImage> {
public:

    CImage();
    CImage(CComPtr<IImage> ptr);

    void Init(
        CGlobalSettings settings, 
        CSkinManager skinManager);
    
    void MoveWindow(const int x, const int y, const int width, const int height);
    void GetControlRect(RECT* rect) const;
}; //CImage

class CHwndHolder : public CPtrHolder<IHwndHolder> {
public:

    CHwndHolder();
    CHwndHolder(CComPtr<IHwndHolder> ptr);

    void MoveWindow(const int x, const int y, const int width, const int height);
    void GetControlRect(RECT* rect) const;

    void SetEmpty();
    void SetWindow(HWND window);
}; //CImage

class CCanvas : public CPtrHolder<ICanvas> {
public:

    CCanvas();
    CCanvas(CComPtr<ICanvas> ptr);
    
    void Create(HWND hwndParent);
    void Reload();
    
    RECT GetWindowRect() const; 

    CControl GetControl(const std::string& idctrl);

    CBarChart GetBarChart(const std::string& idctrl);
    CSkinButton GetButton(const std::string& idctrl);
    CImage GetImage(const std::string& idctrl);
    CHwndHolder GetHwndHolder(const std::string& idctrl);
    CListOutput GetListOutput(const std::string& idctrl);
    CMarqueeOutput GetMarquee(const std::string& idctrl);
    CSkinProgressBar GetProgressBar(const std::string& idctrl);
    CSkinSlider GetSlider(const std::string& idctrl);
    CTextOutput GetTextOutput(const std::string& idctrl);
};


class CPanelWindow : public CPtrHolder<IPanelWindow> {
public:

    CPanelWindow();
    CPanelWindow(CComPtr<IPanelWindow> ptr);
    
    HWND GetHwnd() const;
    int GetFitHeight(const int width) const;
};

class CDetailsWnd;
class CDetailsWndParent: 
    public IDispatchImpl<IDetailsWndParent, &IID_IDetailsWndParent, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnCreateDetailsWnd)(IUnknown* details);
    STDMETHOD(OnCloseDetailsWnd)(IUnknown* details);

    virtual void OnCreateDetailsWnd(CDetailsWnd& /*details*/){}
    virtual void OnCloseDetailsWnd(CDetailsWnd& /*details*/){}
};

class CDetailsWndParent2: 
    public IDispatchImpl<IDetailsWndParent2, &IID_IDetailsWndParent2, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:

    STDMETHOD(OnCreateDetailsWnd)(IUnknown* details);
    STDMETHOD(OnCloseDetailsWnd)(IUnknown* details);
    STDMETHOD(OnDetailsButtonClicked)(IUnknown* details,UINT btn);

    virtual void OnCreateDetailsWnd(CDetailsWnd& /*details*/){}
    virtual void OnCloseDetailsWnd(CDetailsWnd& /*details*/){}
    virtual void OnDetailsButtonClicked(CDetailsWnd& /*details*/,UINT /*btn*/){}
};

/*
This is details window displayed when user rest mouse pointer 
over various parts of sidebar. It has balloon shape and it automatically 
hidden when user move mouse  
*/
class CDetailsWnd {
public:

    CComPtr<IDetailsWnd> m_ptr;

    CDetailsWnd();
    CDetailsWnd(CComPtr<IDetailsWnd> ptr);
    virtual ~CDetailsWnd();
    virtual void Release();
    virtual operator bool() const;
    virtual bool operator!() const;

    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        CPanelConfig panelConfig,
        IDetailsWndParent* parent, 
        const std::string& caption);
    
    bool Init(
        CGlobalSettings settings, 
        CSkinManager skinManager, 
        IDetailsWndParent* parent, 
        const std::string& caption);
    
    void RegisterParent(IDetailsWndParent* parent);

    bool Create(HWND hwndParent, const POINT& origin);
    bool Create(HWND hwndParent, const POINT& origin, SIZE size);
    bool Create(HWND hwndParent, const RECT& parentArea);
    bool Create(HWND hwndParent, const RECT& parentArea, SIZE size);
    bool Create(HWND hwndParent);
    bool Create(HWND hwndParent, SIZE size);
    HWND GetHwnd() const;
    SIZE GetSize() const;
    void SetSize(SIZE size, bool redraw);
    void SetCaption(const std::string& caption);
    RECT GetInteriorRect() const;
    Gdiplus::Color GetBkColor() const;
    void SetFixedSize(bool fixed);

    void Show();
    void Fade();
    void Hide();
    
    void PinWindow();
    void UnpinWindow();

    void SetInterior(HWND hwnd);
    HWND GetInterior() const;

    void SetUserParam(long param);
    long GetUserParam() const;
    void SetUserUnk(IUnknown* unk);
    void GetUserUnk(IUnknown** unk) const;

    void DrawBackground(CGraphics graphics, const RECT& rc);
};

class CTextDetailsWnd : public CDetailsWnd {
public:

    CComPtr<ITextDetailsWnd> m_specific ;

    CTextDetailsWnd(CComPtr<ITextDetailsWnd> ptr);

    virtual void Release();
    virtual operator bool() const;
    virtual bool operator!() const;

    void Set(const std::string& text);
    void Append(const std::string& text);
};

class CLinkDetailsWnd : public CDetailsWnd {
public:

    CComPtr<ILinkDetailsWnd> m_specific ;

    CLinkDetailsWnd(CComPtr<ILinkDetailsWnd> ptr);

    virtual void Release();
    virtual operator bool() const;
    virtual bool operator!() const;

    void Set(const std::string& text);
};

class CHTMLDetailsWnd : public CDetailsWnd {
public:

    CComPtr<IHTMLDetailsWnd> m_specific ;

    CHTMLDetailsWnd(CComPtr<IHTMLDetailsWnd> ptr);

    virtual void Release();
    virtual operator bool() const;
    virtual bool operator!() const;

    void Set(const std::wstring& body);
    void SetExternal(IDispatch* ext);
    void ShowImages(bool showImages);
};

class CWebBrowserDetailsWnd : public CDetailsWnd {
public:

    CComPtr<IWebBrowserDetailsWnd> m_specific ;

    virtual void Release();
    virtual operator bool() const;
    virtual bool operator!() const;

    CWebBrowserDetailsWnd();
    CWebBrowserDetailsWnd(CComPtr<IWebBrowserDetailsWnd> ptr);
    
    void Set(const std::string& url);
    void ShowImages(bool showImages);
};

/*
This interface allows panels to create various controls  
*/
class CControlFactory : public CPtrHolder<IControlFactory> {
public:

    CControlFactory(CComPtr<IControlFactory> ptr);

    CTextOutput CreateTextOutput();
    CListOutput CreateListOutput();
    CMarqueeOutput CreateMarqueeOutput();
    CSkinButton CreateSkinButton();
    CSkinProgressBar CreateSkinProgressBar();
    CSkinSlider CreateSkinSlider();
    CBarChart CreateBarChart();
    CDetailsWnd CreateDetailsWnd(const std::string& panel, bool click=false, DWORD style=DS_NONE);
    CTextDetailsWnd CreateTextDetailsWnd(const std::string& panel, bool click=false, DWORD style=DS_NONE);
    CLinkDetailsWnd CreateLinkDetailsWnd(const std::string& panel, bool click=false, DWORD style=DS_NONE);
    CHTMLDetailsWnd CreateHTMLDetailsWnd(const std::string& panel, bool click=false, DWORD style=DS_NONE);
    CWebBrowserDetailsWnd CreateWebBrowserDetailsWnd(const std::string& panel, bool click=false, DWORD style=DS_NONE);
    
    SIZE InteriorToDetailsSize(
        const SIZE& interior, 
        const std::string& caption) const;
    void HideAllDetails();
    bool IsDetailsDisplayed() const;

    HMENU CreatePopupMenu();
    void InsertMenuSeparator(int hMenu, int pos);
    void InsertMenuItem(int hMenu, int pos, const std::wstring& caption, int command);
};


/*
This is main interface exposed by Desktop Sidebar. It allows plugins to access 
others interfaces exposed by sidebar 
*/
class CSidebar : public CPtrHolder<ISidebar> {
public:

    CSidebar();
    CSidebar(CComPtr<ISidebar> ptr);

    CTranslator GetTranslator() const;
    CSkinManager GetSkinManager() const;
    CAlertManager GetAlertManager() const;
    CCommandManager GetCommandManager() const;
    CGlobalSettings GetGlobalSettings() const;
    CControlFactory GetControlFactory() const;
    CGraphics CreateGraphics(HDC hdc);
    
    int GetVersion(int* major, int* minor) const;
    std::string GetSettingsDir() const;
    std::string GetInstallDir() const;
    void SaveConfiguration();

    int GetPluginsCount() const;
    CComPtr<IPlugin> GetPlugin(int pluginCookie) const;
    CComPtr<IPlugin> GetPlugin(const std::string& pluginName) const;

    bool OpenXml(CXmlNode* node, const std::string& filePath, std::string* errorMsg) const;
    bool SaveXml(const CXmlBuilder& xml, const std::string& filePath, std::string* errorMsg) const;
    CXmlBuilder CreateXml(const std::string& rootTag) const;
    bool DownloadFile(const std::string& filePath, const std::string& url, bool reload, std::string* errorMsg) const;

    void Log(const std::string& text);

    bool RegisterPanel(
        const std::string& panelClass,
        const std::string& panelCaption,
        const std::string& panelDescription,
        HIMAGELIST imagelist,
        const std::string& panelIcon,
        const std::string& panelCategory,
        const std::string& categoryIcon,
        const std::string& panelFiles,
        const std::string& panelCanvas,
        int pluginCookie);
    bool RegisterPanel2(
        const std::string& panelClass,
        const std::string& panelCaption,
        const std::string& panelDescription,
        HIMAGELIST imagelist,
        const std::string& panelIcon,
        const std::string& panelCategory,
        const std::string& categoryIcon,
        const std::string& panelFiles,
        const std::string& panelCanvas,
        int panelFlags,
        int pluginCookie);

    bool RegisterCmdLineExtension(
        const std::string& identifier,
        const std::string& prefix,
        const std::string& caption,
        const std::string& category,
        const std::string& description,
        const CXmlNode& forms,
        int pluginCookie);
};

typedef HRESULT (STDAPICALLTYPE  *PLUGINENTRYPOINT)(IPlugin** plugin);

class CSidebarWindow : public CPtrHolder<ISidebarWindow> {
public:

    CSidebarWindow(CSidebar sidebar);

    HWND GetHwnd() const;
};




class CPanelConfig : public CPtrHolder<IPanelConfig>{
public:

    CPanelConfig();
    CPanelConfig(CComPtr<IPanelConfig> ptr);

    void Load(CXmlNode settings, bool panelSettings);
    void Save(CXmlBuilder settings, bool panelSettings) const;

    bool AutoFit() const;
    void SetAutoFit(bool autofit);

    SIZE GetDetailsSize()const;
    void SetDetailsSize(const SIZE& size);

    bool AutoStretch() const;
    void SetAutoStretch(bool autoexpand);

    bool IsExpanded() const;
    void Expand(bool expand);
    
    int GetHeight(int width) const;
    void SetHeight(int height);
    
    void ShowCaption(bool decorate);
    bool IsCaptionVisible() const;

    void SetCaption(const std::string& caption);
    std::string GetCaption() const;

    bool NeedUpdate();

    bool IsUndocked() const;
    bool SupportsOffScreen() const;

    CXmlNode GetConfigRoot() const;
    std::string GetConfigPath() const;

    void InitSetting(
        const std::string& name,
        CComVariant default_value);
    CComVariant GetSetting(
        const std::string& name);
    void SetSetting(
        const std::string& name,
        CComVariant value);

    void AddCustomValue(
        const std::string& name,
        const std::string& value);
    std::string GetCustomValues(
        const std::string& name);
    void ClearCustomValues(
        const std::string& name);

    void Copy(CPanelConfig config);
};


class CCmdLinePanel : public CPtrHolder<ICmdLinePanel> {
public:

    CCmdLinePanel(CComPtr<ICmdLinePanel> ptr);

    void Msg(const std::string& text);
    void Log(const std::string& text);
    void GetForm(const std::string& name, IForm** form);
    bool SendForm(IForm* form);
    bool ShellExecute(const std::string& strDoc, const std::string& param="");
    void DisplayText(const std::string& text, const std::string& caption="");
    void AppendText(const std::string& text);
    void DisplayHTML(const std::string& text, const std::string& caption="");
    void DisplayWebPage(const std::string& url, const std::string& caption="");
    void DisplayLink(const std::string& text, const std::string& caption="");
    void SetText(const std::string& text);
};

class CCmdLineSuggestion : public CPtrHolder<ICmdLineSuggestion> {
public:

    CCmdLineSuggestion(CComPtr<ICmdLineSuggestion> ptr);

    void Add(const std::string& caption, const std::string& cmdLine, bool select);
    int AddEx(const std::string& caption);
    void SetSelect(int index, bool select);
    void SetIcon(int index, HICON icon);
    void SetTooltip(int index, const std::string& text);
    void SetCommand(int index, const std::string& text);
    void SetExecutor(int index, ICmdLineExecutor* executor);
};

// class name of sidebar's main window 
const char* const DSWNDCLASS="SideBarWndv10";	

const int DSC_SETSKIN=0x1000;  
const int DSC_HANDLEFILE=0x1001;  
const int DSC_SHOWSIDEBAR=0x1002;  
const int DSC_TESTSKIN=0x1003;  
const int DSC_EXECUTECOMMAND=0x1004;  
const int DSC_CLOSE=0x1005;  

void SetSkin(HWND sidebar, const char* path);
void TestSkin(HWND sidebar, const char* path);
void HandleFile(HWND sidebar, const char* path);
void ExecuteCommand(HWND sidebar, const char* command);
void ShowSidebar(HWND sidebar);
void CloseSidebar(HWND sidebar);

const TCHAR* const RWM_ISUNDOCKEDPANEL=_T("SidebarIsUndockedPanel"); 
const int WM_REDRAWUNDOCKED=WM_USER+1; 
HWND GetUndockedPanel(HWND hwnd);
BOOL InvalidatePanel(HWND hwnd, CONST RECT *lpRect, BOOL bErase);
ESkinState GetNormalSkin(HWND hwnd);

bool variant2bool(VARIANT_BOOL var);
VARIANT_BOOL bool2variant(bool var);
std::string bstr2str(const CComBSTR& text);
std::wstring bstr2wstr(const CComBSTR& text);

#ifdef _DEBUG
#define CHECKCALL(hr) { assert(SUCCEEDED(hr)); }
#else
#define CHECKCALL(hr) { (hr); }
#endif

template <class T> 
CMsgBuilder& operator<<(CMsgBuilder& stream, T param)
{
    std::stringstream ss;
    ss<<param;
    stream.push_back(ss.str());
    return stream;
}

template <class T>
CCommandTargetImplBase<T>::CCommandTargetImplBase(T* pThis)
:p_this(pThis)
{
}

template <class T>
bool CCommandTargetImplBase<T>::onCommand(const std::string& cmdName)
{
    commands_map_t::iterator it=m_commands.find(cmdName);
    if (it!=m_commands.end())
    {
        command_handler_t pCmdHandler=(*it).second.m_handler;
        (p_this->*pCmdHandler)();
        return true;
    }
    else
    {
        return false;
    }
}

template <class T>
bool CCommandTargetImplBase<T>::onUpdateCommand(const std::string& cmdName, CUpdateUI* pCmdUI)
{
    commands_map_t::const_iterator it=m_commands.find(cmdName);
    if (it!=m_commands.end())
    {
        if (command_update_t pCmdUpdate=(*it).second.m_update)
        {
            (p_this->*pCmdUpdate)(pCmdUI);
        }
        else
        {
            pCmdUI->SetEnabled(true);
        }
        return true;
    }
    else
    {
        return false;
    }
}

template <class T>
void CCommandTargetImplBase<T>::addCommand(const char * name, 
                command_handler_t pHandler, 
                command_update_t pUpdate)
{
    assert(m_commands.find(name)==m_commands.end());
    m_commands.insert(
        commands_map_t::value_type(
            name,
            CEntry(pHandler,pUpdate)));
}

template <class T>
CCommandTargetImpl<T>::CCommandTargetImpl(T* pThis)
:CCommandTargetImplBase<T>(pThis)
{
}

template <class T>
STDMETHODIMP CCommandTargetImpl<T>::OnPrivateCommand(int id)
{
    return onPrivateCommand(id)?S_OK:E_FAIL;
}

template <class T>
STDMETHODIMP CCommandTargetImpl<T>::OnUpdatePrivateCommand(int id, IUpdateUI* pCmdUI)
{
    CUpdateUI wrapper(pCmdUI);
    return onUpdatePrivateCommand(id, &wrapper)?S_OK:E_FAIL;
}

template <class T>
STDMETHODIMP CCommandTargetImpl<T>::GetPrivateCommandImage(int id, int* image)
{
    return getPrivateCommandImage(id,image)?S_OK:E_FAIL;
}

template <class T>
STDMETHODIMP CCommandTargetImpl<T>::OnCommand(BSTR cmdName)
{
    return onCommand(bstr2str(cmdName))?S_OK:E_FAIL;
}

template <class T>
STDMETHODIMP CCommandTargetImpl<T>::OnUpdateCommand(BSTR cmdName, IUpdateUI* pCmdUI)
{
    CUpdateUI wrapper(pCmdUI);
    return onUpdateCommand(bstr2str(cmdName),&wrapper)?S_OK:E_FAIL;
}

template <class T>
void CXmlBuilder::AddAttribute(const std::string& name, const T& value)
{
    std::stringstream ss;
    ss<<value;
    CHECKCALL(m_ptr->AddAttribute(CComBSTR(name.c_str()),CComBSTR(ss.str().c_str())));
}

template <class T>
void CXmlBuilder::AddNDAttribute(const std::string& name, const T& value, const T& defValue)
{
    if (value!=defValue)
    {
        AddAttribute(name,value);
    }
}

}

#ifndef DSLIB
#include "dsidebar.inl"
#endif

#endif

#endif
