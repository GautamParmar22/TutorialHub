

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0366 */
/* at Sun Jul 09 21:54:48 2006
 */
/* Compiler settings for ..\dssdk\includes\dsidebar.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __dsidebaridl_h__
#define __dsidebaridl_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IDialogTranslator_FWD_DEFINED__
#define __IDialogTranslator_FWD_DEFINED__
typedef interface IDialogTranslator IDialogTranslator;
#endif 	/* __IDialogTranslator_FWD_DEFINED__ */


#ifndef __ITranslator_FWD_DEFINED__
#define __ITranslator_FWD_DEFINED__
typedef interface ITranslator ITranslator;
#endif 	/* __ITranslator_FWD_DEFINED__ */


#ifndef __IGraphics_FWD_DEFINED__
#define __IGraphics_FWD_DEFINED__
typedef interface IGraphics IGraphics;
#endif 	/* __IGraphics_FWD_DEFINED__ */


#ifndef __ISkinElement_FWD_DEFINED__
#define __ISkinElement_FWD_DEFINED__
typedef interface ISkinElement ISkinElement;
#endif 	/* __ISkinElement_FWD_DEFINED__ */


#ifndef __ISkinElementCreate_FWD_DEFINED__
#define __ISkinElementCreate_FWD_DEFINED__
typedef interface ISkinElementCreate ISkinElementCreate;
#endif 	/* __ISkinElementCreate_FWD_DEFINED__ */


#ifndef __ISkinManager_FWD_DEFINED__
#define __ISkinManager_FWD_DEFINED__
typedef interface ISkinManager ISkinManager;
#endif 	/* __ISkinManager_FWD_DEFINED__ */


#ifndef __IAlert_FWD_DEFINED__
#define __IAlert_FWD_DEFINED__
typedef interface IAlert IAlert;
#endif 	/* __IAlert_FWD_DEFINED__ */


#ifndef __IAlertManager_FWD_DEFINED__
#define __IAlertManager_FWD_DEFINED__
typedef interface IAlertManager IAlertManager;
#endif 	/* __IAlertManager_FWD_DEFINED__ */


#ifndef __IUpdateUI_FWD_DEFINED__
#define __IUpdateUI_FWD_DEFINED__
typedef interface IUpdateUI IUpdateUI;
#endif 	/* __IUpdateUI_FWD_DEFINED__ */


#ifndef __ICommandTarget_FWD_DEFINED__
#define __ICommandTarget_FWD_DEFINED__
typedef interface ICommandTarget ICommandTarget;
#endif 	/* __ICommandTarget_FWD_DEFINED__ */


#ifndef __ICommandManager_FWD_DEFINED__
#define __ICommandManager_FWD_DEFINED__
typedef interface ICommandManager ICommandManager;
#endif 	/* __ICommandManager_FWD_DEFINED__ */


#ifndef __IGlobalSettings_FWD_DEFINED__
#define __IGlobalSettings_FWD_DEFINED__
typedef interface IGlobalSettings IGlobalSettings;
#endif 	/* __IGlobalSettings_FWD_DEFINED__ */


#ifndef __IXmlNode_FWD_DEFINED__
#define __IXmlNode_FWD_DEFINED__
typedef interface IXmlNode IXmlNode;
#endif 	/* __IXmlNode_FWD_DEFINED__ */


#ifndef __IRSSItem_FWD_DEFINED__
#define __IRSSItem_FWD_DEFINED__
typedef interface IRSSItem IRSSItem;
#endif 	/* __IRSSItem_FWD_DEFINED__ */


#ifndef __IRSSFeed_FWD_DEFINED__
#define __IRSSFeed_FWD_DEFINED__
typedef interface IRSSFeed IRSSFeed;
#endif 	/* __IRSSFeed_FWD_DEFINED__ */


#ifndef __IXmlBuilder_FWD_DEFINED__
#define __IXmlBuilder_FWD_DEFINED__
typedef interface IXmlBuilder IXmlBuilder;
#endif 	/* __IXmlBuilder_FWD_DEFINED__ */


#ifndef __IControl_FWD_DEFINED__
#define __IControl_FWD_DEFINED__
typedef interface IControl IControl;
#endif 	/* __IControl_FWD_DEFINED__ */


#ifndef __ITextOutput_FWD_DEFINED__
#define __ITextOutput_FWD_DEFINED__
typedef interface ITextOutput ITextOutput;
#endif 	/* __ITextOutput_FWD_DEFINED__ */


#ifndef __ITextOutputParent_FWD_DEFINED__
#define __ITextOutputParent_FWD_DEFINED__
typedef interface ITextOutputParent ITextOutputParent;
#endif 	/* __ITextOutputParent_FWD_DEFINED__ */


#ifndef __IListRow_FWD_DEFINED__
#define __IListRow_FWD_DEFINED__
typedef interface IListRow IListRow;
#endif 	/* __IListRow_FWD_DEFINED__ */


#ifndef __IListOutput_FWD_DEFINED__
#define __IListOutput_FWD_DEFINED__
typedef interface IListOutput IListOutput;
#endif 	/* __IListOutput_FWD_DEFINED__ */


#ifndef __IListOutputParent_FWD_DEFINED__
#define __IListOutputParent_FWD_DEFINED__
typedef interface IListOutputParent IListOutputParent;
#endif 	/* __IListOutputParent_FWD_DEFINED__ */


#ifndef __IMarqueeOutput_FWD_DEFINED__
#define __IMarqueeOutput_FWD_DEFINED__
typedef interface IMarqueeOutput IMarqueeOutput;
#endif 	/* __IMarqueeOutput_FWD_DEFINED__ */


#ifndef __IMarqueeOutputParent_FWD_DEFINED__
#define __IMarqueeOutputParent_FWD_DEFINED__
typedef interface IMarqueeOutputParent IMarqueeOutputParent;
#endif 	/* __IMarqueeOutputParent_FWD_DEFINED__ */


#ifndef __ISkinButton_FWD_DEFINED__
#define __ISkinButton_FWD_DEFINED__
typedef interface ISkinButton ISkinButton;
#endif 	/* __ISkinButton_FWD_DEFINED__ */


#ifndef __ISkinButtonParent_FWD_DEFINED__
#define __ISkinButtonParent_FWD_DEFINED__
typedef interface ISkinButtonParent ISkinButtonParent;
#endif 	/* __ISkinButtonParent_FWD_DEFINED__ */


#ifndef __ISkinProgressBar_FWD_DEFINED__
#define __ISkinProgressBar_FWD_DEFINED__
typedef interface ISkinProgressBar ISkinProgressBar;
#endif 	/* __ISkinProgressBar_FWD_DEFINED__ */


#ifndef __ISkinSlider_FWD_DEFINED__
#define __ISkinSlider_FWD_DEFINED__
typedef interface ISkinSlider ISkinSlider;
#endif 	/* __ISkinSlider_FWD_DEFINED__ */


#ifndef __ISkinSliderParent_FWD_DEFINED__
#define __ISkinSliderParent_FWD_DEFINED__
typedef interface ISkinSliderParent ISkinSliderParent;
#endif 	/* __ISkinSliderParent_FWD_DEFINED__ */


#ifndef __IBarChart_FWD_DEFINED__
#define __IBarChart_FWD_DEFINED__
typedef interface IBarChart IBarChart;
#endif 	/* __IBarChart_FWD_DEFINED__ */


#ifndef __IBarChartParent_FWD_DEFINED__
#define __IBarChartParent_FWD_DEFINED__
typedef interface IBarChartParent IBarChartParent;
#endif 	/* __IBarChartParent_FWD_DEFINED__ */


#ifndef __IImage_FWD_DEFINED__
#define __IImage_FWD_DEFINED__
typedef interface IImage IImage;
#endif 	/* __IImage_FWD_DEFINED__ */


#ifndef __IText_FWD_DEFINED__
#define __IText_FWD_DEFINED__
typedef interface IText IText;
#endif 	/* __IText_FWD_DEFINED__ */


#ifndef __IControlEvent_FWD_DEFINED__
#define __IControlEvent_FWD_DEFINED__
typedef interface IControlEvent IControlEvent;
#endif 	/* __IControlEvent_FWD_DEFINED__ */


#ifndef __IControlEventHandler_FWD_DEFINED__
#define __IControlEventHandler_FWD_DEFINED__
typedef interface IControlEventHandler IControlEventHandler;
#endif 	/* __IControlEventHandler_FWD_DEFINED__ */


#ifndef __IHwndHolder_FWD_DEFINED__
#define __IHwndHolder_FWD_DEFINED__
typedef interface IHwndHolder IHwndHolder;
#endif 	/* __IHwndHolder_FWD_DEFINED__ */


#ifndef __IDetailsWndParent_FWD_DEFINED__
#define __IDetailsWndParent_FWD_DEFINED__
typedef interface IDetailsWndParent IDetailsWndParent;
#endif 	/* __IDetailsWndParent_FWD_DEFINED__ */


#ifndef __IDetailsWndParent2_FWD_DEFINED__
#define __IDetailsWndParent2_FWD_DEFINED__
typedef interface IDetailsWndParent2 IDetailsWndParent2;
#endif 	/* __IDetailsWndParent2_FWD_DEFINED__ */


#ifndef __IDetailsWnd_FWD_DEFINED__
#define __IDetailsWnd_FWD_DEFINED__
typedef interface IDetailsWnd IDetailsWnd;
#endif 	/* __IDetailsWnd_FWD_DEFINED__ */


#ifndef __ITextDetailsWnd_FWD_DEFINED__
#define __ITextDetailsWnd_FWD_DEFINED__
typedef interface ITextDetailsWnd ITextDetailsWnd;
#endif 	/* __ITextDetailsWnd_FWD_DEFINED__ */


#ifndef __ITextDetailsWnd2_FWD_DEFINED__
#define __ITextDetailsWnd2_FWD_DEFINED__
typedef interface ITextDetailsWnd2 ITextDetailsWnd2;
#endif 	/* __ITextDetailsWnd2_FWD_DEFINED__ */


#ifndef __ILinkDetailsWnd_FWD_DEFINED__
#define __ILinkDetailsWnd_FWD_DEFINED__
typedef interface ILinkDetailsWnd ILinkDetailsWnd;
#endif 	/* __ILinkDetailsWnd_FWD_DEFINED__ */


#ifndef __ILinkDetailsWnd2_FWD_DEFINED__
#define __ILinkDetailsWnd2_FWD_DEFINED__
typedef interface ILinkDetailsWnd2 ILinkDetailsWnd2;
#endif 	/* __ILinkDetailsWnd2_FWD_DEFINED__ */


#ifndef __IHTMLDetailsWnd_FWD_DEFINED__
#define __IHTMLDetailsWnd_FWD_DEFINED__
typedef interface IHTMLDetailsWnd IHTMLDetailsWnd;
#endif 	/* __IHTMLDetailsWnd_FWD_DEFINED__ */


#ifndef __IHTMLDetailsWnd2_FWD_DEFINED__
#define __IHTMLDetailsWnd2_FWD_DEFINED__
typedef interface IHTMLDetailsWnd2 IHTMLDetailsWnd2;
#endif 	/* __IHTMLDetailsWnd2_FWD_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd_FWD_DEFINED__
#define __IWebBrowserDetailsWnd_FWD_DEFINED__
typedef interface IWebBrowserDetailsWnd IWebBrowserDetailsWnd;
#endif 	/* __IWebBrowserDetailsWnd_FWD_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd2_FWD_DEFINED__
#define __IWebBrowserDetailsWnd2_FWD_DEFINED__
typedef interface IWebBrowserDetailsWnd2 IWebBrowserDetailsWnd2;
#endif 	/* __IWebBrowserDetailsWnd2_FWD_DEFINED__ */


#ifndef __IControlFactory_FWD_DEFINED__
#define __IControlFactory_FWD_DEFINED__
typedef interface IControlFactory IControlFactory;
#endif 	/* __IControlFactory_FWD_DEFINED__ */


#ifndef __ISidebar_FWD_DEFINED__
#define __ISidebar_FWD_DEFINED__
typedef interface ISidebar ISidebar;
#endif 	/* __ISidebar_FWD_DEFINED__ */


#ifndef __ISidebarWindow_FWD_DEFINED__
#define __ISidebarWindow_FWD_DEFINED__
typedef interface ISidebarWindow ISidebarWindow;
#endif 	/* __ISidebarWindow_FWD_DEFINED__ */


#ifndef __IPanelParent_FWD_DEFINED__
#define __IPanelParent_FWD_DEFINED__
typedef interface IPanelParent IPanelParent;
#endif 	/* __IPanelParent_FWD_DEFINED__ */


#ifndef __IPanelConfig_FWD_DEFINED__
#define __IPanelConfig_FWD_DEFINED__
typedef interface IPanelConfig IPanelConfig;
#endif 	/* __IPanelConfig_FWD_DEFINED__ */


#ifndef __ICanvas_FWD_DEFINED__
#define __ICanvas_FWD_DEFINED__
typedef interface ICanvas ICanvas;
#endif 	/* __ICanvas_FWD_DEFINED__ */


#ifndef __ISidebarSite_FWD_DEFINED__
#define __ISidebarSite_FWD_DEFINED__
typedef interface ISidebarSite ISidebarSite;
#endif 	/* __ISidebarSite_FWD_DEFINED__ */


#ifndef __IPanelContextMenu_FWD_DEFINED__
#define __IPanelContextMenu_FWD_DEFINED__
typedef interface IPanelContextMenu IPanelContextMenu;
#endif 	/* __IPanelContextMenu_FWD_DEFINED__ */


#ifndef __IPanelProperties_FWD_DEFINED__
#define __IPanelProperties_FWD_DEFINED__
typedef interface IPanelProperties IPanelProperties;
#endif 	/* __IPanelProperties_FWD_DEFINED__ */


#ifndef __IPanelFileHandler_FWD_DEFINED__
#define __IPanelFileHandler_FWD_DEFINED__
typedef interface IPanelFileHandler IPanelFileHandler;
#endif 	/* __IPanelFileHandler_FWD_DEFINED__ */


#ifndef __IPanelNotification_FWD_DEFINED__
#define __IPanelNotification_FWD_DEFINED__
typedef interface IPanelNotification IPanelNotification;
#endif 	/* __IPanelNotification_FWD_DEFINED__ */


#ifndef __IPanelEvent_FWD_DEFINED__
#define __IPanelEvent_FWD_DEFINED__
typedef interface IPanelEvent IPanelEvent;
#endif 	/* __IPanelEvent_FWD_DEFINED__ */


#ifndef __IPanelPolicy_FWD_DEFINED__
#define __IPanelPolicy_FWD_DEFINED__
typedef interface IPanelPolicy IPanelPolicy;
#endif 	/* __IPanelPolicy_FWD_DEFINED__ */


#ifndef __IPanelWindow_FWD_DEFINED__
#define __IPanelWindow_FWD_DEFINED__
typedef interface IPanelWindow IPanelWindow;
#endif 	/* __IPanelWindow_FWD_DEFINED__ */


#ifndef __IPanel_FWD_DEFINED__
#define __IPanel_FWD_DEFINED__
typedef interface IPanel IPanel;
#endif 	/* __IPanel_FWD_DEFINED__ */


#ifndef __IPerfmonTicket_FWD_DEFINED__
#define __IPerfmonTicket_FWD_DEFINED__
typedef interface IPerfmonTicket IPerfmonTicket;
#endif 	/* __IPerfmonTicket_FWD_DEFINED__ */


#ifndef __IPanelCreator_FWD_DEFINED__
#define __IPanelCreator_FWD_DEFINED__
typedef interface IPanelCreator IPanelCreator;
#endif 	/* __IPanelCreator_FWD_DEFINED__ */


#ifndef __IPanelCreatorEvents_FWD_DEFINED__
#define __IPanelCreatorEvents_FWD_DEFINED__
typedef interface IPanelCreatorEvents IPanelCreatorEvents;
#endif 	/* __IPanelCreatorEvents_FWD_DEFINED__ */


#ifndef __IPlugin_FWD_DEFINED__
#define __IPlugin_FWD_DEFINED__
typedef interface IPlugin IPlugin;
#endif 	/* __IPlugin_FWD_DEFINED__ */


#ifndef __IPluginProperties_FWD_DEFINED__
#define __IPluginProperties_FWD_DEFINED__
typedef interface IPluginProperties IPluginProperties;
#endif 	/* __IPluginProperties_FWD_DEFINED__ */


#ifndef __IFormField_FWD_DEFINED__
#define __IFormField_FWD_DEFINED__
typedef interface IFormField IFormField;
#endif 	/* __IFormField_FWD_DEFINED__ */


#ifndef __IForm_FWD_DEFINED__
#define __IForm_FWD_DEFINED__
typedef interface IForm IForm;
#endif 	/* __IForm_FWD_DEFINED__ */


#ifndef __ICmdLinePanel_FWD_DEFINED__
#define __ICmdLinePanel_FWD_DEFINED__
typedef interface ICmdLinePanel ICmdLinePanel;
#endif 	/* __ICmdLinePanel_FWD_DEFINED__ */


#ifndef __ICmdLineExecutor_FWD_DEFINED__
#define __ICmdLineExecutor_FWD_DEFINED__
typedef interface ICmdLineExecutor ICmdLineExecutor;
#endif 	/* __ICmdLineExecutor_FWD_DEFINED__ */


#ifndef __ICmdLineSuggestion_FWD_DEFINED__
#define __ICmdLineSuggestion_FWD_DEFINED__
typedef interface ICmdLineSuggestion ICmdLineSuggestion;
#endif 	/* __ICmdLineSuggestion_FWD_DEFINED__ */


#ifndef __ICmdLineExtension_FWD_DEFINED__
#define __ICmdLineExtension_FWD_DEFINED__
typedef interface ICmdLineExtension ICmdLineExtension;
#endif 	/* __ICmdLineExtension_FWD_DEFINED__ */


#ifndef __ICmdLineExtCreator_FWD_DEFINED__
#define __ICmdLineExtCreator_FWD_DEFINED__
typedef interface ICmdLineExtCreator ICmdLineExtCreator;
#endif 	/* __ICmdLineExtCreator_FWD_DEFINED__ */


#ifndef __Sidebar_FWD_DEFINED__
#define __Sidebar_FWD_DEFINED__

#ifdef __cplusplus
typedef class Sidebar Sidebar;
#else
typedef struct Sidebar Sidebar;
#endif /* __cplusplus */

#endif 	/* __Sidebar_FWD_DEFINED__ */


#ifndef __IPanelConfig_FWD_DEFINED__
#define __IPanelConfig_FWD_DEFINED__
typedef interface IPanelConfig IPanelConfig;
#endif 	/* __IPanelConfig_FWD_DEFINED__ */


#ifndef __IPlugin_FWD_DEFINED__
#define __IPlugin_FWD_DEFINED__
typedef interface IPlugin IPlugin;
#endif 	/* __IPlugin_FWD_DEFINED__ */


#ifndef __IPluginProperties_FWD_DEFINED__
#define __IPluginProperties_FWD_DEFINED__
typedef interface IPluginProperties IPluginProperties;
#endif 	/* __IPluginProperties_FWD_DEFINED__ */


#ifndef __IPanel_FWD_DEFINED__
#define __IPanel_FWD_DEFINED__
typedef interface IPanel IPanel;
#endif 	/* __IPanel_FWD_DEFINED__ */


#ifndef __IPanelWindow_FWD_DEFINED__
#define __IPanelWindow_FWD_DEFINED__
typedef interface IPanelWindow IPanelWindow;
#endif 	/* __IPanelWindow_FWD_DEFINED__ */


#ifndef __IPanelContextMenu_FWD_DEFINED__
#define __IPanelContextMenu_FWD_DEFINED__
typedef interface IPanelContextMenu IPanelContextMenu;
#endif 	/* __IPanelContextMenu_FWD_DEFINED__ */


#ifndef __IPanelProperties_FWD_DEFINED__
#define __IPanelProperties_FWD_DEFINED__
typedef interface IPanelProperties IPanelProperties;
#endif 	/* __IPanelProperties_FWD_DEFINED__ */


#ifndef __IPanelFileHandler_FWD_DEFINED__
#define __IPanelFileHandler_FWD_DEFINED__
typedef interface IPanelFileHandler IPanelFileHandler;
#endif 	/* __IPanelFileHandler_FWD_DEFINED__ */


#ifndef __IPanelNotification_FWD_DEFINED__
#define __IPanelNotification_FWD_DEFINED__
typedef interface IPanelNotification IPanelNotification;
#endif 	/* __IPanelNotification_FWD_DEFINED__ */


#ifndef __IPanelEvent_FWD_DEFINED__
#define __IPanelEvent_FWD_DEFINED__
typedef interface IPanelEvent IPanelEvent;
#endif 	/* __IPanelEvent_FWD_DEFINED__ */


#ifndef __IPanelPolicy_FWD_DEFINED__
#define __IPanelPolicy_FWD_DEFINED__
typedef interface IPanelPolicy IPanelPolicy;
#endif 	/* __IPanelPolicy_FWD_DEFINED__ */


#ifndef __IPanelCreator_FWD_DEFINED__
#define __IPanelCreator_FWD_DEFINED__
typedef interface IPanelCreator IPanelCreator;
#endif 	/* __IPanelCreator_FWD_DEFINED__ */


#ifndef __ITextOutputParent_FWD_DEFINED__
#define __ITextOutputParent_FWD_DEFINED__
typedef interface ITextOutputParent ITextOutputParent;
#endif 	/* __ITextOutputParent_FWD_DEFINED__ */


#ifndef __IListOutputParent_FWD_DEFINED__
#define __IListOutputParent_FWD_DEFINED__
typedef interface IListOutputParent IListOutputParent;
#endif 	/* __IListOutputParent_FWD_DEFINED__ */


#ifndef __IMarqueeOutputParent_FWD_DEFINED__
#define __IMarqueeOutputParent_FWD_DEFINED__
typedef interface IMarqueeOutputParent IMarqueeOutputParent;
#endif 	/* __IMarqueeOutputParent_FWD_DEFINED__ */


#ifndef __ISkinButtonParent_FWD_DEFINED__
#define __ISkinButtonParent_FWD_DEFINED__
typedef interface ISkinButtonParent ISkinButtonParent;
#endif 	/* __ISkinButtonParent_FWD_DEFINED__ */


#ifndef __ISkinSliderParent_FWD_DEFINED__
#define __ISkinSliderParent_FWD_DEFINED__
typedef interface ISkinSliderParent ISkinSliderParent;
#endif 	/* __ISkinSliderParent_FWD_DEFINED__ */


#ifndef __IBarChartParent_FWD_DEFINED__
#define __IBarChartParent_FWD_DEFINED__
typedef interface IBarChartParent IBarChartParent;
#endif 	/* __IBarChartParent_FWD_DEFINED__ */


#ifndef __IDetailsWndParent_FWD_DEFINED__
#define __IDetailsWndParent_FWD_DEFINED__
typedef interface IDetailsWndParent IDetailsWndParent;
#endif 	/* __IDetailsWndParent_FWD_DEFINED__ */


#ifndef __IDetailsWndParent2_FWD_DEFINED__
#define __IDetailsWndParent2_FWD_DEFINED__
typedef interface IDetailsWndParent2 IDetailsWndParent2;
#endif 	/* __IDetailsWndParent2_FWD_DEFINED__ */


#ifndef __IPanelParent_FWD_DEFINED__
#define __IPanelParent_FWD_DEFINED__
typedef interface IPanelParent IPanelParent;
#endif 	/* __IPanelParent_FWD_DEFINED__ */


#ifndef __IPerfmonTicket_FWD_DEFINED__
#define __IPerfmonTicket_FWD_DEFINED__
typedef interface IPerfmonTicket IPerfmonTicket;
#endif 	/* __IPerfmonTicket_FWD_DEFINED__ */


#ifndef __IDialogTranslator_FWD_DEFINED__
#define __IDialogTranslator_FWD_DEFINED__
typedef interface IDialogTranslator IDialogTranslator;
#endif 	/* __IDialogTranslator_FWD_DEFINED__ */


#ifndef __ICommandTarget_FWD_DEFINED__
#define __ICommandTarget_FWD_DEFINED__
typedef interface ICommandTarget ICommandTarget;
#endif 	/* __ICommandTarget_FWD_DEFINED__ */


#ifndef __ITextOutput_FWD_DEFINED__
#define __ITextOutput_FWD_DEFINED__
typedef interface ITextOutput ITextOutput;
#endif 	/* __ITextOutput_FWD_DEFINED__ */


#ifndef __IListOutput_FWD_DEFINED__
#define __IListOutput_FWD_DEFINED__
typedef interface IListOutput IListOutput;
#endif 	/* __IListOutput_FWD_DEFINED__ */


#ifndef __ISkinProgressBar_FWD_DEFINED__
#define __ISkinProgressBar_FWD_DEFINED__
typedef interface ISkinProgressBar ISkinProgressBar;
#endif 	/* __ISkinProgressBar_FWD_DEFINED__ */


#ifndef __IMarqueeOutput_FWD_DEFINED__
#define __IMarqueeOutput_FWD_DEFINED__
typedef interface IMarqueeOutput IMarqueeOutput;
#endif 	/* __IMarqueeOutput_FWD_DEFINED__ */


#ifndef __ISkinButton_FWD_DEFINED__
#define __ISkinButton_FWD_DEFINED__
typedef interface ISkinButton ISkinButton;
#endif 	/* __ISkinButton_FWD_DEFINED__ */


#ifndef __ISkinSlider_FWD_DEFINED__
#define __ISkinSlider_FWD_DEFINED__
typedef interface ISkinSlider ISkinSlider;
#endif 	/* __ISkinSlider_FWD_DEFINED__ */


#ifndef __IBarChart_FWD_DEFINED__
#define __IBarChart_FWD_DEFINED__
typedef interface IBarChart IBarChart;
#endif 	/* __IBarChart_FWD_DEFINED__ */


#ifndef __IImage_FWD_DEFINED__
#define __IImage_FWD_DEFINED__
typedef interface IImage IImage;
#endif 	/* __IImage_FWD_DEFINED__ */


#ifndef __IText_FWD_DEFINED__
#define __IText_FWD_DEFINED__
typedef interface IText IText;
#endif 	/* __IText_FWD_DEFINED__ */


#ifndef __IHwndHolder_FWD_DEFINED__
#define __IHwndHolder_FWD_DEFINED__
typedef interface IHwndHolder IHwndHolder;
#endif 	/* __IHwndHolder_FWD_DEFINED__ */


#ifndef __ISidebarSite_FWD_DEFINED__
#define __ISidebarSite_FWD_DEFINED__
typedef interface ISidebarSite ISidebarSite;
#endif 	/* __ISidebarSite_FWD_DEFINED__ */


#ifndef __ICanvas_FWD_DEFINED__
#define __ICanvas_FWD_DEFINED__
typedef interface ICanvas ICanvas;
#endif 	/* __ICanvas_FWD_DEFINED__ */


#ifndef __IControl_FWD_DEFINED__
#define __IControl_FWD_DEFINED__
typedef interface IControl IControl;
#endif 	/* __IControl_FWD_DEFINED__ */


#ifndef __IControlEventHandler_FWD_DEFINED__
#define __IControlEventHandler_FWD_DEFINED__
typedef interface IControlEventHandler IControlEventHandler;
#endif 	/* __IControlEventHandler_FWD_DEFINED__ */


#ifndef __IControlEvent_FWD_DEFINED__
#define __IControlEvent_FWD_DEFINED__
typedef interface IControlEvent IControlEvent;
#endif 	/* __IControlEvent_FWD_DEFINED__ */


#ifndef __ICmdLinePanel_FWD_DEFINED__
#define __ICmdLinePanel_FWD_DEFINED__
typedef interface ICmdLinePanel ICmdLinePanel;
#endif 	/* __ICmdLinePanel_FWD_DEFINED__ */


#ifndef __IFormField_FWD_DEFINED__
#define __IFormField_FWD_DEFINED__
typedef interface IFormField IFormField;
#endif 	/* __IFormField_FWD_DEFINED__ */


#ifndef __IForm_FWD_DEFINED__
#define __IForm_FWD_DEFINED__
typedef interface IForm IForm;
#endif 	/* __IForm_FWD_DEFINED__ */


#ifndef __ICmdLineSuggestion_FWD_DEFINED__
#define __ICmdLineSuggestion_FWD_DEFINED__
typedef interface ICmdLineSuggestion ICmdLineSuggestion;
#endif 	/* __ICmdLineSuggestion_FWD_DEFINED__ */


#ifndef __ICmdLineExtension_FWD_DEFINED__
#define __ICmdLineExtension_FWD_DEFINED__
typedef interface ICmdLineExtension ICmdLineExtension;
#endif 	/* __ICmdLineExtension_FWD_DEFINED__ */


#ifndef __ICmdLineExtCreator_FWD_DEFINED__
#define __ICmdLineExtCreator_FWD_DEFINED__
typedef interface ICmdLineExtCreator ICmdLineExtCreator;
#endif 	/* __ICmdLineExtCreator_FWD_DEFINED__ */


#ifndef __IDetailsWnd_FWD_DEFINED__
#define __IDetailsWnd_FWD_DEFINED__
typedef interface IDetailsWnd IDetailsWnd;
#endif 	/* __IDetailsWnd_FWD_DEFINED__ */


#ifndef __ITextDetailsWnd_FWD_DEFINED__
#define __ITextDetailsWnd_FWD_DEFINED__
typedef interface ITextDetailsWnd ITextDetailsWnd;
#endif 	/* __ITextDetailsWnd_FWD_DEFINED__ */


#ifndef __ITextDetailsWnd2_FWD_DEFINED__
#define __ITextDetailsWnd2_FWD_DEFINED__
typedef interface ITextDetailsWnd2 ITextDetailsWnd2;
#endif 	/* __ITextDetailsWnd2_FWD_DEFINED__ */


#ifndef __ILinkDetailsWnd_FWD_DEFINED__
#define __ILinkDetailsWnd_FWD_DEFINED__
typedef interface ILinkDetailsWnd ILinkDetailsWnd;
#endif 	/* __ILinkDetailsWnd_FWD_DEFINED__ */


#ifndef __ILinkDetailsWnd2_FWD_DEFINED__
#define __ILinkDetailsWnd2_FWD_DEFINED__
typedef interface ILinkDetailsWnd2 ILinkDetailsWnd2;
#endif 	/* __ILinkDetailsWnd2_FWD_DEFINED__ */


#ifndef __IHTMLDetailsWnd_FWD_DEFINED__
#define __IHTMLDetailsWnd_FWD_DEFINED__
typedef interface IHTMLDetailsWnd IHTMLDetailsWnd;
#endif 	/* __IHTMLDetailsWnd_FWD_DEFINED__ */


#ifndef __IHTMLDetailsWnd2_FWD_DEFINED__
#define __IHTMLDetailsWnd2_FWD_DEFINED__
typedef interface IHTMLDetailsWnd2 IHTMLDetailsWnd2;
#endif 	/* __IHTMLDetailsWnd2_FWD_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd_FWD_DEFINED__
#define __IWebBrowserDetailsWnd_FWD_DEFINED__
typedef interface IWebBrowserDetailsWnd IWebBrowserDetailsWnd;
#endif 	/* __IWebBrowserDetailsWnd_FWD_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd2_FWD_DEFINED__
#define __IWebBrowserDetailsWnd2_FWD_DEFINED__
typedef interface IWebBrowserDetailsWnd2 IWebBrowserDetailsWnd2;
#endif 	/* __IWebBrowserDetailsWnd2_FWD_DEFINED__ */


#ifndef __IRSSFeed_FWD_DEFINED__
#define __IRSSFeed_FWD_DEFINED__
typedef interface IRSSFeed IRSSFeed;
#endif 	/* __IRSSFeed_FWD_DEFINED__ */


#ifndef __IRSSItem_FWD_DEFINED__
#define __IRSSItem_FWD_DEFINED__
typedef interface IRSSItem IRSSItem;
#endif 	/* __IRSSItem_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_dsidebar_0000 */
/* [local] */ 

#pragma warning( disable: 4430)


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0000_v0_0_s_ifspec;

#ifndef __IDialogTranslator_INTERFACE_DEFINED__
#define __IDialogTranslator_INTERFACE_DEFINED__

/* interface IDialogTranslator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDialogTranslator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("478ABFD0-0010-4f5f-9BC2-7DA7CA941A3E")
    IDialogTranslator : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetCaption( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetControl( 
            BSTR controlId,
            BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDialogTranslatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDialogTranslator * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDialogTranslator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDialogTranslator * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDialogTranslator * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDialogTranslator * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDialogTranslator * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDialogTranslator * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IDialogTranslator * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *SetControl )( 
            IDialogTranslator * This,
            BSTR controlId,
            BSTR text);
        
        END_INTERFACE
    } IDialogTranslatorVtbl;

    interface IDialogTranslator
    {
        CONST_VTBL struct IDialogTranslatorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDialogTranslator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDialogTranslator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDialogTranslator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDialogTranslator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDialogTranslator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDialogTranslator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDialogTranslator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDialogTranslator_SetCaption(This,text)	\
    (This)->lpVtbl -> SetCaption(This,text)

#define IDialogTranslator_SetControl(This,controlId,text)	\
    (This)->lpVtbl -> SetControl(This,controlId,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDialogTranslator_SetCaption_Proxy( 
    IDialogTranslator * This,
    BSTR text);


void __RPC_STUB IDialogTranslator_SetCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDialogTranslator_SetControl_Proxy( 
    IDialogTranslator * This,
    BSTR controlId,
    BSTR text);


void __RPC_STUB IDialogTranslator_SetControl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDialogTranslator_INTERFACE_DEFINED__ */


#ifndef __ITranslator_INTERFACE_DEFINED__
#define __ITranslator_INTERFACE_DEFINED__

/* interface ITranslator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITranslator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("62458ACC-13C1-4c51-B366-16F7FC193B9E")
    ITranslator : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE TranslateCommand( 
            BSTR text,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TranslateMenu( 
            HMENU hMenu) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TranslateDialog( 
            int hDlg,
            BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TranslateControl( 
            BSTR dialog,
            BSTR ctrlId,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDialogCaption( 
            BSTR name,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Date2string( 
            const SYSTEMTIME *time,
            BSTR format,
            DWORD flags,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Msg( 
            BSTR id,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TranslateDialog2( 
            IDialogTranslator *dlgTranslator,
            BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FillParameter( 
            /* [in] */ BSTR raw_message,
            /* [in] */ int paremeterIndex,
            /* [in] */ VARIANT paramterValue,
            /* [retval][out] */ BSTR *message) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITranslatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITranslator * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITranslator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITranslator * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITranslator * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITranslator * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITranslator * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITranslator * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *TranslateCommand )( 
            ITranslator * This,
            BSTR text,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *TranslateMenu )( 
            ITranslator * This,
            HMENU hMenu);
        
        HRESULT ( STDMETHODCALLTYPE *TranslateDialog )( 
            ITranslator * This,
            int hDlg,
            BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *TranslateControl )( 
            ITranslator * This,
            BSTR dialog,
            BSTR ctrlId,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetDialogCaption )( 
            ITranslator * This,
            BSTR name,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Date2string )( 
            ITranslator * This,
            const SYSTEMTIME *time,
            BSTR format,
            DWORD flags,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Msg )( 
            ITranslator * This,
            BSTR id,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *TranslateDialog2 )( 
            ITranslator * This,
            IDialogTranslator *dlgTranslator,
            BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *FillParameter )( 
            ITranslator * This,
            /* [in] */ BSTR raw_message,
            /* [in] */ int paremeterIndex,
            /* [in] */ VARIANT paramterValue,
            /* [retval][out] */ BSTR *message);
        
        END_INTERFACE
    } ITranslatorVtbl;

    interface ITranslator
    {
        CONST_VTBL struct ITranslatorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITranslator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITranslator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITranslator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITranslator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITranslator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITranslator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITranslator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITranslator_TranslateCommand(This,text,retVal)	\
    (This)->lpVtbl -> TranslateCommand(This,text,retVal)

#define ITranslator_TranslateMenu(This,hMenu)	\
    (This)->lpVtbl -> TranslateMenu(This,hMenu)

#define ITranslator_TranslateDialog(This,hDlg,name)	\
    (This)->lpVtbl -> TranslateDialog(This,hDlg,name)

#define ITranslator_TranslateControl(This,dialog,ctrlId,retVal)	\
    (This)->lpVtbl -> TranslateControl(This,dialog,ctrlId,retVal)

#define ITranslator_GetDialogCaption(This,name,retVal)	\
    (This)->lpVtbl -> GetDialogCaption(This,name,retVal)

#define ITranslator_Date2string(This,time,format,flags,retVal)	\
    (This)->lpVtbl -> Date2string(This,time,format,flags,retVal)

#define ITranslator_Msg(This,id,retVal)	\
    (This)->lpVtbl -> Msg(This,id,retVal)

#define ITranslator_TranslateDialog2(This,dlgTranslator,name)	\
    (This)->lpVtbl -> TranslateDialog2(This,dlgTranslator,name)

#define ITranslator_FillParameter(This,raw_message,paremeterIndex,paramterValue,message)	\
    (This)->lpVtbl -> FillParameter(This,raw_message,paremeterIndex,paramterValue,message)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITranslator_TranslateCommand_Proxy( 
    ITranslator * This,
    BSTR text,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ITranslator_TranslateCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_TranslateMenu_Proxy( 
    ITranslator * This,
    HMENU hMenu);


void __RPC_STUB ITranslator_TranslateMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_TranslateDialog_Proxy( 
    ITranslator * This,
    int hDlg,
    BSTR name);


void __RPC_STUB ITranslator_TranslateDialog_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_TranslateControl_Proxy( 
    ITranslator * This,
    BSTR dialog,
    BSTR ctrlId,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ITranslator_TranslateControl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_GetDialogCaption_Proxy( 
    ITranslator * This,
    BSTR name,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ITranslator_GetDialogCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_Date2string_Proxy( 
    ITranslator * This,
    const SYSTEMTIME *time,
    BSTR format,
    DWORD flags,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ITranslator_Date2string_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_Msg_Proxy( 
    ITranslator * This,
    BSTR id,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ITranslator_Msg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_TranslateDialog2_Proxy( 
    ITranslator * This,
    IDialogTranslator *dlgTranslator,
    BSTR name);


void __RPC_STUB ITranslator_TranslateDialog2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITranslator_FillParameter_Proxy( 
    ITranslator * This,
    /* [in] */ BSTR raw_message,
    /* [in] */ int paremeterIndex,
    /* [in] */ VARIANT paramterValue,
    /* [retval][out] */ BSTR *message);


void __RPC_STUB ITranslator_FillParameter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITranslator_INTERFACE_DEFINED__ */


#ifndef __IGraphics_INTERFACE_DEFINED__
#define __IGraphics_INTERFACE_DEFINED__

/* interface IGraphics */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IGraphics;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C4CD4C7C-2824-4337-859F-D1DCA1D3817B")
    IGraphics : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE TakeoverHDC( 
            int hdc) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ReleaseHDC( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Get( 
            /* [retval][out] */ int *graphics) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IGraphicsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IGraphics * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IGraphics * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IGraphics * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IGraphics * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IGraphics * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IGraphics * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IGraphics * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *TakeoverHDC )( 
            IGraphics * This,
            int hdc);
        
        HRESULT ( STDMETHODCALLTYPE *ReleaseHDC )( 
            IGraphics * This);
        
        HRESULT ( STDMETHODCALLTYPE *Get )( 
            IGraphics * This,
            /* [retval][out] */ int *graphics);
        
        END_INTERFACE
    } IGraphicsVtbl;

    interface IGraphics
    {
        CONST_VTBL struct IGraphicsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IGraphics_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IGraphics_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IGraphics_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IGraphics_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IGraphics_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IGraphics_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IGraphics_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IGraphics_TakeoverHDC(This,hdc)	\
    (This)->lpVtbl -> TakeoverHDC(This,hdc)

#define IGraphics_ReleaseHDC(This)	\
    (This)->lpVtbl -> ReleaseHDC(This)

#define IGraphics_Get(This,graphics)	\
    (This)->lpVtbl -> Get(This,graphics)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IGraphics_TakeoverHDC_Proxy( 
    IGraphics * This,
    int hdc);


void __RPC_STUB IGraphics_TakeoverHDC_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGraphics_ReleaseHDC_Proxy( 
    IGraphics * This);


void __RPC_STUB IGraphics_ReleaseHDC_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGraphics_Get_Proxy( 
    IGraphics * This,
    /* [retval][out] */ int *graphics);


void __RPC_STUB IGraphics_Get_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IGraphics_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0265 */
/* [local] */ 


enum ESkinState
    {	Normal	= 0,
	Hover	= Normal + 1,
	Pressed	= Hover + 1,
	Undocked	= Pressed + 1
    } ;

enum ESkinItem
    {	seBackground	= 0,
	seMirroredBackground	= seBackground + 1,
	seBorder	= seMirroredBackground + 1,
	sePanel	= seBorder + 1,
	seSmallFontPanel	= sePanel + 1,
	seCaption	= seSmallFontPanel + 1,
	seCollapsePanelBtn	= seCaption + 1,
	seExpandPanelBtn	= seCollapsePanelBtn + 1,
	seStackBackground	= seExpandPanelBtn + 1,
	seStackActiveCaption	= seStackBackground + 1,
	seStackInactiveCaption	= seStackActiveCaption + 1,
	seDetails	= seStackInactiveCaption + 1,
	seDetailsTitle	= seDetails + 1,
	seDetailsText	= seDetailsTitle + 1,
	seCloseDetailsBtn	= seDetailsText + 1,
	sePinDetailsBtn	= seCloseDetailsBtn + 1,
	seUnpinDetailsBtn	= sePinDetailsBtn + 1,
	seFirstRow	= seUnpinDetailsBtn + 1,
	seRowsSeparator	= seFirstRow + 1,
	seBarChart	= seRowsSeparator + 1,
	seBarChartBackground	= seBarChart + 1,
	seBarChartOutline	= seBarChartBackground + 1,
	sePieChart	= seBarChartOutline + 1,
	seMSNOnlineIcon	= sePieChart + 1,
	seMSNOfflineIcon	= seMSNOnlineIcon + 1,
	seMSNBusyIcon	= seMSNOfflineIcon + 1,
	seMSNAwayIcon	= seMSNBusyIcon + 1,
	seInkNoteIcon	= seMSNAwayIcon + 1,
	seYellowNoteIcon	= seInkNoteIcon + 1,
	seBlueNoteIcon	= seYellowNoteIcon + 1,
	seGreenNoteIcon	= seBlueNoteIcon + 1,
	sePinkNoteIcon	= seGreenNoteIcon + 1,
	seWhiteNoteIcon	= sePinkNoteIcon + 1,
	seCpuIcon	= seWhiteNoteIcon + 1,
	seNetIcon	= seCpuIcon + 1,
	seDiskIcon	= seNetIcon + 1,
	seMPPanel	= seDiskIcon + 1,
	seMPDisplay	= seMPPanel + 1,
	seMPPause	= seMPDisplay + 1,
	seMPPlay	= seMPPause + 1,
	seMPStop	= seMPPlay + 1,
	seMPNext	= seMPStop + 1,
	seMPPrev	= seMPNext + 1,
	seMPMute	= seMPPrev + 1,
	seMPUndock	= seMPMute + 1,
	seNewsOnline	= seMPUndock + 1,
	seNewsOffline	= seNewsOnline + 1,
	seNewsDownloading	= seNewsOffline + 1,
	seClockFace	= seNewsDownloading + 1,
	seClockHand	= seClockFace + 1,
	seClockPanel	= seClockHand + 1,
	seDoneTask	= seClockPanel + 1,
	seUnreadMessage	= seDoneTask + 1,
	seTodayItem	= seUnreadMessage + 1,
	seTomorrowItem	= seTodayItem + 1,
	seFreshHeadline	= seTomorrowItem + 1,
	seCmdLineEdit	= seFreshHeadline + 1,
	seCmdLineBtn	= seCmdLineEdit + 1,
	seAlert	= seCmdLineBtn + 1,
	seMailAlert	= seAlert + 1,
	seNewsAlert	= seMailAlert + 1,
	seResponse	= seNewsAlert + 1,
	seStockIcon	= seResponse + 1,
	seStock	= seStockIcon + 1,
	seStockUp	= seStock + 1,
	seStockDown	= seStockUp + 1,
	seStockChanged	= seStockDown + 1,
	seWeather1	= seStockChanged + 1,
	seWeather2	= seWeather1 + 1,
	seWeather3	= seWeather2 + 1,
	seWeather4	= seWeather3 + 1,
	seWeather5	= seWeather4 + 1,
	seWeather6	= seWeather5 + 1,
	seWeather7	= seWeather6 + 1,
	seWeather8	= seWeather7 + 1,
	seWeather9	= seWeather8 + 1,
	seWeather10	= seWeather9 + 1,
	seWeather11	= seWeather10 + 1,
	seWeather12	= seWeather11 + 1,
	seWeather13	= seWeather12 + 1,
	seWeather14	= seWeather13 + 1,
	seWeather15	= seWeather14 + 1,
	seWeather16	= seWeather15 + 1,
	seWeather17	= seWeather16 + 1,
	seWeather18	= seWeather17 + 1,
	seWeather19	= seWeather18 + 1,
	seWeather20	= seWeather19 + 1,
	seWeather21	= seWeather20 + 1,
	seWeather22	= seWeather21 + 1,
	seWeather23	= seWeather22 + 1,
	seWeather24	= seWeather23 + 1,
	seWeather25	= seWeather24 + 1,
	seWeather26	= seWeather25 + 1,
	seWeather27	= seWeather26 + 1,
	seWeather28	= seWeather27 + 1,
	seWeather29	= seWeather28 + 1,
	seWeather30	= seWeather29 + 1,
	seWeather31	= seWeather30 + 1,
	seWeather32	= seWeather31 + 1,
	seWeather33	= seWeather32 + 1,
	seWeather34	= seWeather33 + 1,
	seWeather35	= seWeather34 + 1,
	seWeather36	= seWeather35 + 1,
	seWeather37	= seWeather36 + 1,
	seWeather38	= seWeather37 + 1,
	seWeather39	= seWeather38 + 1,
	seWeather40	= seWeather39 + 1,
	seWeather41	= seWeather40 + 1,
	seWeather42	= seWeather41 + 1,
	seWeather43	= seWeather42 + 1,
	seWeather44	= seWeather43 + 1,
	seWeather45	= seWeather44 + 1,
	seWeather46	= seWeather45 + 1,
	seWeather47	= seWeather46 + 1,
	seWeatherLogo	= seWeather47 + 1,
	seSliderBar	= seWeatherLogo + 1,
	seSliderButton	= seSliderBar + 1,
	seVolumeMute	= seSliderButton + 1,
	seMPMuted	= seVolumeMute + 1,
	seVolumeMuted	= seMPMuted + 1,
	seMarkedHeadline	= seVolumeMuted + 1,
	seEmptyBackground	= seMarkedHeadline + 1,
	seMirroredEmptyBackground	= seEmptyBackground + 1,
	seCollapsedCaption	= seMirroredEmptyBackground + 1,
	seStartCaption	= seCollapsedCaption + 1,
	seStartButton	= seStartCaption + 1,
	seScrollUp	= seStartButton + 1,
	seScrollDown	= seScrollUp + 1,
	seCaptionIcon	= seScrollDown + 1,
	seMinClockHand	= seCaptionIcon + 1,
	seSecClockHand	= seMinClockHand + 1,
	seStackMirroredBackground	= seSecClockHand + 1,
	seMIMOnlineIcon	= seStackMirroredBackground + 1,
	seMIMOfflineIcon	= seMIMOnlineIcon + 1,
	seMIMBusyIcon	= seMIMOfflineIcon + 1,
	seMIMAwayIcon	= seMIMBusyIcon + 1,
	seMIMOutToLunchIcon	= seMIMAwayIcon + 1,
	seMIMOnThePhoneIcon	= seMIMOutToLunchIcon + 1,
	seMIMMSNOnlineIcon	= seMIMOnThePhoneIcon + 1,
	seMIMMSNOfflineIcon	= seMIMMSNOnlineIcon + 1,
	seMIMMSNBusyIcon	= seMIMMSNOfflineIcon + 1,
	seMIMMSNAwayIcon	= seMIMMSNBusyIcon + 1,
	seMIMMSNOutToLunchIcon	= seMIMMSNAwayIcon + 1,
	seMIMMSNOnThePhoneIcon	= seMIMMSNOutToLunchIcon + 1,
	seMIMICQOnlineIcon	= seMIMMSNOnThePhoneIcon + 1,
	seMIMICQOfflineIcon	= seMIMICQOnlineIcon + 1,
	seMIMICQBusyIcon	= seMIMICQOfflineIcon + 1,
	seMIMICQAwayIcon	= seMIMICQBusyIcon + 1,
	seMIMICQOutToLunchIcon	= seMIMICQAwayIcon + 1,
	seMIMICQOnThePhoneIcon	= seMIMICQOutToLunchIcon + 1,
	seMIMAIMOnlineIcon	= seMIMICQOnThePhoneIcon + 1,
	seMIMAIMOfflineIcon	= seMIMAIMOnlineIcon + 1,
	seMIMAIMBusyIcon	= seMIMAIMOfflineIcon + 1,
	seMIMAIMAwayIcon	= seMIMAIMBusyIcon + 1,
	seMIMAIMOutToLunchIcon	= seMIMAIMAwayIcon + 1,
	seMIMAIMOnThePhoneIcon	= seMIMAIMOutToLunchIcon + 1,
	seMIMYAHOOOnlineIcon	= seMIMAIMOnThePhoneIcon + 1,
	seMIMYAHOOOfflineIcon	= seMIMYAHOOOnlineIcon + 1,
	seMIMYAHOOBusyIcon	= seMIMYAHOOOfflineIcon + 1,
	seMIMYAHOOAwayIcon	= seMIMYAHOOBusyIcon + 1,
	seMIMYAHOOOutToLunchIcon	= seMIMYAHOOAwayIcon + 1,
	seMIMYAHOOOnThePhoneIcon	= seMIMYAHOOOutToLunchIcon + 1,
	seMIMJABBEROnlineIcon	= seMIMYAHOOOnThePhoneIcon + 1,
	seMIMJABBEROfflineIcon	= seMIMJABBEROnlineIcon + 1,
	seMIMJABBERBusyIcon	= seMIMJABBEROfflineIcon + 1,
	seMIMJABBERAwayIcon	= seMIMJABBERBusyIcon + 1,
	seMIMJABBEROutToLunchIcon	= seMIMJABBERAwayIcon + 1,
	seMIMJABBEROnThePhoneIcon	= seMIMJABBEROutToLunchIcon + 1,
	seLowPriorityTask	= seMIMJABBEROnThePhoneIcon + 1,
	seHighPriorityTask	= seLowPriorityTask + 1,
	seListScrollUp	= seHighPriorityTask + 1,
	seListScrollDown	= seListScrollUp + 1,
	seListScrollUpDisabled	= seListScrollDown + 1,
	seListScrollDownDisabled	= seListScrollUpDisabled + 1,
	seMIMInvisibleIcon	= seListScrollDownDisabled + 1,
	seMIMFreeForChatIcon	= seMIMInvisibleIcon + 1,
	seMIMNAIcon	= seMIMFreeForChatIcon + 1,
	seMIMDNDIcon	= seMIMNAIcon + 1,
	seMIMMSNInvisibleIcon	= seMIMDNDIcon + 1,
	seMIMMSNFreeForChatIcon	= seMIMMSNInvisibleIcon + 1,
	seMIMMSNNAIcon	= seMIMMSNFreeForChatIcon + 1,
	seMIMMSNDNDIcon	= seMIMMSNNAIcon + 1,
	seMIMICQInvisibleIcon	= seMIMMSNDNDIcon + 1,
	seMIMICQFreeForChatIcon	= seMIMICQInvisibleIcon + 1,
	seMIMICQNAIcon	= seMIMICQFreeForChatIcon + 1,
	seMIMICQDNDIcon	= seMIMICQNAIcon + 1,
	seMIMAIMInvisibleIcon	= seMIMICQDNDIcon + 1,
	seMIMAIMFreeForChatIcon	= seMIMAIMInvisibleIcon + 1,
	seMIMAIMNAIcon	= seMIMAIMFreeForChatIcon + 1,
	seMIMAIMDNDIcon	= seMIMAIMNAIcon + 1,
	seMIMYAHOOInvisibleIcon	= seMIMAIMDNDIcon + 1,
	seMIMYAHOOFreeForChatIcon	= seMIMYAHOOInvisibleIcon + 1,
	seMIMYAHOONAIcon	= seMIMYAHOOFreeForChatIcon + 1,
	seMIMYAHOODNDIcon	= seMIMYAHOONAIcon + 1,
	seMIMJABBERInvisibleIcon	= seMIMYAHOODNDIcon + 1,
	seMIMJABBERFreeForChatIcon	= seMIMJABBERInvisibleIcon + 1,
	seMIMJABBERNAIcon	= seMIMJABBERFreeForChatIcon + 1,
	seMIMJABBERDNDIcon	= seMIMJABBERNAIcon + 1,
	sePopupDrag	= seMIMJABBERDNDIcon + 1,
	sePopupResize	= sePopupDrag + 1,
	sePopupBackground	= sePopupResize + 1,
	seGraphChart	= sePopupBackground + 1,
	seGraphChartBackground	= seGraphChart + 1,
	seHistogramChart	= seGraphChartBackground + 1,
	seHistogramChartBackground	= seHistogramChart + 1,
	seProgressChart	= seHistogramChartBackground + 1,
	seProgressChartBackground	= seProgressChart + 1,
	seAnalogChart	= seProgressChartBackground + 1,
	seAnalogChartBackground	= seAnalogChart + 1,
	sePerfPieChart	= seAnalogChartBackground + 1,
	sePerfPieChartBackground	= sePerfPieChart + 1,
	seTextChart	= sePerfPieChartBackground + 1,
	seTextChartBackground	= seTextChart + 1,
	seDefaultbutton	= seTextChartBackground + 1,
	seMIMTLENOnlineIcon	= seDefaultbutton + 1,
	seMIMTLENOfflineIcon	= seMIMTLENOnlineIcon + 1,
	seMIMTLENBusyIcon	= seMIMTLENOfflineIcon + 1,
	seMIMTLENAwayIcon	= seMIMTLENBusyIcon + 1,
	seMIMTLENOutToLunchIcon	= seMIMTLENAwayIcon + 1,
	seMIMTLENOnThePhoneIcon	= seMIMTLENOutToLunchIcon + 1,
	seMIMTLENInvisibleIcon	= seMIMTLENOnThePhoneIcon + 1,
	seMIMTLENFreeForChatIcon	= seMIMTLENInvisibleIcon + 1,
	seMIMTLENNAIcon	= seMIMTLENFreeForChatIcon + 1,
	seMIMTLENDNDIcon	= seMIMTLENNAIcon + 1,
	seMIMGGOnlineIcon	= seMIMTLENDNDIcon + 1,
	seMIMGGOfflineIcon	= seMIMGGOnlineIcon + 1,
	seMIMGGBusyIcon	= seMIMGGOfflineIcon + 1,
	seMIMGGAwayIcon	= seMIMGGBusyIcon + 1,
	seMIMGGOutToLunchIcon	= seMIMGGAwayIcon + 1,
	seMIMGGOnThePhoneIcon	= seMIMGGOutToLunchIcon + 1,
	seMIMGGInvisibleIcon	= seMIMGGOnThePhoneIcon + 1,
	seMIMGGFreeForChatIcon	= seMIMGGInvisibleIcon + 1,
	seMIMGGNAIcon	= seMIMGGFreeForChatIcon + 1,
	seMIMGGDNDIcon	= seMIMGGNAIcon + 1,
	seAlertClose	= seMIMGGDNDIcon + 1,
	seMonthlyView	= seAlertClose + 1,
	seMonthlyViewOtherMonths	= seMonthlyView + 1,
	seMonthlyViewAppointments	= seMonthlyViewOtherMonths + 1,
	seMonthlyViewOtherMonthsAppointments	= seMonthlyViewAppointments + 1,
	seScrollLeft	= seMonthlyViewOtherMonthsAppointments + 1,
	seScrollRight	= seScrollLeft + 1,
	seScrollLeftDisabled	= seScrollRight + 1,
	seScrollRightDisabled	= seScrollLeftDisabled + 1,
	seMonthlyViewCurrentDay	= seScrollRightDisabled + 1,
	seMonthlyViewCurrentDayAppointments	= seMonthlyViewCurrentDay + 1,
	seMonthlyViewWeeks	= seMonthlyViewCurrentDayAppointments + 1,
	seNoNewMail	= seMonthlyViewWeeks + 1,
	seNewMail	= seNoNewMail + 1,
	seMoreDetailsBtn	= seNewMail + 1,
	seLast	= seMoreDetailsBtn + 1
    } ;

enum ETextAlign
    {	Left	= 0,
	Right	= Left + 1,
	Center	= Right + 1,
	Hidden	= Center + 1
    } ;

enum ESkinButtonStyle
    {	sbsNormal	= 0,
	sbsContinuousClick	= sbsNormal + 1
    } ;
#ifndef _WINGDI_
typedef struct tagLOGFONTA
    {
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    CHAR lfFaceName[ 32 ];
    } 	LOGFONTA;

typedef struct tagLOGFONTW
    {
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    WCHAR lfFaceName[ 32 ];
    } 	LOGFONTW;

typedef LOGFONTA LOGFONT;

#endif

enum EOutlineStyle
    {	EFlat	= 0,
	ESunken	= EFlat + 1,
	ERaised	= ESunken + 1,
	EBump	= ERaised + 1,
	ENone	= EBump + 1
    } ;

enum EFillStyle
    {	ESolid	= 0,
	EGradient	= ESolid + 1,
	EHollow	= EGradient + 1,
	EBitmap	= EHollow + 1,
	ECenterBitmap	= EBitmap + 1,
	EStretchBitmap	= ECenterBitmap + 1,
	ETiledBitmap	= EStretchBitmap + 1
    } ;

enum EFontStyle
    {	FSNormal	= 0,
	FSBold	= 1,
	FSItalic	= 2,
	FSUnderline	= 4,
	FSStrikeout	= 8,
	FSBoldItalic	= FSBold | FSItalic,
	FSBoldUnderline	= FSBold | FSUnderline,
	FSStrikeoutUnderline	= FSStrikeout | FSUnderline
    } ;

enum ETextVAlign
    {	ETop	= 0,
	EBottom	= ETop + 1,
	EMiddle	= EBottom + 1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0265_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0265_v0_0_s_ifspec;

#ifndef __ISkinElement_INTERFACE_DEFINED__
#define __ISkinElement_INTERFACE_DEFINED__

/* interface ISkinElement */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinElement;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("946FDD08-E5EC-49e1-AFEF-79F581C3B7C4")
    ISkinElement : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE DrawText( 
            IGraphics *graphics,
            const RECT *rect,
            BSTR text,
            int *tabs,
            int tabsCount,
            VARIANT_BOOL rightToLeft) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawMultilineText( 
            IGraphics *graphics,
            const RECT *rect,
            BSTR text,
            VARIANT_BOOL rightToLeft) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawRect( 
            IGraphics *graphics,
            const RECT *rect,
            IUnknown *panelParent,
            int cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Fill( 
            IGraphics *graphics,
            const RECT *skinRect,
            const RECT *targetRect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Outline( 
            IGraphics *graphics,
            const RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAlign( 
            /* [retval][out] */ enum ETextAlign *align) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetOutlineColor( 
            /* [retval][out] */ DWORD *argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFillColor( 
            /* [retval][out] */ DWORD *argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFillColor2( 
            /* [retval][out] */ DWORD *argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsHollow( 
            /* [retval][out] */ VARIANT_BOOL *hollow) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMetrics( 
            BSTR metrics,
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSize( 
            BSTR metrics,
            /* [retval][out] */ SIZE *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPoint( 
            BSTR metrics,
            /* [retval][out] */ POINT *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetImageSize( 
            /* [retval][out] */ SIZE *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetImagePath( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFontFamily( 
            /* [retval][out] */ BSTR *name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFontSize( 
            /* [retval][out] */ int *size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFontStyle( 
            /* [retval][out] */ int *style) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetLogFont( 
            /* [retval][out] */ LOGFONT *logfont) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTextColor( 
            /* [retval][out] */ DWORD *argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFontHeight( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTextSize( 
            BSTR text,
            /* [retval][out] */ SIZE *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTextMargin( 
            /* [retval][out] */ RECT *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTextHeight( 
            BSTR text,
            int width,
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetVAlign( 
            /* [retval][out] */ enum ETextVAlign *align) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetOutlineStyle( 
            /* [retval][out] */ enum EOutlineStyle *style) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetOutlineWidth( 
            /* [retval][out] */ int *wdith) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFillStyle( 
            /* [retval][out] */ enum EFillStyle *style) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetImageMargins( 
            /* [out] */ int *left,
            /* [out] */ int *top,
            /* [out] */ int *right,
            /* [out] */ int *bottom) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsDefined( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinElementVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinElement * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinElement * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinElement * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinElement * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinElement * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinElement * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinElement * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *DrawText )( 
            ISkinElement * This,
            IGraphics *graphics,
            const RECT *rect,
            BSTR text,
            int *tabs,
            int tabsCount,
            VARIANT_BOOL rightToLeft);
        
        HRESULT ( STDMETHODCALLTYPE *DrawMultilineText )( 
            ISkinElement * This,
            IGraphics *graphics,
            const RECT *rect,
            BSTR text,
            VARIANT_BOOL rightToLeft);
        
        HRESULT ( STDMETHODCALLTYPE *DrawRect )( 
            ISkinElement * This,
            IGraphics *graphics,
            const RECT *rect,
            IUnknown *panelParent,
            int cookie);
        
        HRESULT ( STDMETHODCALLTYPE *Fill )( 
            ISkinElement * This,
            IGraphics *graphics,
            const RECT *skinRect,
            const RECT *targetRect);
        
        HRESULT ( STDMETHODCALLTYPE *Outline )( 
            ISkinElement * This,
            IGraphics *graphics,
            const RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *GetAlign )( 
            ISkinElement * This,
            /* [retval][out] */ enum ETextAlign *align);
        
        HRESULT ( STDMETHODCALLTYPE *GetOutlineColor )( 
            ISkinElement * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *GetFillColor )( 
            ISkinElement * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *GetFillColor2 )( 
            ISkinElement * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *IsHollow )( 
            ISkinElement * This,
            /* [retval][out] */ VARIANT_BOOL *hollow);
        
        HRESULT ( STDMETHODCALLTYPE *GetMetrics )( 
            ISkinElement * This,
            BSTR metrics,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            ISkinElement * This,
            BSTR metrics,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetPoint )( 
            ISkinElement * This,
            BSTR metrics,
            /* [retval][out] */ POINT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetImageSize )( 
            ISkinElement * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetImagePath )( 
            ISkinElement * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetFontFamily )( 
            ISkinElement * This,
            /* [retval][out] */ BSTR *name);
        
        HRESULT ( STDMETHODCALLTYPE *GetFontSize )( 
            ISkinElement * This,
            /* [retval][out] */ int *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetFontStyle )( 
            ISkinElement * This,
            /* [retval][out] */ int *style);
        
        HRESULT ( STDMETHODCALLTYPE *GetLogFont )( 
            ISkinElement * This,
            /* [retval][out] */ LOGFONT *logfont);
        
        HRESULT ( STDMETHODCALLTYPE *GetTextColor )( 
            ISkinElement * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *GetFontHeight )( 
            ISkinElement * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetTextSize )( 
            ISkinElement * This,
            BSTR text,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetTextMargin )( 
            ISkinElement * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetTextHeight )( 
            ISkinElement * This,
            BSTR text,
            int width,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetVAlign )( 
            ISkinElement * This,
            /* [retval][out] */ enum ETextVAlign *align);
        
        HRESULT ( STDMETHODCALLTYPE *GetOutlineStyle )( 
            ISkinElement * This,
            /* [retval][out] */ enum EOutlineStyle *style);
        
        HRESULT ( STDMETHODCALLTYPE *GetOutlineWidth )( 
            ISkinElement * This,
            /* [retval][out] */ int *wdith);
        
        HRESULT ( STDMETHODCALLTYPE *GetFillStyle )( 
            ISkinElement * This,
            /* [retval][out] */ enum EFillStyle *style);
        
        HRESULT ( STDMETHODCALLTYPE *GetImageMargins )( 
            ISkinElement * This,
            /* [out] */ int *left,
            /* [out] */ int *top,
            /* [out] */ int *right,
            /* [out] */ int *bottom);
        
        HRESULT ( STDMETHODCALLTYPE *IsDefined )( 
            ISkinElement * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        END_INTERFACE
    } ISkinElementVtbl;

    interface ISkinElement
    {
        CONST_VTBL struct ISkinElementVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinElement_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinElement_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinElement_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinElement_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinElement_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinElement_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinElement_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinElement_DrawText(This,graphics,rect,text,tabs,tabsCount,rightToLeft)	\
    (This)->lpVtbl -> DrawText(This,graphics,rect,text,tabs,tabsCount,rightToLeft)

#define ISkinElement_DrawMultilineText(This,graphics,rect,text,rightToLeft)	\
    (This)->lpVtbl -> DrawMultilineText(This,graphics,rect,text,rightToLeft)

#define ISkinElement_DrawRect(This,graphics,rect,panelParent,cookie)	\
    (This)->lpVtbl -> DrawRect(This,graphics,rect,panelParent,cookie)

#define ISkinElement_Fill(This,graphics,skinRect,targetRect)	\
    (This)->lpVtbl -> Fill(This,graphics,skinRect,targetRect)

#define ISkinElement_Outline(This,graphics,rect)	\
    (This)->lpVtbl -> Outline(This,graphics,rect)

#define ISkinElement_GetAlign(This,align)	\
    (This)->lpVtbl -> GetAlign(This,align)

#define ISkinElement_GetOutlineColor(This,argb)	\
    (This)->lpVtbl -> GetOutlineColor(This,argb)

#define ISkinElement_GetFillColor(This,argb)	\
    (This)->lpVtbl -> GetFillColor(This,argb)

#define ISkinElement_GetFillColor2(This,argb)	\
    (This)->lpVtbl -> GetFillColor2(This,argb)

#define ISkinElement_IsHollow(This,hollow)	\
    (This)->lpVtbl -> IsHollow(This,hollow)

#define ISkinElement_GetMetrics(This,metrics,retVal)	\
    (This)->lpVtbl -> GetMetrics(This,metrics,retVal)

#define ISkinElement_GetSize(This,metrics,retVal)	\
    (This)->lpVtbl -> GetSize(This,metrics,retVal)

#define ISkinElement_GetPoint(This,metrics,retVal)	\
    (This)->lpVtbl -> GetPoint(This,metrics,retVal)

#define ISkinElement_GetImageSize(This,retVal)	\
    (This)->lpVtbl -> GetImageSize(This,retVal)

#define ISkinElement_GetImagePath(This,retVal)	\
    (This)->lpVtbl -> GetImagePath(This,retVal)

#define ISkinElement_GetFontFamily(This,name)	\
    (This)->lpVtbl -> GetFontFamily(This,name)

#define ISkinElement_GetFontSize(This,size)	\
    (This)->lpVtbl -> GetFontSize(This,size)

#define ISkinElement_GetFontStyle(This,style)	\
    (This)->lpVtbl -> GetFontStyle(This,style)

#define ISkinElement_GetLogFont(This,logfont)	\
    (This)->lpVtbl -> GetLogFont(This,logfont)

#define ISkinElement_GetTextColor(This,argb)	\
    (This)->lpVtbl -> GetTextColor(This,argb)

#define ISkinElement_GetFontHeight(This,retVal)	\
    (This)->lpVtbl -> GetFontHeight(This,retVal)

#define ISkinElement_GetTextSize(This,text,retVal)	\
    (This)->lpVtbl -> GetTextSize(This,text,retVal)

#define ISkinElement_GetTextMargin(This,retVal)	\
    (This)->lpVtbl -> GetTextMargin(This,retVal)

#define ISkinElement_GetTextHeight(This,text,width,retVal)	\
    (This)->lpVtbl -> GetTextHeight(This,text,width,retVal)

#define ISkinElement_GetVAlign(This,align)	\
    (This)->lpVtbl -> GetVAlign(This,align)

#define ISkinElement_GetOutlineStyle(This,style)	\
    (This)->lpVtbl -> GetOutlineStyle(This,style)

#define ISkinElement_GetOutlineWidth(This,wdith)	\
    (This)->lpVtbl -> GetOutlineWidth(This,wdith)

#define ISkinElement_GetFillStyle(This,style)	\
    (This)->lpVtbl -> GetFillStyle(This,style)

#define ISkinElement_GetImageMargins(This,left,top,right,bottom)	\
    (This)->lpVtbl -> GetImageMargins(This,left,top,right,bottom)

#define ISkinElement_IsDefined(This,retVal)	\
    (This)->lpVtbl -> IsDefined(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinElement_DrawText_Proxy( 
    ISkinElement * This,
    IGraphics *graphics,
    const RECT *rect,
    BSTR text,
    int *tabs,
    int tabsCount,
    VARIANT_BOOL rightToLeft);


void __RPC_STUB ISkinElement_DrawText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_DrawMultilineText_Proxy( 
    ISkinElement * This,
    IGraphics *graphics,
    const RECT *rect,
    BSTR text,
    VARIANT_BOOL rightToLeft);


void __RPC_STUB ISkinElement_DrawMultilineText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_DrawRect_Proxy( 
    ISkinElement * This,
    IGraphics *graphics,
    const RECT *rect,
    IUnknown *panelParent,
    int cookie);


void __RPC_STUB ISkinElement_DrawRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_Fill_Proxy( 
    ISkinElement * This,
    IGraphics *graphics,
    const RECT *skinRect,
    const RECT *targetRect);


void __RPC_STUB ISkinElement_Fill_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_Outline_Proxy( 
    ISkinElement * This,
    IGraphics *graphics,
    const RECT *rect);


void __RPC_STUB ISkinElement_Outline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetAlign_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ enum ETextAlign *align);


void __RPC_STUB ISkinElement_GetAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetOutlineColor_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ DWORD *argb);


void __RPC_STUB ISkinElement_GetOutlineColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFillColor_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ DWORD *argb);


void __RPC_STUB ISkinElement_GetFillColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFillColor2_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ DWORD *argb);


void __RPC_STUB ISkinElement_GetFillColor2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_IsHollow_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ VARIANT_BOOL *hollow);


void __RPC_STUB ISkinElement_IsHollow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetMetrics_Proxy( 
    ISkinElement * This,
    BSTR metrics,
    /* [retval][out] */ int *retVal);


void __RPC_STUB ISkinElement_GetMetrics_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetSize_Proxy( 
    ISkinElement * This,
    BSTR metrics,
    /* [retval][out] */ SIZE *retVal);


void __RPC_STUB ISkinElement_GetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetPoint_Proxy( 
    ISkinElement * This,
    BSTR metrics,
    /* [retval][out] */ POINT *retVal);


void __RPC_STUB ISkinElement_GetPoint_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetImageSize_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ SIZE *retVal);


void __RPC_STUB ISkinElement_GetImageSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetImagePath_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ISkinElement_GetImagePath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFontFamily_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ BSTR *name);


void __RPC_STUB ISkinElement_GetFontFamily_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFontSize_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ int *size);


void __RPC_STUB ISkinElement_GetFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFontStyle_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ int *style);


void __RPC_STUB ISkinElement_GetFontStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetLogFont_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ LOGFONT *logfont);


void __RPC_STUB ISkinElement_GetLogFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetTextColor_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ DWORD *argb);


void __RPC_STUB ISkinElement_GetTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFontHeight_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB ISkinElement_GetFontHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetTextSize_Proxy( 
    ISkinElement * This,
    BSTR text,
    /* [retval][out] */ SIZE *retVal);


void __RPC_STUB ISkinElement_GetTextSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetTextMargin_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ RECT *retVal);


void __RPC_STUB ISkinElement_GetTextMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetTextHeight_Proxy( 
    ISkinElement * This,
    BSTR text,
    int width,
    /* [retval][out] */ int *retVal);


void __RPC_STUB ISkinElement_GetTextHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetVAlign_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ enum ETextVAlign *align);


void __RPC_STUB ISkinElement_GetVAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetOutlineStyle_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ enum EOutlineStyle *style);


void __RPC_STUB ISkinElement_GetOutlineStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetOutlineWidth_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ int *wdith);


void __RPC_STUB ISkinElement_GetOutlineWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetFillStyle_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ enum EFillStyle *style);


void __RPC_STUB ISkinElement_GetFillStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_GetImageMargins_Proxy( 
    ISkinElement * This,
    /* [out] */ int *left,
    /* [out] */ int *top,
    /* [out] */ int *right,
    /* [out] */ int *bottom);


void __RPC_STUB ISkinElement_GetImageMargins_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElement_IsDefined_Proxy( 
    ISkinElement * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB ISkinElement_IsDefined_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinElement_INTERFACE_DEFINED__ */


#ifndef __ISkinElementCreate_INTERFACE_DEFINED__
#define __ISkinElementCreate_INTERFACE_DEFINED__

/* interface ISkinElementCreate */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinElementCreate;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("86323934-EE36-422b-8997-D011BF73A886")
    ISkinElementCreate : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetOutlineStyle( 
            enum EOutlineStyle outline) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetOutlineColor( 
            DWORD argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetOutlineWidth( 
            int width) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFillStyle( 
            enum EFillStyle fill) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFillColor( 
            DWORD argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFillColor2( 
            DWORD argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetImagePath( 
            BSTR path) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetImageMargins( 
            int left,
            int top,
            int right,
            int bottom) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFontFamily( 
            BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFontSize( 
            int size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFontStyle( 
            enum EFontStyle style) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTextColor( 
            DWORD argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetAlign( 
            enum ETextAlign align) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetVAlign( 
            enum ETextVAlign align) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinElementCreateVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinElementCreate * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinElementCreate * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinElementCreate * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinElementCreate * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinElementCreate * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinElementCreate * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinElementCreate * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *SetOutlineStyle )( 
            ISkinElementCreate * This,
            enum EOutlineStyle outline);
        
        HRESULT ( STDMETHODCALLTYPE *SetOutlineColor )( 
            ISkinElementCreate * This,
            DWORD argb);
        
        HRESULT ( STDMETHODCALLTYPE *SetOutlineWidth )( 
            ISkinElementCreate * This,
            int width);
        
        HRESULT ( STDMETHODCALLTYPE *SetFillStyle )( 
            ISkinElementCreate * This,
            enum EFillStyle fill);
        
        HRESULT ( STDMETHODCALLTYPE *SetFillColor )( 
            ISkinElementCreate * This,
            DWORD argb);
        
        HRESULT ( STDMETHODCALLTYPE *SetFillColor2 )( 
            ISkinElementCreate * This,
            DWORD argb);
        
        HRESULT ( STDMETHODCALLTYPE *SetImagePath )( 
            ISkinElementCreate * This,
            BSTR path);
        
        HRESULT ( STDMETHODCALLTYPE *SetImageMargins )( 
            ISkinElementCreate * This,
            int left,
            int top,
            int right,
            int bottom);
        
        HRESULT ( STDMETHODCALLTYPE *SetFontFamily )( 
            ISkinElementCreate * This,
            BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *SetFontSize )( 
            ISkinElementCreate * This,
            int size);
        
        HRESULT ( STDMETHODCALLTYPE *SetFontStyle )( 
            ISkinElementCreate * This,
            enum EFontStyle style);
        
        HRESULT ( STDMETHODCALLTYPE *SetTextColor )( 
            ISkinElementCreate * This,
            DWORD argb);
        
        HRESULT ( STDMETHODCALLTYPE *SetAlign )( 
            ISkinElementCreate * This,
            enum ETextAlign align);
        
        HRESULT ( STDMETHODCALLTYPE *SetVAlign )( 
            ISkinElementCreate * This,
            enum ETextVAlign align);
        
        END_INTERFACE
    } ISkinElementCreateVtbl;

    interface ISkinElementCreate
    {
        CONST_VTBL struct ISkinElementCreateVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinElementCreate_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinElementCreate_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinElementCreate_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinElementCreate_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinElementCreate_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinElementCreate_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinElementCreate_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinElementCreate_SetOutlineStyle(This,outline)	\
    (This)->lpVtbl -> SetOutlineStyle(This,outline)

#define ISkinElementCreate_SetOutlineColor(This,argb)	\
    (This)->lpVtbl -> SetOutlineColor(This,argb)

#define ISkinElementCreate_SetOutlineWidth(This,width)	\
    (This)->lpVtbl -> SetOutlineWidth(This,width)

#define ISkinElementCreate_SetFillStyle(This,fill)	\
    (This)->lpVtbl -> SetFillStyle(This,fill)

#define ISkinElementCreate_SetFillColor(This,argb)	\
    (This)->lpVtbl -> SetFillColor(This,argb)

#define ISkinElementCreate_SetFillColor2(This,argb)	\
    (This)->lpVtbl -> SetFillColor2(This,argb)

#define ISkinElementCreate_SetImagePath(This,path)	\
    (This)->lpVtbl -> SetImagePath(This,path)

#define ISkinElementCreate_SetImageMargins(This,left,top,right,bottom)	\
    (This)->lpVtbl -> SetImageMargins(This,left,top,right,bottom)

#define ISkinElementCreate_SetFontFamily(This,name)	\
    (This)->lpVtbl -> SetFontFamily(This,name)

#define ISkinElementCreate_SetFontSize(This,size)	\
    (This)->lpVtbl -> SetFontSize(This,size)

#define ISkinElementCreate_SetFontStyle(This,style)	\
    (This)->lpVtbl -> SetFontStyle(This,style)

#define ISkinElementCreate_SetTextColor(This,argb)	\
    (This)->lpVtbl -> SetTextColor(This,argb)

#define ISkinElementCreate_SetAlign(This,align)	\
    (This)->lpVtbl -> SetAlign(This,align)

#define ISkinElementCreate_SetVAlign(This,align)	\
    (This)->lpVtbl -> SetVAlign(This,align)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetOutlineStyle_Proxy( 
    ISkinElementCreate * This,
    enum EOutlineStyle outline);


void __RPC_STUB ISkinElementCreate_SetOutlineStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetOutlineColor_Proxy( 
    ISkinElementCreate * This,
    DWORD argb);


void __RPC_STUB ISkinElementCreate_SetOutlineColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetOutlineWidth_Proxy( 
    ISkinElementCreate * This,
    int width);


void __RPC_STUB ISkinElementCreate_SetOutlineWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFillStyle_Proxy( 
    ISkinElementCreate * This,
    enum EFillStyle fill);


void __RPC_STUB ISkinElementCreate_SetFillStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFillColor_Proxy( 
    ISkinElementCreate * This,
    DWORD argb);


void __RPC_STUB ISkinElementCreate_SetFillColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFillColor2_Proxy( 
    ISkinElementCreate * This,
    DWORD argb);


void __RPC_STUB ISkinElementCreate_SetFillColor2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetImagePath_Proxy( 
    ISkinElementCreate * This,
    BSTR path);


void __RPC_STUB ISkinElementCreate_SetImagePath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetImageMargins_Proxy( 
    ISkinElementCreate * This,
    int left,
    int top,
    int right,
    int bottom);


void __RPC_STUB ISkinElementCreate_SetImageMargins_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFontFamily_Proxy( 
    ISkinElementCreate * This,
    BSTR name);


void __RPC_STUB ISkinElementCreate_SetFontFamily_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFontSize_Proxy( 
    ISkinElementCreate * This,
    int size);


void __RPC_STUB ISkinElementCreate_SetFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetFontStyle_Proxy( 
    ISkinElementCreate * This,
    enum EFontStyle style);


void __RPC_STUB ISkinElementCreate_SetFontStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetTextColor_Proxy( 
    ISkinElementCreate * This,
    DWORD argb);


void __RPC_STUB ISkinElementCreate_SetTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetAlign_Proxy( 
    ISkinElementCreate * This,
    enum ETextAlign align);


void __RPC_STUB ISkinElementCreate_SetAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinElementCreate_SetVAlign_Proxy( 
    ISkinElementCreate * This,
    enum ETextVAlign align);


void __RPC_STUB ISkinElementCreate_SetVAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinElementCreate_INTERFACE_DEFINED__ */


#ifndef __ISkinManager_INTERFACE_DEFINED__
#define __ISkinManager_INTERFACE_DEFINED__

/* interface ISkinManager */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6A707A25-9820-4a79-A6F5-DE811BA17959")
    ISkinManager : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Get( 
            int skinItem,
            enum ESkinState state,
            /* [retval][out] */ ISkinElement **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCustom( 
            BSTR elementName,
            enum ESkinState state,
            /* [retval][out] */ ISkinElement **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Name2Id( 
            BSTR elementName,
            /* [retval][out] */ int *elementId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int skinItem,
            enum ESkinState state,
            /* [retval][out] */ ISkinElementCreate **element) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Insert( 
            ISkinElementCreate *normal,
            ISkinElementCreate *hover,
            ISkinElementCreate *pressed,
            ISkinElementCreate *undocked,
            /* [retval][out] */ int *elementId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Remove( 
            int elementId) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinManager * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinManager * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinManager * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinManager * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinManager * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinManager * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinManager * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Get )( 
            ISkinManager * This,
            int skinItem,
            enum ESkinState state,
            /* [retval][out] */ ISkinElement **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetCustom )( 
            ISkinManager * This,
            BSTR elementName,
            enum ESkinState state,
            /* [retval][out] */ ISkinElement **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Name2Id )( 
            ISkinManager * This,
            BSTR elementName,
            /* [retval][out] */ int *elementId);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ISkinManager * This,
            int skinItem,
            enum ESkinState state,
            /* [retval][out] */ ISkinElementCreate **element);
        
        HRESULT ( STDMETHODCALLTYPE *Insert )( 
            ISkinManager * This,
            ISkinElementCreate *normal,
            ISkinElementCreate *hover,
            ISkinElementCreate *pressed,
            ISkinElementCreate *undocked,
            /* [retval][out] */ int *elementId);
        
        HRESULT ( STDMETHODCALLTYPE *Remove )( 
            ISkinManager * This,
            int elementId);
        
        END_INTERFACE
    } ISkinManagerVtbl;

    interface ISkinManager
    {
        CONST_VTBL struct ISkinManagerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinManager_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinManager_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinManager_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinManager_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinManager_Get(This,skinItem,state,retVal)	\
    (This)->lpVtbl -> Get(This,skinItem,state,retVal)

#define ISkinManager_GetCustom(This,elementName,state,retVal)	\
    (This)->lpVtbl -> GetCustom(This,elementName,state,retVal)

#define ISkinManager_Name2Id(This,elementName,elementId)	\
    (This)->lpVtbl -> Name2Id(This,elementName,elementId)

#define ISkinManager_Create(This,skinItem,state,element)	\
    (This)->lpVtbl -> Create(This,skinItem,state,element)

#define ISkinManager_Insert(This,normal,hover,pressed,undocked,elementId)	\
    (This)->lpVtbl -> Insert(This,normal,hover,pressed,undocked,elementId)

#define ISkinManager_Remove(This,elementId)	\
    (This)->lpVtbl -> Remove(This,elementId)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinManager_Get_Proxy( 
    ISkinManager * This,
    int skinItem,
    enum ESkinState state,
    /* [retval][out] */ ISkinElement **retVal);


void __RPC_STUB ISkinManager_Get_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinManager_GetCustom_Proxy( 
    ISkinManager * This,
    BSTR elementName,
    enum ESkinState state,
    /* [retval][out] */ ISkinElement **retVal);


void __RPC_STUB ISkinManager_GetCustom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinManager_Name2Id_Proxy( 
    ISkinManager * This,
    BSTR elementName,
    /* [retval][out] */ int *elementId);


void __RPC_STUB ISkinManager_Name2Id_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinManager_Create_Proxy( 
    ISkinManager * This,
    int skinItem,
    enum ESkinState state,
    /* [retval][out] */ ISkinElementCreate **element);


void __RPC_STUB ISkinManager_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinManager_Insert_Proxy( 
    ISkinManager * This,
    ISkinElementCreate *normal,
    ISkinElementCreate *hover,
    ISkinElementCreate *pressed,
    ISkinElementCreate *undocked,
    /* [retval][out] */ int *elementId);


void __RPC_STUB ISkinManager_Insert_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinManager_Remove_Proxy( 
    ISkinManager * This,
    int elementId);


void __RPC_STUB ISkinManager_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinManager_INTERFACE_DEFINED__ */


#ifndef __IAlert_INTERFACE_DEFINED__
#define __IAlert_INTERFACE_DEFINED__

/* interface IAlert */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAlert;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("11EADD89-F78F-406b-A809-232BB800DFFC")
    IAlert : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetText( 
            /* [retval][out] */ BSTR *text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetIcon( 
            /* [retval][out] */ int *skinItem) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAlertVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAlert * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAlert * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAlert * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAlert * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAlert * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAlert * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAlert * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetText )( 
            IAlert * This,
            /* [retval][out] */ BSTR *text);
        
        HRESULT ( STDMETHODCALLTYPE *GetIcon )( 
            IAlert * This,
            /* [retval][out] */ int *skinItem);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            IAlert * This);
        
        END_INTERFACE
    } IAlertVtbl;

    interface IAlert
    {
        CONST_VTBL struct IAlertVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAlert_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAlert_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAlert_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAlert_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAlert_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAlert_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAlert_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAlert_GetText(This,text)	\
    (This)->lpVtbl -> GetText(This,text)

#define IAlert_GetIcon(This,skinItem)	\
    (This)->lpVtbl -> GetIcon(This,skinItem)

#define IAlert_OnClick(This)	\
    (This)->lpVtbl -> OnClick(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IAlert_GetText_Proxy( 
    IAlert * This,
    /* [retval][out] */ BSTR *text);


void __RPC_STUB IAlert_GetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IAlert_GetIcon_Proxy( 
    IAlert * This,
    /* [retval][out] */ int *skinItem);


void __RPC_STUB IAlert_GetIcon_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IAlert_OnClick_Proxy( 
    IAlert * This);


void __RPC_STUB IAlert_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAlert_INTERFACE_DEFINED__ */


#ifndef __IAlertManager_INTERFACE_DEFINED__
#define __IAlertManager_INTERFACE_DEFINED__

/* interface IAlertManager */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAlertManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B49E6CCF-736B-4bd6-A711-605D57B5BA00")
    IAlertManager : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ShowAlert( 
            int hwnd,
            IAlert *alert) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAlertManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAlertManager * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAlertManager * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAlertManager * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IAlertManager * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IAlertManager * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IAlertManager * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IAlertManager * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *ShowAlert )( 
            IAlertManager * This,
            int hwnd,
            IAlert *alert);
        
        END_INTERFACE
    } IAlertManagerVtbl;

    interface IAlertManager
    {
        CONST_VTBL struct IAlertManagerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAlertManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAlertManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAlertManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAlertManager_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAlertManager_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAlertManager_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAlertManager_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAlertManager_ShowAlert(This,hwnd,alert)	\
    (This)->lpVtbl -> ShowAlert(This,hwnd,alert)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IAlertManager_ShowAlert_Proxy( 
    IAlertManager * This,
    int hwnd,
    IAlert *alert);


void __RPC_STUB IAlertManager_ShowAlert_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAlertManager_INTERFACE_DEFINED__ */


#ifndef __IUpdateUI_INTERFACE_DEFINED__
#define __IUpdateUI_INTERFACE_DEFINED__

/* interface IUpdateUI */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUpdateUI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C2262F41-3162-46fc-92A8-F8EDCA0A2A76")
    IUpdateUI : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Remove( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetEnabled( 
            VARIANT_BOOL enable) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetChecked( 
            VARIANT_BOOL checked) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUpdateUIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IUpdateUI * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IUpdateUI * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IUpdateUI * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IUpdateUI * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IUpdateUI * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IUpdateUI * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IUpdateUI * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IUpdateUI * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetEnabled )( 
            IUpdateUI * This,
            VARIANT_BOOL enable);
        
        HRESULT ( STDMETHODCALLTYPE *SetChecked )( 
            IUpdateUI * This,
            VARIANT_BOOL checked);
        
        END_INTERFACE
    } IUpdateUIVtbl;

    interface IUpdateUI
    {
        CONST_VTBL struct IUpdateUIVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUpdateUI_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUpdateUI_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUpdateUI_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUpdateUI_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUpdateUI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUpdateUI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUpdateUI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUpdateUI_Remove(This)	\
    (This)->lpVtbl -> Remove(This)

#define IUpdateUI_SetEnabled(This,enable)	\
    (This)->lpVtbl -> SetEnabled(This,enable)

#define IUpdateUI_SetChecked(This,checked)	\
    (This)->lpVtbl -> SetChecked(This,checked)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IUpdateUI_Remove_Proxy( 
    IUpdateUI * This);


void __RPC_STUB IUpdateUI_Remove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IUpdateUI_SetEnabled_Proxy( 
    IUpdateUI * This,
    VARIANT_BOOL enable);


void __RPC_STUB IUpdateUI_SetEnabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IUpdateUI_SetChecked_Proxy( 
    IUpdateUI * This,
    VARIANT_BOOL checked);


void __RPC_STUB IUpdateUI_SetChecked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUpdateUI_INTERFACE_DEFINED__ */


#ifndef __ICommandTarget_INTERFACE_DEFINED__
#define __ICommandTarget_INTERFACE_DEFINED__

/* interface ICommandTarget */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICommandTarget;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("73C9FDC4-3E7C-4113-9544-11CAC329820B")
    ICommandTarget : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnCommand( 
            BSTR cmdName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnUpdateCommand( 
            BSTR cmdName,
            IUpdateUI *pAction) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnPrivateCommand( 
            int id) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnUpdatePrivateCommand( 
            int id,
            IUpdateUI *pAction) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPrivateCommandImage( 
            int id,
            /* [retval][out] */ int *image) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICommandTargetVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICommandTarget * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICommandTarget * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICommandTarget * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICommandTarget * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICommandTarget * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICommandTarget * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICommandTarget * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnCommand )( 
            ICommandTarget * This,
            BSTR cmdName);
        
        HRESULT ( STDMETHODCALLTYPE *OnUpdateCommand )( 
            ICommandTarget * This,
            BSTR cmdName,
            IUpdateUI *pAction);
        
        HRESULT ( STDMETHODCALLTYPE *OnPrivateCommand )( 
            ICommandTarget * This,
            int id);
        
        HRESULT ( STDMETHODCALLTYPE *OnUpdatePrivateCommand )( 
            ICommandTarget * This,
            int id,
            IUpdateUI *pAction);
        
        HRESULT ( STDMETHODCALLTYPE *GetPrivateCommandImage )( 
            ICommandTarget * This,
            int id,
            /* [retval][out] */ int *image);
        
        END_INTERFACE
    } ICommandTargetVtbl;

    interface ICommandTarget
    {
        CONST_VTBL struct ICommandTargetVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICommandTarget_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICommandTarget_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICommandTarget_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICommandTarget_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICommandTarget_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICommandTarget_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICommandTarget_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICommandTarget_OnCommand(This,cmdName)	\
    (This)->lpVtbl -> OnCommand(This,cmdName)

#define ICommandTarget_OnUpdateCommand(This,cmdName,pAction)	\
    (This)->lpVtbl -> OnUpdateCommand(This,cmdName,pAction)

#define ICommandTarget_OnPrivateCommand(This,id)	\
    (This)->lpVtbl -> OnPrivateCommand(This,id)

#define ICommandTarget_OnUpdatePrivateCommand(This,id,pAction)	\
    (This)->lpVtbl -> OnUpdatePrivateCommand(This,id,pAction)

#define ICommandTarget_GetPrivateCommandImage(This,id,image)	\
    (This)->lpVtbl -> GetPrivateCommandImage(This,id,image)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICommandTarget_OnCommand_Proxy( 
    ICommandTarget * This,
    BSTR cmdName);


void __RPC_STUB ICommandTarget_OnCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandTarget_OnUpdateCommand_Proxy( 
    ICommandTarget * This,
    BSTR cmdName,
    IUpdateUI *pAction);


void __RPC_STUB ICommandTarget_OnUpdateCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandTarget_OnPrivateCommand_Proxy( 
    ICommandTarget * This,
    int id);


void __RPC_STUB ICommandTarget_OnPrivateCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandTarget_OnUpdatePrivateCommand_Proxy( 
    ICommandTarget * This,
    int id,
    IUpdateUI *pAction);


void __RPC_STUB ICommandTarget_OnUpdatePrivateCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandTarget_GetPrivateCommandImage_Proxy( 
    ICommandTarget * This,
    int id,
    /* [retval][out] */ int *image);


void __RPC_STUB ICommandTarget_GetPrivateCommandImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICommandTarget_INTERFACE_DEFINED__ */


#ifndef __ICommandManager_INTERFACE_DEFINED__
#define __ICommandManager_INTERFACE_DEFINED__

/* interface ICommandManager */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICommandManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1AB9F19C-B078-4ed1-99D1-6CA71F70C2E3")
    ICommandManager : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE RegisterCommandTarget( 
            BSTR name,
            ICommandTarget *pTarget,
            /* [retval][out] */ int *cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterCommandTarget( 
            int cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AppendMenu( 
            HMENU hMenu,
            BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UpdateMenu( 
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            HMENU hMenu) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetupToolbar( 
            int hwndToolbar,
            BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UpdateToolbar( 
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int hwndToolbar) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DispatchCommand( 
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int cmdId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DispatchCommandUpdate( 
            VARIANT_BOOL *enabled,
            VARIANT_BOOL *checked,
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int cmdId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandId( 
            BSTR cmdName,
            /* [retval][out] */ int *id) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandImage( 
            BSTR cmdName,
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandName( 
            int id,
            /* [retval][out] */ BSTR *cmdName) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetImages( 
            /* [retval][out] */ HBITMAP *bitmap) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetToolbarOffset( 
            BSTR toolbarId,
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandProc( 
            BSTR cmdName,
            /* [retval][out] */ BSTR *procName) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICommandManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICommandManager * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICommandManager * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICommandManager * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICommandManager * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICommandManager * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICommandManager * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICommandManager * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterCommandTarget )( 
            ICommandManager * This,
            BSTR name,
            ICommandTarget *pTarget,
            /* [retval][out] */ int *cookie);
        
        HRESULT ( STDMETHODCALLTYPE *UnregisterCommandTarget )( 
            ICommandManager * This,
            int cookie);
        
        HRESULT ( STDMETHODCALLTYPE *AppendMenu )( 
            ICommandManager * This,
            HMENU hMenu,
            BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *UpdateMenu )( 
            ICommandManager * This,
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            HMENU hMenu);
        
        HRESULT ( STDMETHODCALLTYPE *SetupToolbar )( 
            ICommandManager * This,
            int hwndToolbar,
            BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *UpdateToolbar )( 
            ICommandManager * This,
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int hwndToolbar);
        
        HRESULT ( STDMETHODCALLTYPE *DispatchCommand )( 
            ICommandManager * This,
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int cmdId);
        
        HRESULT ( STDMETHODCALLTYPE *DispatchCommandUpdate )( 
            ICommandManager * This,
            VARIANT_BOOL *enabled,
            VARIANT_BOOL *checked,
            ICommandTarget *pGroup,
            ICommandTarget *pPanel,
            int cmdId);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandId )( 
            ICommandManager * This,
            BSTR cmdName,
            /* [retval][out] */ int *id);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandImage )( 
            ICommandManager * This,
            BSTR cmdName,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandName )( 
            ICommandManager * This,
            int id,
            /* [retval][out] */ BSTR *cmdName);
        
        HRESULT ( STDMETHODCALLTYPE *GetImages )( 
            ICommandManager * This,
            /* [retval][out] */ HBITMAP *bitmap);
        
        HRESULT ( STDMETHODCALLTYPE *GetToolbarOffset )( 
            ICommandManager * This,
            BSTR toolbarId,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandProc )( 
            ICommandManager * This,
            BSTR cmdName,
            /* [retval][out] */ BSTR *procName);
        
        END_INTERFACE
    } ICommandManagerVtbl;

    interface ICommandManager
    {
        CONST_VTBL struct ICommandManagerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICommandManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICommandManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICommandManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICommandManager_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICommandManager_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICommandManager_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICommandManager_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICommandManager_RegisterCommandTarget(This,name,pTarget,cookie)	\
    (This)->lpVtbl -> RegisterCommandTarget(This,name,pTarget,cookie)

#define ICommandManager_UnregisterCommandTarget(This,cookie)	\
    (This)->lpVtbl -> UnregisterCommandTarget(This,cookie)

#define ICommandManager_AppendMenu(This,hMenu,name)	\
    (This)->lpVtbl -> AppendMenu(This,hMenu,name)

#define ICommandManager_UpdateMenu(This,pGroup,pPanel,hMenu)	\
    (This)->lpVtbl -> UpdateMenu(This,pGroup,pPanel,hMenu)

#define ICommandManager_SetupToolbar(This,hwndToolbar,name)	\
    (This)->lpVtbl -> SetupToolbar(This,hwndToolbar,name)

#define ICommandManager_UpdateToolbar(This,pGroup,pPanel,hwndToolbar)	\
    (This)->lpVtbl -> UpdateToolbar(This,pGroup,pPanel,hwndToolbar)

#define ICommandManager_DispatchCommand(This,pGroup,pPanel,cmdId)	\
    (This)->lpVtbl -> DispatchCommand(This,pGroup,pPanel,cmdId)

#define ICommandManager_DispatchCommandUpdate(This,enabled,checked,pGroup,pPanel,cmdId)	\
    (This)->lpVtbl -> DispatchCommandUpdate(This,enabled,checked,pGroup,pPanel,cmdId)

#define ICommandManager_GetCommandId(This,cmdName,id)	\
    (This)->lpVtbl -> GetCommandId(This,cmdName,id)

#define ICommandManager_GetCommandImage(This,cmdName,index)	\
    (This)->lpVtbl -> GetCommandImage(This,cmdName,index)

#define ICommandManager_GetCommandName(This,id,cmdName)	\
    (This)->lpVtbl -> GetCommandName(This,id,cmdName)

#define ICommandManager_GetImages(This,bitmap)	\
    (This)->lpVtbl -> GetImages(This,bitmap)

#define ICommandManager_GetToolbarOffset(This,toolbarId,index)	\
    (This)->lpVtbl -> GetToolbarOffset(This,toolbarId,index)

#define ICommandManager_GetCommandProc(This,cmdName,procName)	\
    (This)->lpVtbl -> GetCommandProc(This,cmdName,procName)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICommandManager_RegisterCommandTarget_Proxy( 
    ICommandManager * This,
    BSTR name,
    ICommandTarget *pTarget,
    /* [retval][out] */ int *cookie);


void __RPC_STUB ICommandManager_RegisterCommandTarget_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_UnregisterCommandTarget_Proxy( 
    ICommandManager * This,
    int cookie);


void __RPC_STUB ICommandManager_UnregisterCommandTarget_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_AppendMenu_Proxy( 
    ICommandManager * This,
    HMENU hMenu,
    BSTR name);


void __RPC_STUB ICommandManager_AppendMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_UpdateMenu_Proxy( 
    ICommandManager * This,
    ICommandTarget *pGroup,
    ICommandTarget *pPanel,
    HMENU hMenu);


void __RPC_STUB ICommandManager_UpdateMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_SetupToolbar_Proxy( 
    ICommandManager * This,
    int hwndToolbar,
    BSTR name);


void __RPC_STUB ICommandManager_SetupToolbar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_UpdateToolbar_Proxy( 
    ICommandManager * This,
    ICommandTarget *pGroup,
    ICommandTarget *pPanel,
    int hwndToolbar);


void __RPC_STUB ICommandManager_UpdateToolbar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_DispatchCommand_Proxy( 
    ICommandManager * This,
    ICommandTarget *pGroup,
    ICommandTarget *pPanel,
    int cmdId);


void __RPC_STUB ICommandManager_DispatchCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_DispatchCommandUpdate_Proxy( 
    ICommandManager * This,
    VARIANT_BOOL *enabled,
    VARIANT_BOOL *checked,
    ICommandTarget *pGroup,
    ICommandTarget *pPanel,
    int cmdId);


void __RPC_STUB ICommandManager_DispatchCommandUpdate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetCommandId_Proxy( 
    ICommandManager * This,
    BSTR cmdName,
    /* [retval][out] */ int *id);


void __RPC_STUB ICommandManager_GetCommandId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetCommandImage_Proxy( 
    ICommandManager * This,
    BSTR cmdName,
    /* [retval][out] */ int *index);


void __RPC_STUB ICommandManager_GetCommandImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetCommandName_Proxy( 
    ICommandManager * This,
    int id,
    /* [retval][out] */ BSTR *cmdName);


void __RPC_STUB ICommandManager_GetCommandName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetImages_Proxy( 
    ICommandManager * This,
    /* [retval][out] */ HBITMAP *bitmap);


void __RPC_STUB ICommandManager_GetImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetToolbarOffset_Proxy( 
    ICommandManager * This,
    BSTR toolbarId,
    /* [retval][out] */ int *index);


void __RPC_STUB ICommandManager_GetToolbarOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICommandManager_GetCommandProc_Proxy( 
    ICommandManager * This,
    BSTR cmdName,
    /* [retval][out] */ BSTR *procName);


void __RPC_STUB ICommandManager_GetCommandProc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICommandManager_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0273 */
/* [local] */ 


enum EGlobalParam
    {	LANGUAGE	= 0,
	SKIN_NAME	= LANGUAGE + 1,
	INTERNET_CONNECTION	= SKIN_NAME + 1,
	INTERNET_PROXY	= INTERNET_CONNECTION + 1,
	INTERNET_PROXY_PORT	= INTERNET_PROXY + 1,
	INTERNET_AUTHENTICATION	= INTERNET_PROXY_PORT + 1,
	INTERNET_USER	= INTERNET_AUTHENTICATION + 1,
	INTERNET_PASSWORD	= INTERNET_USER + 1,
	INTERNET_OFFLINE	= INTERNET_PASSWORD + 1,
	HOVER_DELAY	= INTERNET_OFFLINE + 1,
	AUTOSCROLL_MARGIN	= HOVER_DELAY + 1,
	AUTOSCROLL_FREQUENCY	= AUTOSCROLL_MARGIN + 1,
	AUTOSCROLL_SPEED	= AUTOSCROLL_FREQUENCY + 1,
	SHOW_DETAILS	= AUTOSCROLL_SPEED + 1,
	DETAILS_SHOW_DELAY	= SHOW_DETAILS + 1,
	DETAILS_HIDE_DELAY	= DETAILS_SHOW_DELAY + 1,
	SCREEN_EDGE	= DETAILS_HIDE_DELAY + 1,
	WINDOW_WIDTH	= SCREEN_EDGE + 1,
	WINDOW_POS	= WINDOW_WIDTH + 1,
	MONITOR	= WINDOW_POS + 1,
	ALWAYS_ON_TOP	= MONITOR + 1,
	TRAY_ICON	= ALWAYS_ON_TOP + 1,
	TRANSPARENCY	= TRAY_ICON + 1,
	FORCE_WINDOW_TITLE	= TRANSPARENCY + 1,
	AUTOHIDE	= FORCE_WINDOW_TITLE + 1,
	AUTOHIDE_SHOW_DELAY	= AUTOHIDE + 1,
	AUTOHIDE_HIDE_DELAY	= AUTOHIDE_SHOW_DELAY + 1,
	AUTOHIDE_WIDTH	= AUTOHIDE_HIDE_DELAY + 1,
	AUTOHIDE_ANIMATION	= AUTOHIDE_WIDTH + 1,
	AUTOHIDE_ANIMATION_SPEED	= AUTOHIDE_ANIMATION + 1,
	CHECK_FOR_UPDATES	= AUTOHIDE_ANIMATION_SPEED + 1,
	DONT_UPDATE_TO_BUILD	= CHECK_FOR_UPDATES + 1,
	SILENT_UPDATE	= DONT_UPDATE_TO_BUILD + 1,
	UPDATE_TIMESTAMP	= SILENT_UPDATE + 1,
	UPDATE_URL	= UPDATE_TIMESTAMP + 1,
	SUPPORT	= UPDATE_URL + 1,
	HOMEPAGE	= SUPPORT + 1,
	SEND_STATISTIC	= HOMEPAGE + 1,
	STATISTIC_SAMPLE	= SEND_STATISTIC + 1,
	ALERT_FREQUENCY	= STATISTIC_SAMPLE + 1,
	ALERT_WIDTH	= ALERT_FREQUENCY + 1,
	ALERT_HEIGHT	= ALERT_WIDTH + 1,
	ALERT_DURATION	= ALERT_HEIGHT + 1,
	ALERT_ANIMATION	= ALERT_DURATION + 1,
	ALERT_ANIMATION_SPEED	= ALERT_ANIMATION + 1,
	ALERT_FLASH	= ALERT_ANIMATION_SPEED + 1,
	ALERT_MARGIN	= ALERT_FLASH + 1,
	ALERT_IN_FULLSCREEN	= ALERT_MARGIN + 1,
	LOCK_WINDOW	= ALERT_IN_FULLSCREEN + 1,
	SHOW_START	= LOCK_WINDOW + 1,
	PANEL_ICONS	= SHOW_START + 1,
	SHOW_AUTOHIDE_INFO	= PANEL_ICONS + 1,
	FORUMS	= SHOW_AUTOHIDE_INFO + 1,
	ADDINS	= FORUMS + 1,
	FAQ	= ADDINS + 1,
	LOCK_UNDOCKED	= FAQ + 1,
	DETAILS_ANIMATION	= LOCK_UNDOCKED + 1,
	DETAILS_ANIMATION_SPEED	= DETAILS_ANIMATION + 1,
	GROUP_ANIMATION_SPEED	= DETAILS_ANIMATION_SPEED + 1,
	SIDEBAR_BUILD	= GROUP_ANIMATION_SPEED + 1,
	INIT_THRESHOLD	= SIDEBAR_BUILD + 1,
	CLEANUP_THRESHOLD	= INIT_THRESHOLD + 1,
	UNDOCKED_TEXT_COLOR	= CLEANUP_THRESHOLD + 1,
	SETTINGS_DIRECTORY	= UNDOCKED_TEXT_COLOR + 1,
	SANDBOX_MODE	= SETTINGS_DIRECTORY + 1,
	REPORT_SCRIPT_ERRORS	= SANDBOX_MODE + 1,
	CHECK_FOR_BETAS	= REPORT_SCRIPT_ERRORS + 1,
	ALERTS_ENABLED	= CHECK_FOR_BETAS + 1,
	DISABLE_DETAILS	= ALERTS_ENABLED + 1
    } ;

enum EShowDeatils
    {	DetailsDisabled	= 0,
	DetailsHover	= 1,
	DetailsClick	= 2,
	DetailsCompatibility	= 16
    } ;

enum EDSPosition
    {	LEFT_EDGE	= 0,
	RIGHT_EDGE	= 1,
	FLOATING	= 2
    } ;

enum ESandboxMode
    {	BANNED_REGISTRY	= 1,
	BANNED_LOCALCONFIG	= 2
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0273_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0273_v0_0_s_ifspec;

#ifndef __IGlobalSettings_INTERFACE_DEFINED__
#define __IGlobalSettings_INTERFACE_DEFINED__

/* interface IGlobalSettings */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IGlobalSettings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9E11EE55-1FF0-4388-B84C-3C99836E8BB0")
    IGlobalSettings : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetInt( 
            enum EGlobalParam param,
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetString( 
            enum EGlobalParam param,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCodedString( 
            enum EGlobalParam param,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetInt( 
            enum EGlobalParam param,
            int val) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetString( 
            enum EGlobalParam param,
            BSTR str) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCodedString( 
            enum EGlobalParam param,
            BSTR str) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IGlobalSettingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IGlobalSettings * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IGlobalSettings * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IGlobalSettings * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IGlobalSettings * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IGlobalSettings * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IGlobalSettings * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IGlobalSettings * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetInt )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetString )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetCodedString )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetInt )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            int val);
        
        HRESULT ( STDMETHODCALLTYPE *SetString )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            BSTR str);
        
        HRESULT ( STDMETHODCALLTYPE *SetCodedString )( 
            IGlobalSettings * This,
            enum EGlobalParam param,
            BSTR str);
        
        END_INTERFACE
    } IGlobalSettingsVtbl;

    interface IGlobalSettings
    {
        CONST_VTBL struct IGlobalSettingsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IGlobalSettings_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IGlobalSettings_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IGlobalSettings_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IGlobalSettings_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IGlobalSettings_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IGlobalSettings_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IGlobalSettings_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IGlobalSettings_GetInt(This,param,retVal)	\
    (This)->lpVtbl -> GetInt(This,param,retVal)

#define IGlobalSettings_GetString(This,param,retVal)	\
    (This)->lpVtbl -> GetString(This,param,retVal)

#define IGlobalSettings_GetCodedString(This,param,retVal)	\
    (This)->lpVtbl -> GetCodedString(This,param,retVal)

#define IGlobalSettings_SetInt(This,param,val)	\
    (This)->lpVtbl -> SetInt(This,param,val)

#define IGlobalSettings_SetString(This,param,str)	\
    (This)->lpVtbl -> SetString(This,param,str)

#define IGlobalSettings_SetCodedString(This,param,str)	\
    (This)->lpVtbl -> SetCodedString(This,param,str)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IGlobalSettings_GetInt_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IGlobalSettings_GetInt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGlobalSettings_GetString_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IGlobalSettings_GetString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGlobalSettings_GetCodedString_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IGlobalSettings_GetCodedString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGlobalSettings_SetInt_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    int val);


void __RPC_STUB IGlobalSettings_SetInt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGlobalSettings_SetString_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    BSTR str);


void __RPC_STUB IGlobalSettings_SetString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IGlobalSettings_SetCodedString_Proxy( 
    IGlobalSettings * This,
    enum EGlobalParam param,
    BSTR str);


void __RPC_STUB IGlobalSettings_SetCodedString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IGlobalSettings_INTERFACE_DEFINED__ */


#ifndef __IXmlNode_INTERFACE_DEFINED__
#define __IXmlNode_INTERFACE_DEFINED__

/* interface IXmlNode */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IXmlNode;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("08B1D64F-1999-45cb-83DE-E251C1CF7BF8")
    IXmlNode : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetName( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBody( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAttribute( 
            BSTR name,
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetNode( 
            BSTR path,
            /* [retval][out] */ IXmlNode **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetChildCount( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetChild( 
            int index,
            /* [retval][out] */ IXmlNode **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAttributeCount( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAttributeName( 
            int index,
            /* [retval][out] */ BSTR *retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IXmlNodeVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IXmlNode * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IXmlNode * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IXmlNode * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IXmlNode * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IXmlNode * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IXmlNode * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IXmlNode * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetName )( 
            IXmlNode * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBody )( 
            IXmlNode * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetAttribute )( 
            IXmlNode * This,
            BSTR name,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetNode )( 
            IXmlNode * This,
            BSTR path,
            /* [retval][out] */ IXmlNode **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetChildCount )( 
            IXmlNode * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetChild )( 
            IXmlNode * This,
            int index,
            /* [retval][out] */ IXmlNode **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetAttributeCount )( 
            IXmlNode * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetAttributeName )( 
            IXmlNode * This,
            int index,
            /* [retval][out] */ BSTR *retVal);
        
        END_INTERFACE
    } IXmlNodeVtbl;

    interface IXmlNode
    {
        CONST_VTBL struct IXmlNodeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IXmlNode_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IXmlNode_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IXmlNode_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IXmlNode_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IXmlNode_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IXmlNode_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IXmlNode_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IXmlNode_GetName(This,retVal)	\
    (This)->lpVtbl -> GetName(This,retVal)

#define IXmlNode_GetBody(This,retVal)	\
    (This)->lpVtbl -> GetBody(This,retVal)

#define IXmlNode_GetAttribute(This,name,retVal)	\
    (This)->lpVtbl -> GetAttribute(This,name,retVal)

#define IXmlNode_GetNode(This,path,retVal)	\
    (This)->lpVtbl -> GetNode(This,path,retVal)

#define IXmlNode_GetChildCount(This,retVal)	\
    (This)->lpVtbl -> GetChildCount(This,retVal)

#define IXmlNode_GetChild(This,index,retVal)	\
    (This)->lpVtbl -> GetChild(This,index,retVal)

#define IXmlNode_GetAttributeCount(This,retVal)	\
    (This)->lpVtbl -> GetAttributeCount(This,retVal)

#define IXmlNode_GetAttributeName(This,index,retVal)	\
    (This)->lpVtbl -> GetAttributeName(This,index,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IXmlNode_GetName_Proxy( 
    IXmlNode * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IXmlNode_GetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetBody_Proxy( 
    IXmlNode * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IXmlNode_GetBody_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetAttribute_Proxy( 
    IXmlNode * This,
    BSTR name,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IXmlNode_GetAttribute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetNode_Proxy( 
    IXmlNode * This,
    BSTR path,
    /* [retval][out] */ IXmlNode **retVal);


void __RPC_STUB IXmlNode_GetNode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetChildCount_Proxy( 
    IXmlNode * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IXmlNode_GetChildCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetChild_Proxy( 
    IXmlNode * This,
    int index,
    /* [retval][out] */ IXmlNode **retVal);


void __RPC_STUB IXmlNode_GetChild_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetAttributeCount_Proxy( 
    IXmlNode * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IXmlNode_GetAttributeCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlNode_GetAttributeName_Proxy( 
    IXmlNode * This,
    int index,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IXmlNode_GetAttributeName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IXmlNode_INTERFACE_DEFINED__ */


#ifndef __IRSSItem_INTERFACE_DEFINED__
#define __IRSSItem_INTERFACE_DEFINED__

/* interface IRSSItem */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRSSItem;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F28E53B8-ECC0-4891-971A-1ACF5084D355")
    IRSSItem : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetItemNode( 
            /* [retval][out] */ IXmlNode **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTitle( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetLink( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDescription( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDescriptionText( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMediaUrl( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetThumbnailUrl( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPubDate( 
            /* [retval][out] */ VARIANT *retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRSSItemVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IRSSItem * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IRSSItem * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IRSSItem * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IRSSItem * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IRSSItem * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IRSSItem * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IRSSItem * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetItemNode )( 
            IRSSItem * This,
            /* [retval][out] */ IXmlNode **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetTitle )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetLink )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetDescription )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetDescriptionText )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetMediaUrl )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetThumbnailUrl )( 
            IRSSItem * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetPubDate )( 
            IRSSItem * This,
            /* [retval][out] */ VARIANT *retVal);
        
        END_INTERFACE
    } IRSSItemVtbl;

    interface IRSSItem
    {
        CONST_VTBL struct IRSSItemVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRSSItem_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRSSItem_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRSSItem_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRSSItem_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRSSItem_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRSSItem_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRSSItem_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRSSItem_GetItemNode(This,retVal)	\
    (This)->lpVtbl -> GetItemNode(This,retVal)

#define IRSSItem_GetTitle(This,retVal)	\
    (This)->lpVtbl -> GetTitle(This,retVal)

#define IRSSItem_GetLink(This,retVal)	\
    (This)->lpVtbl -> GetLink(This,retVal)

#define IRSSItem_GetDescription(This,retVal)	\
    (This)->lpVtbl -> GetDescription(This,retVal)

#define IRSSItem_GetDescriptionText(This,retVal)	\
    (This)->lpVtbl -> GetDescriptionText(This,retVal)

#define IRSSItem_GetMediaUrl(This,retVal)	\
    (This)->lpVtbl -> GetMediaUrl(This,retVal)

#define IRSSItem_GetThumbnailUrl(This,retVal)	\
    (This)->lpVtbl -> GetThumbnailUrl(This,retVal)

#define IRSSItem_GetPubDate(This,retVal)	\
    (This)->lpVtbl -> GetPubDate(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IRSSItem_GetItemNode_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ IXmlNode **retVal);


void __RPC_STUB IRSSItem_GetItemNode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetTitle_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetLink_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetDescription_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetDescriptionText_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetDescriptionText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetMediaUrl_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetMediaUrl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetThumbnailUrl_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSItem_GetThumbnailUrl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSItem_GetPubDate_Proxy( 
    IRSSItem * This,
    /* [retval][out] */ VARIANT *retVal);


void __RPC_STUB IRSSItem_GetPubDate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRSSItem_INTERFACE_DEFINED__ */


#ifndef __IRSSFeed_INTERFACE_DEFINED__
#define __IRSSFeed_INTERFACE_DEFINED__

/* interface IRSSFeed */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRSSFeed;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3937FA9E-D4CB-4e10-A632-6C10BABB121E")
    IRSSFeed : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetItemsCount( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetItem( 
            int index,
            /* [retval][out] */ IRSSItem **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTitle( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetLink( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetChannelNode( 
            /* [retval][out] */ IXmlNode **retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRSSFeedVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IRSSFeed * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IRSSFeed * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IRSSFeed * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IRSSFeed * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IRSSFeed * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IRSSFeed * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IRSSFeed * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetItemsCount )( 
            IRSSFeed * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetItem )( 
            IRSSFeed * This,
            int index,
            /* [retval][out] */ IRSSItem **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetTitle )( 
            IRSSFeed * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetLink )( 
            IRSSFeed * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetChannelNode )( 
            IRSSFeed * This,
            /* [retval][out] */ IXmlNode **retVal);
        
        END_INTERFACE
    } IRSSFeedVtbl;

    interface IRSSFeed
    {
        CONST_VTBL struct IRSSFeedVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRSSFeed_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRSSFeed_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRSSFeed_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRSSFeed_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRSSFeed_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRSSFeed_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRSSFeed_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRSSFeed_GetItemsCount(This,retVal)	\
    (This)->lpVtbl -> GetItemsCount(This,retVal)

#define IRSSFeed_GetItem(This,index,retVal)	\
    (This)->lpVtbl -> GetItem(This,index,retVal)

#define IRSSFeed_GetTitle(This,retVal)	\
    (This)->lpVtbl -> GetTitle(This,retVal)

#define IRSSFeed_GetLink(This,retVal)	\
    (This)->lpVtbl -> GetLink(This,retVal)

#define IRSSFeed_GetChannelNode(This,retVal)	\
    (This)->lpVtbl -> GetChannelNode(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IRSSFeed_GetItemsCount_Proxy( 
    IRSSFeed * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IRSSFeed_GetItemsCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSFeed_GetItem_Proxy( 
    IRSSFeed * This,
    int index,
    /* [retval][out] */ IRSSItem **retVal);


void __RPC_STUB IRSSFeed_GetItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSFeed_GetTitle_Proxy( 
    IRSSFeed * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSFeed_GetTitle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSFeed_GetLink_Proxy( 
    IRSSFeed * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IRSSFeed_GetLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRSSFeed_GetChannelNode_Proxy( 
    IRSSFeed * This,
    /* [retval][out] */ IXmlNode **retVal);


void __RPC_STUB IRSSFeed_GetChannelNode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRSSFeed_INTERFACE_DEFINED__ */


#ifndef __IXmlBuilder_INTERFACE_DEFINED__
#define __IXmlBuilder_INTERFACE_DEFINED__

/* interface IXmlBuilder */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IXmlBuilder;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A292966D-6CA1-427a-8513-39A67FC4BDD6")
    IXmlBuilder : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE AddAttribute( 
            BSTR name,
            BSTR value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddChild( 
            BSTR tag,
            /* [retval][out] */ IXmlBuilder **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetBody( 
            BSTR body) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IXmlBuilderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IXmlBuilder * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IXmlBuilder * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IXmlBuilder * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IXmlBuilder * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IXmlBuilder * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IXmlBuilder * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IXmlBuilder * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *AddAttribute )( 
            IXmlBuilder * This,
            BSTR name,
            BSTR value);
        
        HRESULT ( STDMETHODCALLTYPE *AddChild )( 
            IXmlBuilder * This,
            BSTR tag,
            /* [retval][out] */ IXmlBuilder **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetBody )( 
            IXmlBuilder * This,
            BSTR body);
        
        END_INTERFACE
    } IXmlBuilderVtbl;

    interface IXmlBuilder
    {
        CONST_VTBL struct IXmlBuilderVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IXmlBuilder_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IXmlBuilder_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IXmlBuilder_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IXmlBuilder_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IXmlBuilder_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IXmlBuilder_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IXmlBuilder_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IXmlBuilder_AddAttribute(This,name,value)	\
    (This)->lpVtbl -> AddAttribute(This,name,value)

#define IXmlBuilder_AddChild(This,tag,retVal)	\
    (This)->lpVtbl -> AddChild(This,tag,retVal)

#define IXmlBuilder_SetBody(This,body)	\
    (This)->lpVtbl -> SetBody(This,body)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IXmlBuilder_AddAttribute_Proxy( 
    IXmlBuilder * This,
    BSTR name,
    BSTR value);


void __RPC_STUB IXmlBuilder_AddAttribute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlBuilder_AddChild_Proxy( 
    IXmlBuilder * This,
    BSTR tag,
    /* [retval][out] */ IXmlBuilder **retVal);


void __RPC_STUB IXmlBuilder_AddChild_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IXmlBuilder_SetBody_Proxy( 
    IXmlBuilder * This,
    BSTR body);


void __RPC_STUB IXmlBuilder_SetBody_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IXmlBuilder_INTERFACE_DEFINED__ */


#ifndef __IControl_INTERFACE_DEFINED__
#define __IControl_INTERFACE_DEFINED__

/* interface IControl */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("22022877-827F-494d-B6DA-DFF6EB0FE913")
    IControl : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetDisplay( 
            /* [in] */ VARIANT_BOOL display) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDisplay( 
            /* [retval][out] */ VARIANT_BOOL *display) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetVisible( 
            /* [in] */ VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetVisible( 
            /* [retval][out] */ VARIANT_BOOL *visible) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IControl * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IControl * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IControl * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IControl * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IControl * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IControl * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IControl * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *SetDisplay )( 
            IControl * This,
            /* [in] */ VARIANT_BOOL display);
        
        HRESULT ( STDMETHODCALLTYPE *GetDisplay )( 
            IControl * This,
            /* [retval][out] */ VARIANT_BOOL *display);
        
        HRESULT ( STDMETHODCALLTYPE *SetVisible )( 
            IControl * This,
            /* [in] */ VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetVisible )( 
            IControl * This,
            /* [retval][out] */ VARIANT_BOOL *visible);
        
        END_INTERFACE
    } IControlVtbl;

    interface IControl
    {
        CONST_VTBL struct IControlVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IControl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IControl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IControl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IControl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IControl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IControl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IControl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IControl_SetDisplay(This,display)	\
    (This)->lpVtbl -> SetDisplay(This,display)

#define IControl_GetDisplay(This,display)	\
    (This)->lpVtbl -> GetDisplay(This,display)

#define IControl_SetVisible(This,visible)	\
    (This)->lpVtbl -> SetVisible(This,visible)

#define IControl_GetVisible(This,visible)	\
    (This)->lpVtbl -> GetVisible(This,visible)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IControl_SetDisplay_Proxy( 
    IControl * This,
    /* [in] */ VARIANT_BOOL display);


void __RPC_STUB IControl_SetDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControl_GetDisplay_Proxy( 
    IControl * This,
    /* [retval][out] */ VARIANT_BOOL *display);


void __RPC_STUB IControl_GetDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControl_SetVisible_Proxy( 
    IControl * This,
    /* [in] */ VARIANT_BOOL visible);


void __RPC_STUB IControl_SetVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControl_GetVisible_Proxy( 
    IControl * This,
    /* [retval][out] */ VARIANT_BOOL *visible);


void __RPC_STUB IControl_GetVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IControl_INTERFACE_DEFINED__ */


#ifndef __ITextOutput_INTERFACE_DEFINED__
#define __ITextOutput_INTERFACE_DEFINED__

/* interface ITextOutput */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITextOutput;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CBD28A8E-8229-4fbc-821B-6F907BCA9599")
    ITextOutput : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *textOutputParent,
            VARIANT_BOOL supportClick) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetText( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkinElement( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSkinElement( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitHeight( 
            /* [retval][out] */ int *calc) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TakeoverDetails( 
            IUnknown *details) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetWrap( 
            VARIANT_BOOL wrap) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetWrap( 
            /* [retval][out] */ VARIANT_BOOL *wrap) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetText( 
            /* [retval][out] */ BSTR *text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitHeightEx( 
            int width,
            /* [retval][out] */ int *calc) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *textOutputParent,
            VARIANT_BOOL supportClick,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSupportClick( 
            VARIANT_BOOL supportClick) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetRightToLeft( 
            VARIANT_BOOL rightToLeft) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextOutputVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextOutput * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextOutput * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextOutput * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextOutput * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextOutput * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextOutput * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ITextOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *textOutputParent,
            VARIANT_BOOL supportClick);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ITextOutput * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ITextOutput * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            ITextOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            ITextOutput * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            ITextOutput * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            ITextOutput * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetText )( 
            ITextOutput * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkinElement )( 
            ITextOutput * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetSkinElement )( 
            ITextOutput * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitHeight )( 
            ITextOutput * This,
            /* [retval][out] */ int *calc);
        
        HRESULT ( STDMETHODCALLTYPE *TakeoverDetails )( 
            ITextOutput * This,
            IUnknown *details);
        
        HRESULT ( STDMETHODCALLTYPE *SetWrap )( 
            ITextOutput * This,
            VARIANT_BOOL wrap);
        
        HRESULT ( STDMETHODCALLTYPE *GetWrap )( 
            ITextOutput * This,
            /* [retval][out] */ VARIANT_BOOL *wrap);
        
        HRESULT ( STDMETHODCALLTYPE *GetText )( 
            ITextOutput * This,
            /* [retval][out] */ BSTR *text);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitHeightEx )( 
            ITextOutput * This,
            int width,
            /* [retval][out] */ int *calc);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            ITextOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *textOutputParent,
            VARIANT_BOOL supportClick,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            ITextOutput * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            ITextOutput * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            ITextOutput * This,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetSupportClick )( 
            ITextOutput * This,
            VARIANT_BOOL supportClick);
        
        HRESULT ( STDMETHODCALLTYPE *SetRightToLeft )( 
            ITextOutput * This,
            VARIANT_BOOL rightToLeft);
        
        END_INTERFACE
    } ITextOutputVtbl;

    interface ITextOutput
    {
        CONST_VTBL struct ITextOutputVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextOutput_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITextOutput_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITextOutput_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITextOutput_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITextOutput_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITextOutput_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITextOutput_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITextOutput_Init(This,settings,skinManager,textOutputParent,supportClick)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,textOutputParent,supportClick)

#define ITextOutput_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define ITextOutput_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ITextOutput_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ITextOutput_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define ITextOutput_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define ITextOutput_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define ITextOutput_SetText(This,text)	\
    (This)->lpVtbl -> SetText(This,text)

#define ITextOutput_SetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> SetSkinElement(This,skinElement)

#define ITextOutput_GetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> GetSkinElement(This,skinElement)

#define ITextOutput_GetFitHeight(This,calc)	\
    (This)->lpVtbl -> GetFitHeight(This,calc)

#define ITextOutput_TakeoverDetails(This,details)	\
    (This)->lpVtbl -> TakeoverDetails(This,details)

#define ITextOutput_SetWrap(This,wrap)	\
    (This)->lpVtbl -> SetWrap(This,wrap)

#define ITextOutput_GetWrap(This,wrap)	\
    (This)->lpVtbl -> GetWrap(This,wrap)

#define ITextOutput_GetText(This,text)	\
    (This)->lpVtbl -> GetText(This,text)

#define ITextOutput_GetFitHeightEx(This,width,calc)	\
    (This)->lpVtbl -> GetFitHeightEx(This,width,calc)

#define ITextOutput_Init2(This,settings,skinManager,textOutputParent,supportClick,identifier)	\
    (This)->lpVtbl -> Init2(This,settings,skinManager,textOutputParent,supportClick,identifier)

#define ITextOutput_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define ITextOutput_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define ITextOutput_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define ITextOutput_SetSupportClick(This,supportClick)	\
    (This)->lpVtbl -> SetSupportClick(This,supportClick)

#define ITextOutput_SetRightToLeft(This,rightToLeft)	\
    (This)->lpVtbl -> SetRightToLeft(This,rightToLeft)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITextOutput_Init_Proxy( 
    ITextOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *textOutputParent,
    VARIANT_BOOL supportClick);


void __RPC_STUB ITextOutput_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_Create_Proxy( 
    ITextOutput * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB ITextOutput_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetHwnd_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB ITextOutput_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_Close_Proxy( 
    ITextOutput * This);


void __RPC_STUB ITextOutput_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_MoveWindow_Proxy( 
    ITextOutput * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB ITextOutput_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_ShowWindow_Proxy( 
    ITextOutput * This,
    VARIANT_BOOL show);


void __RPC_STUB ITextOutput_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetControlRect_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB ITextOutput_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetText_Proxy( 
    ITextOutput * This,
    BSTR text);


void __RPC_STUB ITextOutput_SetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetSkinElement_Proxy( 
    ITextOutput * This,
    int skinElement);


void __RPC_STUB ITextOutput_SetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetSkinElement_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB ITextOutput_GetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetFitHeight_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ int *calc);


void __RPC_STUB ITextOutput_GetFitHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_TakeoverDetails_Proxy( 
    ITextOutput * This,
    IUnknown *details);


void __RPC_STUB ITextOutput_TakeoverDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetWrap_Proxy( 
    ITextOutput * This,
    VARIANT_BOOL wrap);


void __RPC_STUB ITextOutput_SetWrap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetWrap_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ VARIANT_BOOL *wrap);


void __RPC_STUB ITextOutput_GetWrap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetText_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ BSTR *text);


void __RPC_STUB ITextOutput_GetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetFitHeightEx_Proxy( 
    ITextOutput * This,
    int width,
    /* [retval][out] */ int *calc);


void __RPC_STUB ITextOutput_GetFitHeightEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_Init2_Proxy( 
    ITextOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *textOutputParent,
    VARIANT_BOOL supportClick,
    int identifier);


void __RPC_STUB ITextOutput_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_GetId_Proxy( 
    ITextOutput * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB ITextOutput_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetParent_Proxy( 
    ITextOutput * This,
    IUnknown *parent);


void __RPC_STUB ITextOutput_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetIdentifier_Proxy( 
    ITextOutput * This,
    int identifier);


void __RPC_STUB ITextOutput_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetSupportClick_Proxy( 
    ITextOutput * This,
    VARIANT_BOOL supportClick);


void __RPC_STUB ITextOutput_SetSupportClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutput_SetRightToLeft_Proxy( 
    ITextOutput * This,
    VARIANT_BOOL rightToLeft);


void __RPC_STUB ITextOutput_SetRightToLeft_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITextOutput_INTERFACE_DEFINED__ */


#ifndef __ITextOutputParent_INTERFACE_DEFINED__
#define __ITextOutputParent_INTERFACE_DEFINED__

/* interface ITextOutputParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITextOutputParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("63B0C7C4-E1F9-467a-A560-F0F83F00F386")
    ITextOutputParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            ITextOutput *textOutput,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            ITextOutput *textOutput,
            VARIANT_BOOL dbclk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseHover( 
            ITextOutput *textOutput) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseLeave( 
            ITextOutput *textOutput) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnShowDetails( 
            ITextOutput *textOutput) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextOutputParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextOutputParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextOutputParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextOutputParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextOutputParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextOutputParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextOutputParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextOutputParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            ITextOutputParent * This,
            ITextOutput *textOutput,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            ITextOutputParent * This,
            ITextOutput *textOutput,
            VARIANT_BOOL dbclk);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseHover )( 
            ITextOutputParent * This,
            ITextOutput *textOutput);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseLeave )( 
            ITextOutputParent * This,
            ITextOutput *textOutput);
        
        HRESULT ( STDMETHODCALLTYPE *OnShowDetails )( 
            ITextOutputParent * This,
            ITextOutput *textOutput);
        
        END_INTERFACE
    } ITextOutputParentVtbl;

    interface ITextOutputParent
    {
        CONST_VTBL struct ITextOutputParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextOutputParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITextOutputParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITextOutputParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITextOutputParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITextOutputParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITextOutputParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITextOutputParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITextOutputParent_OnDrawBackground(This,textOutput,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,textOutput,graphics)

#define ITextOutputParent_OnClick(This,textOutput,dbclk)	\
    (This)->lpVtbl -> OnClick(This,textOutput,dbclk)

#define ITextOutputParent_OnMouseHover(This,textOutput)	\
    (This)->lpVtbl -> OnMouseHover(This,textOutput)

#define ITextOutputParent_OnMouseLeave(This,textOutput)	\
    (This)->lpVtbl -> OnMouseLeave(This,textOutput)

#define ITextOutputParent_OnShowDetails(This,textOutput)	\
    (This)->lpVtbl -> OnShowDetails(This,textOutput)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITextOutputParent_OnDrawBackground_Proxy( 
    ITextOutputParent * This,
    ITextOutput *textOutput,
    IGraphics *graphics);


void __RPC_STUB ITextOutputParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutputParent_OnClick_Proxy( 
    ITextOutputParent * This,
    ITextOutput *textOutput,
    VARIANT_BOOL dbclk);


void __RPC_STUB ITextOutputParent_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutputParent_OnMouseHover_Proxy( 
    ITextOutputParent * This,
    ITextOutput *textOutput);


void __RPC_STUB ITextOutputParent_OnMouseHover_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutputParent_OnMouseLeave_Proxy( 
    ITextOutputParent * This,
    ITextOutput *textOutput);


void __RPC_STUB ITextOutputParent_OnMouseLeave_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextOutputParent_OnShowDetails_Proxy( 
    ITextOutputParent * This,
    ITextOutput *textOutput);


void __RPC_STUB ITextOutputParent_OnShowDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITextOutputParent_INTERFACE_DEFINED__ */


#ifndef __IListRow_INTERFACE_DEFINED__
#define __IListRow_INTERFACE_DEFINED__

/* interface IListRow */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IListRow;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F4C60D77-14BE-4a32-8717-816BB2C383D3")
    IListRow : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SetImageIndex( 
            int image) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetImageSkin( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTextSkin( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetBackgroundSkin( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetText( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetText( 
            /* [retval][out] */ BSTR *text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetDetailsText( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDetailsText( 
            /* [retval][out] */ BSTR *text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetUserData( 
            int index,
            /* [retval][out] */ int *data) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetUserData( 
            int index,
            int value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetUserData2( 
            int index,
            /* [retval][out] */ VARIANT *data) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetUserData2( 
            int index,
            VARIANT value) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IListRowVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IListRow * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IListRow * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IListRow * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IListRow * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IListRow * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IListRow * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IListRow * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *SetImageIndex )( 
            IListRow * This,
            int image);
        
        HRESULT ( STDMETHODCALLTYPE *SetImageSkin )( 
            IListRow * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *SetTextSkin )( 
            IListRow * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *SetBackgroundSkin )( 
            IListRow * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *SetText )( 
            IListRow * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *GetText )( 
            IListRow * This,
            /* [retval][out] */ BSTR *text);
        
        HRESULT ( STDMETHODCALLTYPE *SetDetailsText )( 
            IListRow * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *GetDetailsText )( 
            IListRow * This,
            /* [retval][out] */ BSTR *text);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserData )( 
            IListRow * This,
            int index,
            /* [retval][out] */ int *data);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserData )( 
            IListRow * This,
            int index,
            int value);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserData2 )( 
            IListRow * This,
            int index,
            /* [retval][out] */ VARIANT *data);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserData2 )( 
            IListRow * This,
            int index,
            VARIANT value);
        
        END_INTERFACE
    } IListRowVtbl;

    interface IListRow
    {
        CONST_VTBL struct IListRowVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IListRow_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IListRow_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IListRow_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IListRow_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IListRow_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IListRow_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IListRow_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IListRow_SetImageIndex(This,image)	\
    (This)->lpVtbl -> SetImageIndex(This,image)

#define IListRow_SetImageSkin(This,skinElement)	\
    (This)->lpVtbl -> SetImageSkin(This,skinElement)

#define IListRow_SetTextSkin(This,skinElement)	\
    (This)->lpVtbl -> SetTextSkin(This,skinElement)

#define IListRow_SetBackgroundSkin(This,skinElement)	\
    (This)->lpVtbl -> SetBackgroundSkin(This,skinElement)

#define IListRow_SetText(This,text)	\
    (This)->lpVtbl -> SetText(This,text)

#define IListRow_GetText(This,text)	\
    (This)->lpVtbl -> GetText(This,text)

#define IListRow_SetDetailsText(This,text)	\
    (This)->lpVtbl -> SetDetailsText(This,text)

#define IListRow_GetDetailsText(This,text)	\
    (This)->lpVtbl -> GetDetailsText(This,text)

#define IListRow_GetUserData(This,index,data)	\
    (This)->lpVtbl -> GetUserData(This,index,data)

#define IListRow_SetUserData(This,index,value)	\
    (This)->lpVtbl -> SetUserData(This,index,value)

#define IListRow_GetUserData2(This,index,data)	\
    (This)->lpVtbl -> GetUserData2(This,index,data)

#define IListRow_SetUserData2(This,index,value)	\
    (This)->lpVtbl -> SetUserData2(This,index,value)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IListRow_SetImageIndex_Proxy( 
    IListRow * This,
    int image);


void __RPC_STUB IListRow_SetImageIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetImageSkin_Proxy( 
    IListRow * This,
    int skinElement);


void __RPC_STUB IListRow_SetImageSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetTextSkin_Proxy( 
    IListRow * This,
    int skinElement);


void __RPC_STUB IListRow_SetTextSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetBackgroundSkin_Proxy( 
    IListRow * This,
    int skinElement);


void __RPC_STUB IListRow_SetBackgroundSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetText_Proxy( 
    IListRow * This,
    BSTR text);


void __RPC_STUB IListRow_SetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_GetText_Proxy( 
    IListRow * This,
    /* [retval][out] */ BSTR *text);


void __RPC_STUB IListRow_GetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetDetailsText_Proxy( 
    IListRow * This,
    BSTR text);


void __RPC_STUB IListRow_SetDetailsText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_GetDetailsText_Proxy( 
    IListRow * This,
    /* [retval][out] */ BSTR *text);


void __RPC_STUB IListRow_GetDetailsText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_GetUserData_Proxy( 
    IListRow * This,
    int index,
    /* [retval][out] */ int *data);


void __RPC_STUB IListRow_GetUserData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetUserData_Proxy( 
    IListRow * This,
    int index,
    int value);


void __RPC_STUB IListRow_SetUserData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_GetUserData2_Proxy( 
    IListRow * This,
    int index,
    /* [retval][out] */ VARIANT *data);


void __RPC_STUB IListRow_GetUserData2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListRow_SetUserData2_Proxy( 
    IListRow * This,
    int index,
    VARIANT value);


void __RPC_STUB IListRow_SetUserData2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IListRow_INTERFACE_DEFINED__ */


#ifndef __IListOutput_INTERFACE_DEFINED__
#define __IListOutput_INTERFACE_DEFINED__

/* interface IListOutput */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IListOutput;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4A4A3ED5-F2F8-4bb4-BBCE-4EA1E0FFCEE2")
    IListOutput : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *listOutputParent,
            VARIANT_BOOL supportAutoScrolling) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Invalidate( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetImageList( 
            int himageList) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkinElement( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSkinElement( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowRowSeparator( 
            VARIANT_BOOL showSeparator) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE WrapText( 
            VARIANT_BOOL wrap) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetRightToLeft( 
            VARIANT_BOOL rightToLeft) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitHeight( 
            int width,
            /* [retval][out] */ int *height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddRow( 
            /* [retval][out] */ IListRow **pRow) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetRow( 
            int index,
            /* [retval][out] */ IListRow **row) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Size( 
            /* [retval][out] */ int *size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Delete( 
            IListRow *pRow) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFirstVisible( 
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetLastVisible( 
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHoverRow( 
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetRowRect( 
            IListRow *pRow,
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetRowFromPoint( 
            POINT pt,
            /* [retval][out] */ IListRow **row) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ScrollToPrev( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ScrollToNext( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIndent( 
            int image,
            int text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTabs( 
            int *tabs,
            int tabsCount) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TakeoverDetails( 
            IUnknown *details,
            IListRow *pRow) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ScrollToRow( 
            int index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *listOutputParent,
            VARIANT_BOOL supportAutoScrolling,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InsertRow( 
            int insertBefore,
            /* [retval][out] */ IListRow **pRow) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetAutoScrolling( 
            VARIANT_BOOL supportAutoScrolling) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetMaxFitRows( 
            /* [in] */ int maxFitRows) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTab( 
            int index,
            int value) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IListOutputVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IListOutput * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IListOutput * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IListOutput * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IListOutput * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IListOutput * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IListOutput * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IListOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *listOutputParent,
            VARIANT_BOOL supportAutoScrolling);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IListOutput * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IListOutput * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IListOutput * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            IListOutput * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IListOutput * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *Invalidate )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetImageList )( 
            IListOutput * This,
            int himageList);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkinElement )( 
            IListOutput * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetSkinElement )( 
            IListOutput * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *ShowRowSeparator )( 
            IListOutput * This,
            VARIANT_BOOL showSeparator);
        
        HRESULT ( STDMETHODCALLTYPE *WrapText )( 
            IListOutput * This,
            VARIANT_BOOL wrap);
        
        HRESULT ( STDMETHODCALLTYPE *SetRightToLeft )( 
            IListOutput * This,
            VARIANT_BOOL rightToLeft);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitHeight )( 
            IListOutput * This,
            int width,
            /* [retval][out] */ int *height);
        
        HRESULT ( STDMETHODCALLTYPE *AddRow )( 
            IListOutput * This,
            /* [retval][out] */ IListRow **pRow);
        
        HRESULT ( STDMETHODCALLTYPE *GetRow )( 
            IListOutput * This,
            int index,
            /* [retval][out] */ IListRow **row);
        
        HRESULT ( STDMETHODCALLTYPE *Size )( 
            IListOutput * This,
            /* [retval][out] */ int *size);
        
        HRESULT ( STDMETHODCALLTYPE *Delete )( 
            IListOutput * This,
            IListRow *pRow);
        
        HRESULT ( STDMETHODCALLTYPE *GetFirstVisible )( 
            IListOutput * This,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *GetLastVisible )( 
            IListOutput * This,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *GetHoverRow )( 
            IListOutput * This,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *Clear )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetRowRect )( 
            IListOutput * This,
            IListRow *pRow,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *GetRowFromPoint )( 
            IListOutput * This,
            POINT pt,
            /* [retval][out] */ IListRow **row);
        
        HRESULT ( STDMETHODCALLTYPE *ScrollToPrev )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *ScrollToNext )( 
            IListOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetIndent )( 
            IListOutput * This,
            int image,
            int text);
        
        HRESULT ( STDMETHODCALLTYPE *SetTabs )( 
            IListOutput * This,
            int *tabs,
            int tabsCount);
        
        HRESULT ( STDMETHODCALLTYPE *TakeoverDetails )( 
            IListOutput * This,
            IUnknown *details,
            IListRow *pRow);
        
        HRESULT ( STDMETHODCALLTYPE *ScrollToRow )( 
            IListOutput * This,
            int index);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            IListOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *listOutputParent,
            VARIANT_BOOL supportAutoScrolling,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            IListOutput * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *InsertRow )( 
            IListOutput * This,
            int insertBefore,
            /* [retval][out] */ IListRow **pRow);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            IListOutput * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            IListOutput * This,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetAutoScrolling )( 
            IListOutput * This,
            VARIANT_BOOL supportAutoScrolling);
        
        HRESULT ( STDMETHODCALLTYPE *SetMaxFitRows )( 
            IListOutput * This,
            /* [in] */ int maxFitRows);
        
        HRESULT ( STDMETHODCALLTYPE *SetTab )( 
            IListOutput * This,
            int index,
            int value);
        
        END_INTERFACE
    } IListOutputVtbl;

    interface IListOutput
    {
        CONST_VTBL struct IListOutputVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IListOutput_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IListOutput_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IListOutput_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IListOutput_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IListOutput_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IListOutput_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IListOutput_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IListOutput_Init(This,settings,skinManager,listOutputParent,supportAutoScrolling)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,listOutputParent,supportAutoScrolling)

#define IListOutput_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define IListOutput_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IListOutput_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IListOutput_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IListOutput_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define IListOutput_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IListOutput_Invalidate(This)	\
    (This)->lpVtbl -> Invalidate(This)

#define IListOutput_SetImageList(This,himageList)	\
    (This)->lpVtbl -> SetImageList(This,himageList)

#define IListOutput_SetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> SetSkinElement(This,skinElement)

#define IListOutput_GetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> GetSkinElement(This,skinElement)

#define IListOutput_ShowRowSeparator(This,showSeparator)	\
    (This)->lpVtbl -> ShowRowSeparator(This,showSeparator)

#define IListOutput_WrapText(This,wrap)	\
    (This)->lpVtbl -> WrapText(This,wrap)

#define IListOutput_SetRightToLeft(This,rightToLeft)	\
    (This)->lpVtbl -> SetRightToLeft(This,rightToLeft)

#define IListOutput_GetFitHeight(This,width,height)	\
    (This)->lpVtbl -> GetFitHeight(This,width,height)

#define IListOutput_AddRow(This,pRow)	\
    (This)->lpVtbl -> AddRow(This,pRow)

#define IListOutput_GetRow(This,index,row)	\
    (This)->lpVtbl -> GetRow(This,index,row)

#define IListOutput_Size(This,size)	\
    (This)->lpVtbl -> Size(This,size)

#define IListOutput_Delete(This,pRow)	\
    (This)->lpVtbl -> Delete(This,pRow)

#define IListOutput_GetFirstVisible(This,index)	\
    (This)->lpVtbl -> GetFirstVisible(This,index)

#define IListOutput_GetLastVisible(This,index)	\
    (This)->lpVtbl -> GetLastVisible(This,index)

#define IListOutput_GetHoverRow(This,index)	\
    (This)->lpVtbl -> GetHoverRow(This,index)

#define IListOutput_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define IListOutput_GetRowRect(This,pRow,rect)	\
    (This)->lpVtbl -> GetRowRect(This,pRow,rect)

#define IListOutput_GetRowFromPoint(This,pt,row)	\
    (This)->lpVtbl -> GetRowFromPoint(This,pt,row)

#define IListOutput_ScrollToPrev(This)	\
    (This)->lpVtbl -> ScrollToPrev(This)

#define IListOutput_ScrollToNext(This)	\
    (This)->lpVtbl -> ScrollToNext(This)

#define IListOutput_SetIndent(This,image,text)	\
    (This)->lpVtbl -> SetIndent(This,image,text)

#define IListOutput_SetTabs(This,tabs,tabsCount)	\
    (This)->lpVtbl -> SetTabs(This,tabs,tabsCount)

#define IListOutput_TakeoverDetails(This,details,pRow)	\
    (This)->lpVtbl -> TakeoverDetails(This,details,pRow)

#define IListOutput_ScrollToRow(This,index)	\
    (This)->lpVtbl -> ScrollToRow(This,index)

#define IListOutput_Init2(This,settings,skinManager,listOutputParent,supportAutoScrolling,identifier)	\
    (This)->lpVtbl -> Init2(This,settings,skinManager,listOutputParent,supportAutoScrolling,identifier)

#define IListOutput_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define IListOutput_InsertRow(This,insertBefore,pRow)	\
    (This)->lpVtbl -> InsertRow(This,insertBefore,pRow)

#define IListOutput_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define IListOutput_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define IListOutput_SetAutoScrolling(This,supportAutoScrolling)	\
    (This)->lpVtbl -> SetAutoScrolling(This,supportAutoScrolling)

#define IListOutput_SetMaxFitRows(This,maxFitRows)	\
    (This)->lpVtbl -> SetMaxFitRows(This,maxFitRows)

#define IListOutput_SetTab(This,index,value)	\
    (This)->lpVtbl -> SetTab(This,index,value)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IListOutput_Init_Proxy( 
    IListOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *listOutputParent,
    VARIANT_BOOL supportAutoScrolling);


void __RPC_STUB IListOutput_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Create_Proxy( 
    IListOutput * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB IListOutput_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetHwnd_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB IListOutput_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Close_Proxy( 
    IListOutput * This);


void __RPC_STUB IListOutput_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_MoveWindow_Proxy( 
    IListOutput * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IListOutput_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_ShowWindow_Proxy( 
    IListOutput * This,
    VARIANT_BOOL show);


void __RPC_STUB IListOutput_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetControlRect_Proxy( 
    IListOutput * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IListOutput_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Invalidate_Proxy( 
    IListOutput * This);


void __RPC_STUB IListOutput_Invalidate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetImageList_Proxy( 
    IListOutput * This,
    int himageList);


void __RPC_STUB IListOutput_SetImageList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetSkinElement_Proxy( 
    IListOutput * This,
    int skinElement);


void __RPC_STUB IListOutput_SetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetSkinElement_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB IListOutput_GetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_ShowRowSeparator_Proxy( 
    IListOutput * This,
    VARIANT_BOOL showSeparator);


void __RPC_STUB IListOutput_ShowRowSeparator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_WrapText_Proxy( 
    IListOutput * This,
    VARIANT_BOOL wrap);


void __RPC_STUB IListOutput_WrapText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetRightToLeft_Proxy( 
    IListOutput * This,
    VARIANT_BOOL rightToLeft);


void __RPC_STUB IListOutput_SetRightToLeft_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetFitHeight_Proxy( 
    IListOutput * This,
    int width,
    /* [retval][out] */ int *height);


void __RPC_STUB IListOutput_GetFitHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_AddRow_Proxy( 
    IListOutput * This,
    /* [retval][out] */ IListRow **pRow);


void __RPC_STUB IListOutput_AddRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetRow_Proxy( 
    IListOutput * This,
    int index,
    /* [retval][out] */ IListRow **row);


void __RPC_STUB IListOutput_GetRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Size_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *size);


void __RPC_STUB IListOutput_Size_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Delete_Proxy( 
    IListOutput * This,
    IListRow *pRow);


void __RPC_STUB IListOutput_Delete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetFirstVisible_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *index);


void __RPC_STUB IListOutput_GetFirstVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetLastVisible_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *index);


void __RPC_STUB IListOutput_GetLastVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetHoverRow_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *index);


void __RPC_STUB IListOutput_GetHoverRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Clear_Proxy( 
    IListOutput * This);


void __RPC_STUB IListOutput_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetRowRect_Proxy( 
    IListOutput * This,
    IListRow *pRow,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IListOutput_GetRowRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetRowFromPoint_Proxy( 
    IListOutput * This,
    POINT pt,
    /* [retval][out] */ IListRow **row);


void __RPC_STUB IListOutput_GetRowFromPoint_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_ScrollToPrev_Proxy( 
    IListOutput * This);


void __RPC_STUB IListOutput_ScrollToPrev_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_ScrollToNext_Proxy( 
    IListOutput * This);


void __RPC_STUB IListOutput_ScrollToNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetIndent_Proxy( 
    IListOutput * This,
    int image,
    int text);


void __RPC_STUB IListOutput_SetIndent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetTabs_Proxy( 
    IListOutput * This,
    int *tabs,
    int tabsCount);


void __RPC_STUB IListOutput_SetTabs_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_TakeoverDetails_Proxy( 
    IListOutput * This,
    IUnknown *details,
    IListRow *pRow);


void __RPC_STUB IListOutput_TakeoverDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_ScrollToRow_Proxy( 
    IListOutput * This,
    int index);


void __RPC_STUB IListOutput_ScrollToRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_Init2_Proxy( 
    IListOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *listOutputParent,
    VARIANT_BOOL supportAutoScrolling,
    int identifier);


void __RPC_STUB IListOutput_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_GetId_Proxy( 
    IListOutput * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB IListOutput_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_InsertRow_Proxy( 
    IListOutput * This,
    int insertBefore,
    /* [retval][out] */ IListRow **pRow);


void __RPC_STUB IListOutput_InsertRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetParent_Proxy( 
    IListOutput * This,
    IUnknown *parent);


void __RPC_STUB IListOutput_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetIdentifier_Proxy( 
    IListOutput * This,
    int identifier);


void __RPC_STUB IListOutput_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetAutoScrolling_Proxy( 
    IListOutput * This,
    VARIANT_BOOL supportAutoScrolling);


void __RPC_STUB IListOutput_SetAutoScrolling_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetMaxFitRows_Proxy( 
    IListOutput * This,
    /* [in] */ int maxFitRows);


void __RPC_STUB IListOutput_SetMaxFitRows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutput_SetTab_Proxy( 
    IListOutput * This,
    int index,
    int value);


void __RPC_STUB IListOutput_SetTab_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IListOutput_INTERFACE_DEFINED__ */


#ifndef __IListOutputParent_INTERFACE_DEFINED__
#define __IListOutputParent_INTERFACE_DEFINED__

/* interface IListOutputParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IListOutputParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B366F8B1-78FB-49e6-A9A7-E6EFF4B74A02")
    IListOutputParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            IListOutput *list,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            IListOutput *list,
            IListRow *row,
            VARIANT_BOOL dbclk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnHover( 
            IListOutput *list,
            IListRow *row) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnLeave( 
            IListOutput *list,
            IListRow *row) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnShowDetails( 
            IListOutput *list,
            IListRow *row) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnScrolled( 
            IListOutput *list) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IListOutputParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IListOutputParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IListOutputParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IListOutputParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IListOutputParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IListOutputParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IListOutputParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IListOutputParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            IListOutputParent * This,
            IListOutput *list,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            IListOutputParent * This,
            IListOutput *list,
            IListRow *row,
            VARIANT_BOOL dbclk);
        
        HRESULT ( STDMETHODCALLTYPE *OnHover )( 
            IListOutputParent * This,
            IListOutput *list,
            IListRow *row);
        
        HRESULT ( STDMETHODCALLTYPE *OnLeave )( 
            IListOutputParent * This,
            IListOutput *list,
            IListRow *row);
        
        HRESULT ( STDMETHODCALLTYPE *OnShowDetails )( 
            IListOutputParent * This,
            IListOutput *list,
            IListRow *row);
        
        HRESULT ( STDMETHODCALLTYPE *OnScrolled )( 
            IListOutputParent * This,
            IListOutput *list);
        
        END_INTERFACE
    } IListOutputParentVtbl;

    interface IListOutputParent
    {
        CONST_VTBL struct IListOutputParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IListOutputParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IListOutputParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IListOutputParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IListOutputParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IListOutputParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IListOutputParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IListOutputParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IListOutputParent_OnDrawBackground(This,list,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,list,graphics)

#define IListOutputParent_OnClick(This,list,row,dbclk)	\
    (This)->lpVtbl -> OnClick(This,list,row,dbclk)

#define IListOutputParent_OnHover(This,list,row)	\
    (This)->lpVtbl -> OnHover(This,list,row)

#define IListOutputParent_OnLeave(This,list,row)	\
    (This)->lpVtbl -> OnLeave(This,list,row)

#define IListOutputParent_OnShowDetails(This,list,row)	\
    (This)->lpVtbl -> OnShowDetails(This,list,row)

#define IListOutputParent_OnScrolled(This,list)	\
    (This)->lpVtbl -> OnScrolled(This,list)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IListOutputParent_OnDrawBackground_Proxy( 
    IListOutputParent * This,
    IListOutput *list,
    IGraphics *graphics);


void __RPC_STUB IListOutputParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutputParent_OnClick_Proxy( 
    IListOutputParent * This,
    IListOutput *list,
    IListRow *row,
    VARIANT_BOOL dbclk);


void __RPC_STUB IListOutputParent_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutputParent_OnHover_Proxy( 
    IListOutputParent * This,
    IListOutput *list,
    IListRow *row);


void __RPC_STUB IListOutputParent_OnHover_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutputParent_OnLeave_Proxy( 
    IListOutputParent * This,
    IListOutput *list,
    IListRow *row);


void __RPC_STUB IListOutputParent_OnLeave_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutputParent_OnShowDetails_Proxy( 
    IListOutputParent * This,
    IListOutput *list,
    IListRow *row);


void __RPC_STUB IListOutputParent_OnShowDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IListOutputParent_OnScrolled_Proxy( 
    IListOutputParent * This,
    IListOutput *list);


void __RPC_STUB IListOutputParent_OnScrolled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IListOutputParent_INTERFACE_DEFINED__ */


#ifndef __IMarqueeOutput_INTERFACE_DEFINED__
#define __IMarqueeOutput_INTERFACE_DEFINED__

/* interface IMarqueeOutput */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMarqueeOutput;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFA06A44-CFF1-4ede-8F9A-EE1DB900BB3D")
    IMarqueeOutput : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *marqueeOutputPparent,
            VARIANT_BOOL supportClick) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetText( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkinElement( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSkinElement( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitHeight( 
            /* [retval][out] */ int *height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSpeed( 
            int frequency,
            int delta) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TakeoverDetails( 
            IUnknown *details) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *marqueeOutputPparent,
            VARIANT_BOOL supportClick,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSupportClick( 
            VARIANT_BOOL supportClick) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMarqueeOutputVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMarqueeOutput * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMarqueeOutput * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMarqueeOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IMarqueeOutput * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IMarqueeOutput * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IMarqueeOutput * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IMarqueeOutput * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IMarqueeOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *marqueeOutputPparent,
            VARIANT_BOOL supportClick);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IMarqueeOutput * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IMarqueeOutput * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            IMarqueeOutput * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IMarqueeOutput * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            IMarqueeOutput * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IMarqueeOutput * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetText )( 
            IMarqueeOutput * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkinElement )( 
            IMarqueeOutput * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetSkinElement )( 
            IMarqueeOutput * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitHeight )( 
            IMarqueeOutput * This,
            /* [retval][out] */ int *height);
        
        HRESULT ( STDMETHODCALLTYPE *SetSpeed )( 
            IMarqueeOutput * This,
            int frequency,
            int delta);
        
        HRESULT ( STDMETHODCALLTYPE *TakeoverDetails )( 
            IMarqueeOutput * This,
            IUnknown *details);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            IMarqueeOutput * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *marqueeOutputPparent,
            VARIANT_BOOL supportClick,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            IMarqueeOutput * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            IMarqueeOutput * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            IMarqueeOutput * This,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetSupportClick )( 
            IMarqueeOutput * This,
            VARIANT_BOOL supportClick);
        
        END_INTERFACE
    } IMarqueeOutputVtbl;

    interface IMarqueeOutput
    {
        CONST_VTBL struct IMarqueeOutputVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMarqueeOutput_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMarqueeOutput_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMarqueeOutput_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMarqueeOutput_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMarqueeOutput_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMarqueeOutput_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMarqueeOutput_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMarqueeOutput_Init(This,settings,skinManager,marqueeOutputPparent,supportClick)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,marqueeOutputPparent,supportClick)

#define IMarqueeOutput_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define IMarqueeOutput_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IMarqueeOutput_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IMarqueeOutput_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IMarqueeOutput_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define IMarqueeOutput_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IMarqueeOutput_SetText(This,text)	\
    (This)->lpVtbl -> SetText(This,text)

#define IMarqueeOutput_SetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> SetSkinElement(This,skinElement)

#define IMarqueeOutput_GetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> GetSkinElement(This,skinElement)

#define IMarqueeOutput_GetFitHeight(This,height)	\
    (This)->lpVtbl -> GetFitHeight(This,height)

#define IMarqueeOutput_SetSpeed(This,frequency,delta)	\
    (This)->lpVtbl -> SetSpeed(This,frequency,delta)

#define IMarqueeOutput_TakeoverDetails(This,details)	\
    (This)->lpVtbl -> TakeoverDetails(This,details)

#define IMarqueeOutput_Init2(This,settings,skinManager,marqueeOutputPparent,supportClick,identifier)	\
    (This)->lpVtbl -> Init2(This,settings,skinManager,marqueeOutputPparent,supportClick,identifier)

#define IMarqueeOutput_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define IMarqueeOutput_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define IMarqueeOutput_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define IMarqueeOutput_SetSupportClick(This,supportClick)	\
    (This)->lpVtbl -> SetSupportClick(This,supportClick)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IMarqueeOutput_Init_Proxy( 
    IMarqueeOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *marqueeOutputPparent,
    VARIANT_BOOL supportClick);


void __RPC_STUB IMarqueeOutput_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_Create_Proxy( 
    IMarqueeOutput * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB IMarqueeOutput_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_GetHwnd_Proxy( 
    IMarqueeOutput * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB IMarqueeOutput_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_Close_Proxy( 
    IMarqueeOutput * This);


void __RPC_STUB IMarqueeOutput_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_MoveWindow_Proxy( 
    IMarqueeOutput * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IMarqueeOutput_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_ShowWindow_Proxy( 
    IMarqueeOutput * This,
    VARIANT_BOOL show);


void __RPC_STUB IMarqueeOutput_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_GetControlRect_Proxy( 
    IMarqueeOutput * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IMarqueeOutput_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetText_Proxy( 
    IMarqueeOutput * This,
    BSTR text);


void __RPC_STUB IMarqueeOutput_SetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetSkinElement_Proxy( 
    IMarqueeOutput * This,
    int skinElement);


void __RPC_STUB IMarqueeOutput_SetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_GetSkinElement_Proxy( 
    IMarqueeOutput * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB IMarqueeOutput_GetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_GetFitHeight_Proxy( 
    IMarqueeOutput * This,
    /* [retval][out] */ int *height);


void __RPC_STUB IMarqueeOutput_GetFitHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetSpeed_Proxy( 
    IMarqueeOutput * This,
    int frequency,
    int delta);


void __RPC_STUB IMarqueeOutput_SetSpeed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_TakeoverDetails_Proxy( 
    IMarqueeOutput * This,
    IUnknown *details);


void __RPC_STUB IMarqueeOutput_TakeoverDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_Init2_Proxy( 
    IMarqueeOutput * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *marqueeOutputPparent,
    VARIANT_BOOL supportClick,
    int identifier);


void __RPC_STUB IMarqueeOutput_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_GetId_Proxy( 
    IMarqueeOutput * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB IMarqueeOutput_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetParent_Proxy( 
    IMarqueeOutput * This,
    IUnknown *parent);


void __RPC_STUB IMarqueeOutput_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetIdentifier_Proxy( 
    IMarqueeOutput * This,
    int identifier);


void __RPC_STUB IMarqueeOutput_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutput_SetSupportClick_Proxy( 
    IMarqueeOutput * This,
    VARIANT_BOOL supportClick);


void __RPC_STUB IMarqueeOutput_SetSupportClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMarqueeOutput_INTERFACE_DEFINED__ */


#ifndef __IMarqueeOutputParent_INTERFACE_DEFINED__
#define __IMarqueeOutputParent_INTERFACE_DEFINED__

/* interface IMarqueeOutputParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMarqueeOutputParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5C9C2497-FA97-4b30-9CA5-DDE40D0DF09D")
    IMarqueeOutputParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            IMarqueeOutput *marquee,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            IMarqueeOutput *marquee,
            VARIANT_BOOL dbclk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseHover( 
            IMarqueeOutput *marquee) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseLeave( 
            IMarqueeOutput *marquee) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnShowDetails( 
            IMarqueeOutput *marquee) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMarqueeOutputParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IMarqueeOutputParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IMarqueeOutputParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IMarqueeOutputParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IMarqueeOutputParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IMarqueeOutputParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IMarqueeOutputParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IMarqueeOutputParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            IMarqueeOutputParent * This,
            IMarqueeOutput *marquee,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            IMarqueeOutputParent * This,
            IMarqueeOutput *marquee,
            VARIANT_BOOL dbclk);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseHover )( 
            IMarqueeOutputParent * This,
            IMarqueeOutput *marquee);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseLeave )( 
            IMarqueeOutputParent * This,
            IMarqueeOutput *marquee);
        
        HRESULT ( STDMETHODCALLTYPE *OnShowDetails )( 
            IMarqueeOutputParent * This,
            IMarqueeOutput *marquee);
        
        END_INTERFACE
    } IMarqueeOutputParentVtbl;

    interface IMarqueeOutputParent
    {
        CONST_VTBL struct IMarqueeOutputParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMarqueeOutputParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMarqueeOutputParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMarqueeOutputParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMarqueeOutputParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMarqueeOutputParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMarqueeOutputParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMarqueeOutputParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMarqueeOutputParent_OnDrawBackground(This,marquee,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,marquee,graphics)

#define IMarqueeOutputParent_OnClick(This,marquee,dbclk)	\
    (This)->lpVtbl -> OnClick(This,marquee,dbclk)

#define IMarqueeOutputParent_OnMouseHover(This,marquee)	\
    (This)->lpVtbl -> OnMouseHover(This,marquee)

#define IMarqueeOutputParent_OnMouseLeave(This,marquee)	\
    (This)->lpVtbl -> OnMouseLeave(This,marquee)

#define IMarqueeOutputParent_OnShowDetails(This,marquee)	\
    (This)->lpVtbl -> OnShowDetails(This,marquee)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IMarqueeOutputParent_OnDrawBackground_Proxy( 
    IMarqueeOutputParent * This,
    IMarqueeOutput *marquee,
    IGraphics *graphics);


void __RPC_STUB IMarqueeOutputParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutputParent_OnClick_Proxy( 
    IMarqueeOutputParent * This,
    IMarqueeOutput *marquee,
    VARIANT_BOOL dbclk);


void __RPC_STUB IMarqueeOutputParent_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutputParent_OnMouseHover_Proxy( 
    IMarqueeOutputParent * This,
    IMarqueeOutput *marquee);


void __RPC_STUB IMarqueeOutputParent_OnMouseHover_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutputParent_OnMouseLeave_Proxy( 
    IMarqueeOutputParent * This,
    IMarqueeOutput *marquee);


void __RPC_STUB IMarqueeOutputParent_OnMouseLeave_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMarqueeOutputParent_OnShowDetails_Proxy( 
    IMarqueeOutputParent * This,
    IMarqueeOutput *marquee);


void __RPC_STUB IMarqueeOutputParent_OnShowDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMarqueeOutputParent_INTERFACE_DEFINED__ */


#ifndef __ISkinButton_INTERFACE_DEFINED__
#define __ISkinButton_INTERFACE_DEFINED__

/* interface ISkinButton */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinButton;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5F81991B-361E-46c4-ACA6-2361DDD5AAD8")
    ISkinButton : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            ISkinManager *skinManager,
            IUnknown *skinButtonParent,
            int normalSkin,
            int checkedSkin,
            int commandId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetNormalSkin( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetNormalSkin( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCheckedSkin( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCheckedSkin( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsChecked( 
            /* [retval][out] */ VARIANT_BOOL *check) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCheck( 
            VARIANT_BOOL check) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandId( 
            /* [retval][out] */ int *id) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSize( 
            /* [retval][out] */ SIZE *size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetStyle( 
            int style) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCommandId( 
            int commandId) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinButtonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinButton * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinButton * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinButton * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinButton * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinButton * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinButton * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinButton * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ISkinButton * This,
            ISkinManager *skinManager,
            IUnknown *skinButtonParent,
            int normalSkin,
            int checkedSkin,
            int commandId);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ISkinButton * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ISkinButton * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            ISkinButton * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            ISkinButton * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            ISkinButton * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            ISkinButton * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetNormalSkin )( 
            ISkinButton * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetNormalSkin )( 
            ISkinButton * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *SetCheckedSkin )( 
            ISkinButton * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetCheckedSkin )( 
            ISkinButton * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *IsChecked )( 
            ISkinButton * This,
            /* [retval][out] */ VARIANT_BOOL *check);
        
        HRESULT ( STDMETHODCALLTYPE *SetCheck )( 
            ISkinButton * This,
            VARIANT_BOOL check);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandId )( 
            ISkinButton * This,
            /* [retval][out] */ int *id);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            ISkinButton * This,
            /* [retval][out] */ SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *SetStyle )( 
            ISkinButton * This,
            int style);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            ISkinButton * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetCommandId )( 
            ISkinButton * This,
            int commandId);
        
        END_INTERFACE
    } ISkinButtonVtbl;

    interface ISkinButton
    {
        CONST_VTBL struct ISkinButtonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinButton_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinButton_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinButton_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinButton_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinButton_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinButton_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinButton_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinButton_Init(This,skinManager,skinButtonParent,normalSkin,checkedSkin,commandId)	\
    (This)->lpVtbl -> Init(This,skinManager,skinButtonParent,normalSkin,checkedSkin,commandId)

#define ISkinButton_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define ISkinButton_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ISkinButton_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ISkinButton_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define ISkinButton_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define ISkinButton_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define ISkinButton_SetNormalSkin(This,skinElement)	\
    (This)->lpVtbl -> SetNormalSkin(This,skinElement)

#define ISkinButton_GetNormalSkin(This,skinElement)	\
    (This)->lpVtbl -> GetNormalSkin(This,skinElement)

#define ISkinButton_SetCheckedSkin(This,skinElement)	\
    (This)->lpVtbl -> SetCheckedSkin(This,skinElement)

#define ISkinButton_GetCheckedSkin(This,skinElement)	\
    (This)->lpVtbl -> GetCheckedSkin(This,skinElement)

#define ISkinButton_IsChecked(This,check)	\
    (This)->lpVtbl -> IsChecked(This,check)

#define ISkinButton_SetCheck(This,check)	\
    (This)->lpVtbl -> SetCheck(This,check)

#define ISkinButton_GetCommandId(This,id)	\
    (This)->lpVtbl -> GetCommandId(This,id)

#define ISkinButton_GetSize(This,size)	\
    (This)->lpVtbl -> GetSize(This,size)

#define ISkinButton_SetStyle(This,style)	\
    (This)->lpVtbl -> SetStyle(This,style)

#define ISkinButton_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define ISkinButton_SetCommandId(This,commandId)	\
    (This)->lpVtbl -> SetCommandId(This,commandId)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinButton_Init_Proxy( 
    ISkinButton * This,
    ISkinManager *skinManager,
    IUnknown *skinButtonParent,
    int normalSkin,
    int checkedSkin,
    int commandId);


void __RPC_STUB ISkinButton_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_Create_Proxy( 
    ISkinButton * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB ISkinButton_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetHwnd_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB ISkinButton_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_Close_Proxy( 
    ISkinButton * This);


void __RPC_STUB ISkinButton_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_MoveWindow_Proxy( 
    ISkinButton * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB ISkinButton_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_ShowWindow_Proxy( 
    ISkinButton * This,
    VARIANT_BOOL show);


void __RPC_STUB ISkinButton_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetControlRect_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB ISkinButton_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetNormalSkin_Proxy( 
    ISkinButton * This,
    int skinElement);


void __RPC_STUB ISkinButton_SetNormalSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetNormalSkin_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB ISkinButton_GetNormalSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetCheckedSkin_Proxy( 
    ISkinButton * This,
    int skinElement);


void __RPC_STUB ISkinButton_SetCheckedSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetCheckedSkin_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB ISkinButton_GetCheckedSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_IsChecked_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ VARIANT_BOOL *check);


void __RPC_STUB ISkinButton_IsChecked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetCheck_Proxy( 
    ISkinButton * This,
    VARIANT_BOOL check);


void __RPC_STUB ISkinButton_SetCheck_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetCommandId_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ int *id);


void __RPC_STUB ISkinButton_GetCommandId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_GetSize_Proxy( 
    ISkinButton * This,
    /* [retval][out] */ SIZE *size);


void __RPC_STUB ISkinButton_GetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetStyle_Proxy( 
    ISkinButton * This,
    int style);


void __RPC_STUB ISkinButton_SetStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetParent_Proxy( 
    ISkinButton * This,
    IUnknown *parent);


void __RPC_STUB ISkinButton_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButton_SetCommandId_Proxy( 
    ISkinButton * This,
    int commandId);


void __RPC_STUB ISkinButton_SetCommandId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinButton_INTERFACE_DEFINED__ */


#ifndef __ISkinButtonParent_INTERFACE_DEFINED__
#define __ISkinButtonParent_INTERFACE_DEFINED__

/* interface ISkinButtonParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinButtonParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FE1F6B9D-3F4D-4dd2-9275-1D3F11842D77")
    ISkinButtonParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            ISkinButton *button,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            ISkinButton *button,
            int commandId) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinButtonParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinButtonParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinButtonParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinButtonParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinButtonParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinButtonParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinButtonParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinButtonParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            ISkinButtonParent * This,
            ISkinButton *button,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            ISkinButtonParent * This,
            ISkinButton *button,
            int commandId);
        
        END_INTERFACE
    } ISkinButtonParentVtbl;

    interface ISkinButtonParent
    {
        CONST_VTBL struct ISkinButtonParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinButtonParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinButtonParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinButtonParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinButtonParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinButtonParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinButtonParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinButtonParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinButtonParent_OnDrawBackground(This,button,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,button,graphics)

#define ISkinButtonParent_OnClick(This,button,commandId)	\
    (This)->lpVtbl -> OnClick(This,button,commandId)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinButtonParent_OnDrawBackground_Proxy( 
    ISkinButtonParent * This,
    ISkinButton *button,
    IGraphics *graphics);


void __RPC_STUB ISkinButtonParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinButtonParent_OnClick_Proxy( 
    ISkinButtonParent * This,
    ISkinButton *button,
    int commandId);


void __RPC_STUB ISkinButtonParent_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinButtonParent_INTERFACE_DEFINED__ */


#ifndef __ISkinProgressBar_INTERFACE_DEFINED__
#define __ISkinProgressBar_INTERFACE_DEFINED__

/* interface ISkinProgressBar */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinProgressBar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("EEEB86C3-62B5-46af-8316-BAD7E103346A")
    ISkinProgressBar : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            ISkinManager *skinManager,
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkinElement( 
            int skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSkinElement( 
            /* [retval][out] */ int *skinElement) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetValue( 
            int value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            ISkinManager *skinManager,
            int skinElement,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetRange( 
            int rangeMin,
            int rangeMax) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinProgressBarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinProgressBar * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinProgressBar * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinProgressBar * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinProgressBar * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinProgressBar * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinProgressBar * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinProgressBar * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ISkinProgressBar * This,
            ISkinManager *skinManager,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ISkinProgressBar * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ISkinProgressBar * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            ISkinProgressBar * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            ISkinProgressBar * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            ISkinProgressBar * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            ISkinProgressBar * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkinElement )( 
            ISkinProgressBar * This,
            int skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *GetSkinElement )( 
            ISkinProgressBar * This,
            /* [retval][out] */ int *skinElement);
        
        HRESULT ( STDMETHODCALLTYPE *SetValue )( 
            ISkinProgressBar * This,
            int value);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            ISkinProgressBar * This,
            ISkinManager *skinManager,
            int skinElement,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            ISkinProgressBar * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            ISkinProgressBar * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            ISkinProgressBar * This,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetRange )( 
            ISkinProgressBar * This,
            int rangeMin,
            int rangeMax);
        
        END_INTERFACE
    } ISkinProgressBarVtbl;

    interface ISkinProgressBar
    {
        CONST_VTBL struct ISkinProgressBarVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinProgressBar_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinProgressBar_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinProgressBar_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinProgressBar_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinProgressBar_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinProgressBar_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinProgressBar_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinProgressBar_Init(This,skinManager,skinElement)	\
    (This)->lpVtbl -> Init(This,skinManager,skinElement)

#define ISkinProgressBar_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define ISkinProgressBar_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ISkinProgressBar_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ISkinProgressBar_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define ISkinProgressBar_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define ISkinProgressBar_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define ISkinProgressBar_SetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> SetSkinElement(This,skinElement)

#define ISkinProgressBar_GetSkinElement(This,skinElement)	\
    (This)->lpVtbl -> GetSkinElement(This,skinElement)

#define ISkinProgressBar_SetValue(This,value)	\
    (This)->lpVtbl -> SetValue(This,value)

#define ISkinProgressBar_Init2(This,skinManager,skinElement,identifier)	\
    (This)->lpVtbl -> Init2(This,skinManager,skinElement,identifier)

#define ISkinProgressBar_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define ISkinProgressBar_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define ISkinProgressBar_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define ISkinProgressBar_SetRange(This,rangeMin,rangeMax)	\
    (This)->lpVtbl -> SetRange(This,rangeMin,rangeMax)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinProgressBar_Init_Proxy( 
    ISkinProgressBar * This,
    ISkinManager *skinManager,
    int skinElement);


void __RPC_STUB ISkinProgressBar_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_Create_Proxy( 
    ISkinProgressBar * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB ISkinProgressBar_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_GetHwnd_Proxy( 
    ISkinProgressBar * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB ISkinProgressBar_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_Close_Proxy( 
    ISkinProgressBar * This);


void __RPC_STUB ISkinProgressBar_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_MoveWindow_Proxy( 
    ISkinProgressBar * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB ISkinProgressBar_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_ShowWindow_Proxy( 
    ISkinProgressBar * This,
    VARIANT_BOOL show);


void __RPC_STUB ISkinProgressBar_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_GetControlRect_Proxy( 
    ISkinProgressBar * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB ISkinProgressBar_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_SetSkinElement_Proxy( 
    ISkinProgressBar * This,
    int skinElement);


void __RPC_STUB ISkinProgressBar_SetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_GetSkinElement_Proxy( 
    ISkinProgressBar * This,
    /* [retval][out] */ int *skinElement);


void __RPC_STUB ISkinProgressBar_GetSkinElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_SetValue_Proxy( 
    ISkinProgressBar * This,
    int value);


void __RPC_STUB ISkinProgressBar_SetValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_Init2_Proxy( 
    ISkinProgressBar * This,
    ISkinManager *skinManager,
    int skinElement,
    int identifier);


void __RPC_STUB ISkinProgressBar_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_GetId_Proxy( 
    ISkinProgressBar * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB ISkinProgressBar_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_SetParent_Proxy( 
    ISkinProgressBar * This,
    IUnknown *parent);


void __RPC_STUB ISkinProgressBar_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_SetIdentifier_Proxy( 
    ISkinProgressBar * This,
    int identifier);


void __RPC_STUB ISkinProgressBar_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinProgressBar_SetRange_Proxy( 
    ISkinProgressBar * This,
    int rangeMin,
    int rangeMax);


void __RPC_STUB ISkinProgressBar_SetRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinProgressBar_INTERFACE_DEFINED__ */


#ifndef __ISkinSlider_INTERFACE_DEFINED__
#define __ISkinSlider_INTERFACE_DEFINED__

/* interface ISkinSlider */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinSlider;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8CD72B0A-EC32-47a5-83EF-4C9304F2AC41")
    ISkinSlider : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            ISkinManager *skinManager,
            IUnknown *sliderParent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetValue( 
            int value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetRange( 
            int iMin,
            int iMax) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            ISkinManager *skinManager,
            IUnknown *sliderParent,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            /* [in] */ int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkin( 
            int sliderSkin,
            int sliderButtonSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSliderSkin( 
            /* [retval][out] */ int *sliderSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSliderButtonSkin( 
            /* [retval][out] */ int *sliderButtonSkin) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinSliderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinSlider * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinSlider * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinSlider * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinSlider * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinSlider * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinSlider * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinSlider * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ISkinSlider * This,
            ISkinManager *skinManager,
            IUnknown *sliderParent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ISkinSlider * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ISkinSlider * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            ISkinSlider * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            ISkinSlider * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            ISkinSlider * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            ISkinSlider * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetValue )( 
            ISkinSlider * This,
            int value);
        
        HRESULT ( STDMETHODCALLTYPE *SetRange )( 
            ISkinSlider * This,
            int iMin,
            int iMax);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            ISkinSlider * This,
            ISkinManager *skinManager,
            IUnknown *sliderParent,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            ISkinSlider * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            ISkinSlider * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            ISkinSlider * This,
            /* [in] */ int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkin )( 
            ISkinSlider * This,
            int sliderSkin,
            int sliderButtonSkin);
        
        HRESULT ( STDMETHODCALLTYPE *GetSliderSkin )( 
            ISkinSlider * This,
            /* [retval][out] */ int *sliderSkin);
        
        HRESULT ( STDMETHODCALLTYPE *GetSliderButtonSkin )( 
            ISkinSlider * This,
            /* [retval][out] */ int *sliderButtonSkin);
        
        END_INTERFACE
    } ISkinSliderVtbl;

    interface ISkinSlider
    {
        CONST_VTBL struct ISkinSliderVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinSlider_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinSlider_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinSlider_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinSlider_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinSlider_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinSlider_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinSlider_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinSlider_Init(This,skinManager,sliderParent)	\
    (This)->lpVtbl -> Init(This,skinManager,sliderParent)

#define ISkinSlider_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define ISkinSlider_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ISkinSlider_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ISkinSlider_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define ISkinSlider_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define ISkinSlider_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define ISkinSlider_SetValue(This,value)	\
    (This)->lpVtbl -> SetValue(This,value)

#define ISkinSlider_SetRange(This,iMin,iMax)	\
    (This)->lpVtbl -> SetRange(This,iMin,iMax)

#define ISkinSlider_Init2(This,skinManager,sliderParent,identifier)	\
    (This)->lpVtbl -> Init2(This,skinManager,sliderParent,identifier)

#define ISkinSlider_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define ISkinSlider_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define ISkinSlider_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define ISkinSlider_SetSkin(This,sliderSkin,sliderButtonSkin)	\
    (This)->lpVtbl -> SetSkin(This,sliderSkin,sliderButtonSkin)

#define ISkinSlider_GetSliderSkin(This,sliderSkin)	\
    (This)->lpVtbl -> GetSliderSkin(This,sliderSkin)

#define ISkinSlider_GetSliderButtonSkin(This,sliderButtonSkin)	\
    (This)->lpVtbl -> GetSliderButtonSkin(This,sliderButtonSkin)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinSlider_Init_Proxy( 
    ISkinSlider * This,
    ISkinManager *skinManager,
    IUnknown *sliderParent);


void __RPC_STUB ISkinSlider_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_Create_Proxy( 
    ISkinSlider * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB ISkinSlider_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_GetHwnd_Proxy( 
    ISkinSlider * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB ISkinSlider_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_Close_Proxy( 
    ISkinSlider * This);


void __RPC_STUB ISkinSlider_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_MoveWindow_Proxy( 
    ISkinSlider * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB ISkinSlider_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_ShowWindow_Proxy( 
    ISkinSlider * This,
    VARIANT_BOOL show);


void __RPC_STUB ISkinSlider_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_GetControlRect_Proxy( 
    ISkinSlider * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB ISkinSlider_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_SetValue_Proxy( 
    ISkinSlider * This,
    int value);


void __RPC_STUB ISkinSlider_SetValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_SetRange_Proxy( 
    ISkinSlider * This,
    int iMin,
    int iMax);


void __RPC_STUB ISkinSlider_SetRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_Init2_Proxy( 
    ISkinSlider * This,
    ISkinManager *skinManager,
    IUnknown *sliderParent,
    int identifier);


void __RPC_STUB ISkinSlider_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_GetId_Proxy( 
    ISkinSlider * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB ISkinSlider_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_SetParent_Proxy( 
    ISkinSlider * This,
    IUnknown *parent);


void __RPC_STUB ISkinSlider_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_SetIdentifier_Proxy( 
    ISkinSlider * This,
    /* [in] */ int identifier);


void __RPC_STUB ISkinSlider_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_SetSkin_Proxy( 
    ISkinSlider * This,
    int sliderSkin,
    int sliderButtonSkin);


void __RPC_STUB ISkinSlider_SetSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_GetSliderSkin_Proxy( 
    ISkinSlider * This,
    /* [retval][out] */ int *sliderSkin);


void __RPC_STUB ISkinSlider_GetSliderSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSlider_GetSliderButtonSkin_Proxy( 
    ISkinSlider * This,
    /* [retval][out] */ int *sliderButtonSkin);


void __RPC_STUB ISkinSlider_GetSliderButtonSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinSlider_INTERFACE_DEFINED__ */


#ifndef __ISkinSliderParent_INTERFACE_DEFINED__
#define __ISkinSliderParent_INTERFACE_DEFINED__

/* interface ISkinSliderParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISkinSliderParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0534BDFA-3BFC-4766-BF69-AB9A2334EEE7")
    ISkinSliderParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            ISkinSlider *slider,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnValueChanged( 
            ISkinSlider *slider,
            int value) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISkinSliderParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISkinSliderParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISkinSliderParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISkinSliderParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISkinSliderParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISkinSliderParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISkinSliderParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISkinSliderParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            ISkinSliderParent * This,
            ISkinSlider *slider,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnValueChanged )( 
            ISkinSliderParent * This,
            ISkinSlider *slider,
            int value);
        
        END_INTERFACE
    } ISkinSliderParentVtbl;

    interface ISkinSliderParent
    {
        CONST_VTBL struct ISkinSliderParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISkinSliderParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISkinSliderParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISkinSliderParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISkinSliderParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISkinSliderParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISkinSliderParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISkinSliderParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISkinSliderParent_OnDrawBackground(This,slider,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,slider,graphics)

#define ISkinSliderParent_OnValueChanged(This,slider,value)	\
    (This)->lpVtbl -> OnValueChanged(This,slider,value)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISkinSliderParent_OnDrawBackground_Proxy( 
    ISkinSliderParent * This,
    ISkinSlider *slider,
    IGraphics *graphics);


void __RPC_STUB ISkinSliderParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISkinSliderParent_OnValueChanged_Proxy( 
    ISkinSliderParent * This,
    ISkinSlider *slider,
    int value);


void __RPC_STUB ISkinSliderParent_OnValueChanged_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISkinSliderParent_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0291 */
/* [local] */ 


enum EBarChartType
    {	BarChartProcent	= 0,
	BarChartRaw	= BarChartProcent + 1,
	VerticalBarChartRaw	= BarChartRaw + 1,
	HorizontalBarChartRaw	= VerticalBarChartRaw + 1,
	GraphChart	= HorizontalBarChartRaw + 1,
	HistogramChart	= GraphChart + 1,
	HorizontalProgressChart	= HistogramChart + 1,
	VerticalProgressChart	= HorizontalProgressChart + 1,
	AnalogChart	= VerticalProgressChart + 1,
	PieChart	= AnalogChart + 1,
	TextChart	= PieChart + 1
    } ;
typedef EBarCharType;


enum EChartTextPosition
    {	HorizontalLeftChartText	= 0,
	HorizontalRightChartText	= HorizontalLeftChartText + 1,
	HorizontalTopChartText	= HorizontalRightChartText + 1,
	HorizontalBottomChartText	= HorizontalTopChartText + 1,
	VerticalLeftChartText	= HorizontalBottomChartText + 1,
	VerticalRightChartText	= VerticalLeftChartText + 1,
	VerticalTopChartText	= VerticalRightChartText + 1,
	VerticalBottomChartText	= VerticalTopChartText + 1,
	InvisibleChartText	= VerticalBottomChartText + 1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0291_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0291_v0_0_s_ifspec;

#ifndef __IBarChart_INTERFACE_DEFINED__
#define __IBarChart_INTERFACE_DEFINED__

/* interface IBarChart */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IBarChart;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("824D94A7-5E51-42b2-8702-C6C3F701E492")
    IBarChart : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *barChartParent,
            BSTR label) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            VARIANT_BOOL visible) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowWindow( 
            VARIANT_BOOL show) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetValue( 
            int value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetType( 
            int type) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Init2( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *barChartParent,
            BSTR label,
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetId( 
            /* [retval][out] */ int *identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetParent( 
            IUnknown *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetValueD( 
            double value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetRangeD( 
            double min,
            double max) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetLabel( 
            BSTR label) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitSize( 
            BSTR text,
            SIZE *sz) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTextPosition( 
            int position) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetChartSize( 
            SIZE size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetValueType( 
            int showValue,
            BSTR suffix) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTextColor( 
            DWORD argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIdentifier( 
            int identifier) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSkin( 
            int barChartSkin,
            int backgroundSkin,
            int outlineSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBarChartSkin( 
            /* [retval][out] */ int *barChartSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBackgroundSkin( 
            /* [retval][out] */ int *backgroundSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetOutlineSkin( 
            /* [retval][out] */ int *outlineSkin) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE TakeoverDetails( 
            IUnknown *details) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBarChartVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBarChart * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBarChart * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBarChart * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBarChart * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBarChart * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBarChart * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBarChart * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IBarChart * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *barChartParent,
            BSTR label);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IBarChart * This,
            int hwndParent,
            VARIANT_BOOL visible);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IBarChart * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            IBarChart * This);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IBarChart * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowWindow )( 
            IBarChart * This,
            VARIANT_BOOL show);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IBarChart * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetValue )( 
            IBarChart * This,
            int value);
        
        HRESULT ( STDMETHODCALLTYPE *SetType )( 
            IBarChart * This,
            int type);
        
        HRESULT ( STDMETHODCALLTYPE *Init2 )( 
            IBarChart * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *barChartParent,
            BSTR label,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *GetId )( 
            IBarChart * This,
            /* [retval][out] */ int *identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetParent )( 
            IBarChart * This,
            IUnknown *parent);
        
        HRESULT ( STDMETHODCALLTYPE *SetValueD )( 
            IBarChart * This,
            double value);
        
        HRESULT ( STDMETHODCALLTYPE *SetRangeD )( 
            IBarChart * This,
            double min,
            double max);
        
        HRESULT ( STDMETHODCALLTYPE *SetLabel )( 
            IBarChart * This,
            BSTR label);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitSize )( 
            IBarChart * This,
            BSTR text,
            SIZE *sz);
        
        HRESULT ( STDMETHODCALLTYPE *SetTextPosition )( 
            IBarChart * This,
            int position);
        
        HRESULT ( STDMETHODCALLTYPE *SetChartSize )( 
            IBarChart * This,
            SIZE size);
        
        HRESULT ( STDMETHODCALLTYPE *SetValueType )( 
            IBarChart * This,
            int showValue,
            BSTR suffix);
        
        HRESULT ( STDMETHODCALLTYPE *SetTextColor )( 
            IBarChart * This,
            DWORD argb);
        
        HRESULT ( STDMETHODCALLTYPE *SetIdentifier )( 
            IBarChart * This,
            int identifier);
        
        HRESULT ( STDMETHODCALLTYPE *SetSkin )( 
            IBarChart * This,
            int barChartSkin,
            int backgroundSkin,
            int outlineSkin);
        
        HRESULT ( STDMETHODCALLTYPE *GetBarChartSkin )( 
            IBarChart * This,
            /* [retval][out] */ int *barChartSkin);
        
        HRESULT ( STDMETHODCALLTYPE *GetBackgroundSkin )( 
            IBarChart * This,
            /* [retval][out] */ int *backgroundSkin);
        
        HRESULT ( STDMETHODCALLTYPE *GetOutlineSkin )( 
            IBarChart * This,
            /* [retval][out] */ int *outlineSkin);
        
        HRESULT ( STDMETHODCALLTYPE *TakeoverDetails )( 
            IBarChart * This,
            IUnknown *details);
        
        END_INTERFACE
    } IBarChartVtbl;

    interface IBarChart
    {
        CONST_VTBL struct IBarChartVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBarChart_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBarChart_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBarChart_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBarChart_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IBarChart_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IBarChart_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IBarChart_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IBarChart_Init(This,settings,skinManager,barChartParent,label)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,barChartParent,label)

#define IBarChart_Create(This,hwndParent,visible)	\
    (This)->lpVtbl -> Create(This,hwndParent,visible)

#define IBarChart_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IBarChart_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IBarChart_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IBarChart_ShowWindow(This,show)	\
    (This)->lpVtbl -> ShowWindow(This,show)

#define IBarChart_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IBarChart_SetValue(This,value)	\
    (This)->lpVtbl -> SetValue(This,value)

#define IBarChart_SetType(This,type)	\
    (This)->lpVtbl -> SetType(This,type)

#define IBarChart_Init2(This,settings,skinManager,barChartParent,label,identifier)	\
    (This)->lpVtbl -> Init2(This,settings,skinManager,barChartParent,label,identifier)

#define IBarChart_GetId(This,identifier)	\
    (This)->lpVtbl -> GetId(This,identifier)

#define IBarChart_SetParent(This,parent)	\
    (This)->lpVtbl -> SetParent(This,parent)

#define IBarChart_SetValueD(This,value)	\
    (This)->lpVtbl -> SetValueD(This,value)

#define IBarChart_SetRangeD(This,min,max)	\
    (This)->lpVtbl -> SetRangeD(This,min,max)

#define IBarChart_SetLabel(This,label)	\
    (This)->lpVtbl -> SetLabel(This,label)

#define IBarChart_GetFitSize(This,text,sz)	\
    (This)->lpVtbl -> GetFitSize(This,text,sz)

#define IBarChart_SetTextPosition(This,position)	\
    (This)->lpVtbl -> SetTextPosition(This,position)

#define IBarChart_SetChartSize(This,size)	\
    (This)->lpVtbl -> SetChartSize(This,size)

#define IBarChart_SetValueType(This,showValue,suffix)	\
    (This)->lpVtbl -> SetValueType(This,showValue,suffix)

#define IBarChart_SetTextColor(This,argb)	\
    (This)->lpVtbl -> SetTextColor(This,argb)

#define IBarChart_SetIdentifier(This,identifier)	\
    (This)->lpVtbl -> SetIdentifier(This,identifier)

#define IBarChart_SetSkin(This,barChartSkin,backgroundSkin,outlineSkin)	\
    (This)->lpVtbl -> SetSkin(This,barChartSkin,backgroundSkin,outlineSkin)

#define IBarChart_GetBarChartSkin(This,barChartSkin)	\
    (This)->lpVtbl -> GetBarChartSkin(This,barChartSkin)

#define IBarChart_GetBackgroundSkin(This,backgroundSkin)	\
    (This)->lpVtbl -> GetBackgroundSkin(This,backgroundSkin)

#define IBarChart_GetOutlineSkin(This,outlineSkin)	\
    (This)->lpVtbl -> GetOutlineSkin(This,outlineSkin)

#define IBarChart_TakeoverDetails(This,details)	\
    (This)->lpVtbl -> TakeoverDetails(This,details)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IBarChart_Init_Proxy( 
    IBarChart * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *barChartParent,
    BSTR label);


void __RPC_STUB IBarChart_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_Create_Proxy( 
    IBarChart * This,
    int hwndParent,
    VARIANT_BOOL visible);


void __RPC_STUB IBarChart_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetHwnd_Proxy( 
    IBarChart * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB IBarChart_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_Close_Proxy( 
    IBarChart * This);


void __RPC_STUB IBarChart_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_MoveWindow_Proxy( 
    IBarChart * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IBarChart_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_ShowWindow_Proxy( 
    IBarChart * This,
    VARIANT_BOOL show);


void __RPC_STUB IBarChart_ShowWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetControlRect_Proxy( 
    IBarChart * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IBarChart_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetValue_Proxy( 
    IBarChart * This,
    int value);


void __RPC_STUB IBarChart_SetValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetType_Proxy( 
    IBarChart * This,
    int type);


void __RPC_STUB IBarChart_SetType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_Init2_Proxy( 
    IBarChart * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *barChartParent,
    BSTR label,
    int identifier);


void __RPC_STUB IBarChart_Init2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetId_Proxy( 
    IBarChart * This,
    /* [retval][out] */ int *identifier);


void __RPC_STUB IBarChart_GetId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetParent_Proxy( 
    IBarChart * This,
    IUnknown *parent);


void __RPC_STUB IBarChart_SetParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetValueD_Proxy( 
    IBarChart * This,
    double value);


void __RPC_STUB IBarChart_SetValueD_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetRangeD_Proxy( 
    IBarChart * This,
    double min,
    double max);


void __RPC_STUB IBarChart_SetRangeD_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetLabel_Proxy( 
    IBarChart * This,
    BSTR label);


void __RPC_STUB IBarChart_SetLabel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetFitSize_Proxy( 
    IBarChart * This,
    BSTR text,
    SIZE *sz);


void __RPC_STUB IBarChart_GetFitSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetTextPosition_Proxy( 
    IBarChart * This,
    int position);


void __RPC_STUB IBarChart_SetTextPosition_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetChartSize_Proxy( 
    IBarChart * This,
    SIZE size);


void __RPC_STUB IBarChart_SetChartSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetValueType_Proxy( 
    IBarChart * This,
    int showValue,
    BSTR suffix);


void __RPC_STUB IBarChart_SetValueType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetTextColor_Proxy( 
    IBarChart * This,
    DWORD argb);


void __RPC_STUB IBarChart_SetTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetIdentifier_Proxy( 
    IBarChart * This,
    int identifier);


void __RPC_STUB IBarChart_SetIdentifier_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_SetSkin_Proxy( 
    IBarChart * This,
    int barChartSkin,
    int backgroundSkin,
    int outlineSkin);


void __RPC_STUB IBarChart_SetSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetBarChartSkin_Proxy( 
    IBarChart * This,
    /* [retval][out] */ int *barChartSkin);


void __RPC_STUB IBarChart_GetBarChartSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetBackgroundSkin_Proxy( 
    IBarChart * This,
    /* [retval][out] */ int *backgroundSkin);


void __RPC_STUB IBarChart_GetBackgroundSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_GetOutlineSkin_Proxy( 
    IBarChart * This,
    /* [retval][out] */ int *outlineSkin);


void __RPC_STUB IBarChart_GetOutlineSkin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChart_TakeoverDetails_Proxy( 
    IBarChart * This,
    IUnknown *details);


void __RPC_STUB IBarChart_TakeoverDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBarChart_INTERFACE_DEFINED__ */


#ifndef __IBarChartParent_INTERFACE_DEFINED__
#define __IBarChartParent_INTERFACE_DEFINED__

/* interface IBarChartParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IBarChartParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2AF6728B-DF69-4430-947F-FB70D895729D")
    IBarChartParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDrawBackground( 
            IBarChart *barchart,
            IGraphics *graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            IBarChart *barchart,
            VARIANT_BOOL dbclk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseHover( 
            IBarChart *barchart) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseLeave( 
            IBarChart *barchart) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnShowDetails( 
            IBarChart *barchart) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBarChartParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBarChartParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBarChartParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBarChartParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBarChartParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBarChartParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBarChartParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBarChartParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnDrawBackground )( 
            IBarChartParent * This,
            IBarChart *barchart,
            IGraphics *graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            IBarChartParent * This,
            IBarChart *barchart,
            VARIANT_BOOL dbclk);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseHover )( 
            IBarChartParent * This,
            IBarChart *barchart);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseLeave )( 
            IBarChartParent * This,
            IBarChart *barchart);
        
        HRESULT ( STDMETHODCALLTYPE *OnShowDetails )( 
            IBarChartParent * This,
            IBarChart *barchart);
        
        END_INTERFACE
    } IBarChartParentVtbl;

    interface IBarChartParent
    {
        CONST_VTBL struct IBarChartParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBarChartParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBarChartParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBarChartParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBarChartParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IBarChartParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IBarChartParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IBarChartParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IBarChartParent_OnDrawBackground(This,barchart,graphics)	\
    (This)->lpVtbl -> OnDrawBackground(This,barchart,graphics)

#define IBarChartParent_OnClick(This,barchart,dbclk)	\
    (This)->lpVtbl -> OnClick(This,barchart,dbclk)

#define IBarChartParent_OnMouseHover(This,barchart)	\
    (This)->lpVtbl -> OnMouseHover(This,barchart)

#define IBarChartParent_OnMouseLeave(This,barchart)	\
    (This)->lpVtbl -> OnMouseLeave(This,barchart)

#define IBarChartParent_OnShowDetails(This,barchart)	\
    (This)->lpVtbl -> OnShowDetails(This,barchart)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IBarChartParent_OnDrawBackground_Proxy( 
    IBarChartParent * This,
    IBarChart *barchart,
    IGraphics *graphics);


void __RPC_STUB IBarChartParent_OnDrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChartParent_OnClick_Proxy( 
    IBarChartParent * This,
    IBarChart *barchart,
    VARIANT_BOOL dbclk);


void __RPC_STUB IBarChartParent_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChartParent_OnMouseHover_Proxy( 
    IBarChartParent * This,
    IBarChart *barchart);


void __RPC_STUB IBarChartParent_OnMouseHover_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChartParent_OnMouseLeave_Proxy( 
    IBarChartParent * This,
    IBarChart *barchart);


void __RPC_STUB IBarChartParent_OnMouseLeave_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IBarChartParent_OnShowDetails_Proxy( 
    IBarChartParent * This,
    IBarChart *barchart);


void __RPC_STUB IBarChartParent_OnShowDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBarChartParent_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0293 */
/* [local] */ 


enum EFillMode
    {	ETile	= 0,
	EStretch	= ETile + 1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0293_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0293_v0_0_s_ifspec;

#ifndef __IImage_INTERFACE_DEFINED__
#define __IImage_INTERFACE_DEFINED__

/* interface IImage */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IImage;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6FD348B9-ED87-4199-994C-5241006064F3")
    IImage : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetControlEventHandler( 
            IUnknown *parent) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_name( 
            /* [retval][out] */ BSTR *name) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_display( 
            /* [in] */ VARIANT_BOOL display) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_display( 
            /* [retval][out] */ VARIANT_BOOL *display) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_visible( 
            /* [in] */ VARIANT_BOOL visible) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_visible( 
            /* [retval][out] */ VARIANT_BOOL *visible) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_x( 
            /* [in] */ int x) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_x( 
            /* [retval][out] */ int *x) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_y( 
            /* [in] */ int y) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_y( 
            /* [retval][out] */ int *y) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_height( 
            /* [in] */ int height) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_height( 
            /* [retval][out] */ int *height) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_width( 
            /* [in] */ int width) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_width( 
            /* [retval][out] */ int *width) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_zorder( 
            /* [in] */ int zorder) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_zorder( 
            /* [retval][out] */ int *zorder) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_opacity( 
            int opacity) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_opacity( 
            /* [retval][out] */ int *opacity) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_tooltip( 
            /* [in] */ BSTR tooltip) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_tooltip( 
            /* [retval][out] */ BSTR *tooltip) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_src( 
            BSTR path) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_src( 
            /* [retval][out] */ BSTR *path) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_fillmode( 
            enum EFillMode mode) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_fillmode( 
            /* [retval][out] */ enum EFillMode *mode) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_rotation( 
            int rotation) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_rotation( 
            /* [retval][out] */ int *rotation) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_rotation_x( 
            /* [in] */ int x) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_rotation_x( 
            /* [retval][out] */ int *x) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_rotation_y( 
            /* [in] */ int y) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_rotation_y( 
            /* [retval][out] */ int *y) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Reload( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IImageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IImage * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IImage * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IImage * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IImage * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IImage * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IImage * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IImage * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IImage * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IImage * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IImage * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetControlEventHandler )( 
            IImage * This,
            IUnknown *parent);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_name )( 
            IImage * This,
            /* [retval][out] */ BSTR *name);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_display )( 
            IImage * This,
            /* [in] */ VARIANT_BOOL display);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_display )( 
            IImage * This,
            /* [retval][out] */ VARIANT_BOOL *display);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_visible )( 
            IImage * This,
            /* [in] */ VARIANT_BOOL visible);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_visible )( 
            IImage * This,
            /* [retval][out] */ VARIANT_BOOL *visible);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_x )( 
            IImage * This,
            /* [in] */ int x);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_x )( 
            IImage * This,
            /* [retval][out] */ int *x);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_y )( 
            IImage * This,
            /* [in] */ int y);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_y )( 
            IImage * This,
            /* [retval][out] */ int *y);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_height )( 
            IImage * This,
            /* [in] */ int height);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_height )( 
            IImage * This,
            /* [retval][out] */ int *height);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_width )( 
            IImage * This,
            /* [in] */ int width);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_width )( 
            IImage * This,
            /* [retval][out] */ int *width);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_zorder )( 
            IImage * This,
            /* [in] */ int zorder);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_zorder )( 
            IImage * This,
            /* [retval][out] */ int *zorder);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_opacity )( 
            IImage * This,
            int opacity);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_opacity )( 
            IImage * This,
            /* [retval][out] */ int *opacity);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_tooltip )( 
            IImage * This,
            /* [in] */ BSTR tooltip);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_tooltip )( 
            IImage * This,
            /* [retval][out] */ BSTR *tooltip);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_src )( 
            IImage * This,
            BSTR path);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_src )( 
            IImage * This,
            /* [retval][out] */ BSTR *path);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_fillmode )( 
            IImage * This,
            enum EFillMode mode);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_fillmode )( 
            IImage * This,
            /* [retval][out] */ enum EFillMode *mode);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_rotation )( 
            IImage * This,
            int rotation);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_rotation )( 
            IImage * This,
            /* [retval][out] */ int *rotation);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_rotation_x )( 
            IImage * This,
            /* [in] */ int x);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_rotation_x )( 
            IImage * This,
            /* [retval][out] */ int *x);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_rotation_y )( 
            IImage * This,
            /* [in] */ int y);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_rotation_y )( 
            IImage * This,
            /* [retval][out] */ int *y);
        
        HRESULT ( STDMETHODCALLTYPE *Reload )( 
            IImage * This);
        
        END_INTERFACE
    } IImageVtbl;

    interface IImage
    {
        CONST_VTBL struct IImageVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IImage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IImage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IImage_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IImage_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IImage_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IImage_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IImage_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IImage_Init(This,settings,skinManager)	\
    (This)->lpVtbl -> Init(This,settings,skinManager)

#define IImage_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IImage_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IImage_SetControlEventHandler(This,parent)	\
    (This)->lpVtbl -> SetControlEventHandler(This,parent)

#define IImage_get_name(This,name)	\
    (This)->lpVtbl -> get_name(This,name)

#define IImage_put_display(This,display)	\
    (This)->lpVtbl -> put_display(This,display)

#define IImage_get_display(This,display)	\
    (This)->lpVtbl -> get_display(This,display)

#define IImage_put_visible(This,visible)	\
    (This)->lpVtbl -> put_visible(This,visible)

#define IImage_get_visible(This,visible)	\
    (This)->lpVtbl -> get_visible(This,visible)

#define IImage_put_x(This,x)	\
    (This)->lpVtbl -> put_x(This,x)

#define IImage_get_x(This,x)	\
    (This)->lpVtbl -> get_x(This,x)

#define IImage_put_y(This,y)	\
    (This)->lpVtbl -> put_y(This,y)

#define IImage_get_y(This,y)	\
    (This)->lpVtbl -> get_y(This,y)

#define IImage_put_height(This,height)	\
    (This)->lpVtbl -> put_height(This,height)

#define IImage_get_height(This,height)	\
    (This)->lpVtbl -> get_height(This,height)

#define IImage_put_width(This,width)	\
    (This)->lpVtbl -> put_width(This,width)

#define IImage_get_width(This,width)	\
    (This)->lpVtbl -> get_width(This,width)

#define IImage_put_zorder(This,zorder)	\
    (This)->lpVtbl -> put_zorder(This,zorder)

#define IImage_get_zorder(This,zorder)	\
    (This)->lpVtbl -> get_zorder(This,zorder)

#define IImage_put_opacity(This,opacity)	\
    (This)->lpVtbl -> put_opacity(This,opacity)

#define IImage_get_opacity(This,opacity)	\
    (This)->lpVtbl -> get_opacity(This,opacity)

#define IImage_put_tooltip(This,tooltip)	\
    (This)->lpVtbl -> put_tooltip(This,tooltip)

#define IImage_get_tooltip(This,tooltip)	\
    (This)->lpVtbl -> get_tooltip(This,tooltip)

#define IImage_put_src(This,path)	\
    (This)->lpVtbl -> put_src(This,path)

#define IImage_get_src(This,path)	\
    (This)->lpVtbl -> get_src(This,path)

#define IImage_put_fillmode(This,mode)	\
    (This)->lpVtbl -> put_fillmode(This,mode)

#define IImage_get_fillmode(This,mode)	\
    (This)->lpVtbl -> get_fillmode(This,mode)

#define IImage_put_rotation(This,rotation)	\
    (This)->lpVtbl -> put_rotation(This,rotation)

#define IImage_get_rotation(This,rotation)	\
    (This)->lpVtbl -> get_rotation(This,rotation)

#define IImage_put_rotation_x(This,x)	\
    (This)->lpVtbl -> put_rotation_x(This,x)

#define IImage_get_rotation_x(This,x)	\
    (This)->lpVtbl -> get_rotation_x(This,x)

#define IImage_put_rotation_y(This,y)	\
    (This)->lpVtbl -> put_rotation_y(This,y)

#define IImage_get_rotation_y(This,y)	\
    (This)->lpVtbl -> get_rotation_y(This,y)

#define IImage_Reload(This)	\
    (This)->lpVtbl -> Reload(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IImage_Init_Proxy( 
    IImage * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager);


void __RPC_STUB IImage_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IImage_MoveWindow_Proxy( 
    IImage * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IImage_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IImage_GetControlRect_Proxy( 
    IImage * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IImage_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IImage_SetControlEventHandler_Proxy( 
    IImage * This,
    IUnknown *parent);


void __RPC_STUB IImage_SetControlEventHandler_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_name_Proxy( 
    IImage * This,
    /* [retval][out] */ BSTR *name);


void __RPC_STUB IImage_get_name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_display_Proxy( 
    IImage * This,
    /* [in] */ VARIANT_BOOL display);


void __RPC_STUB IImage_put_display_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_display_Proxy( 
    IImage * This,
    /* [retval][out] */ VARIANT_BOOL *display);


void __RPC_STUB IImage_get_display_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_visible_Proxy( 
    IImage * This,
    /* [in] */ VARIANT_BOOL visible);


void __RPC_STUB IImage_put_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_visible_Proxy( 
    IImage * This,
    /* [retval][out] */ VARIANT_BOOL *visible);


void __RPC_STUB IImage_get_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_x_Proxy( 
    IImage * This,
    /* [in] */ int x);


void __RPC_STUB IImage_put_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_x_Proxy( 
    IImage * This,
    /* [retval][out] */ int *x);


void __RPC_STUB IImage_get_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_y_Proxy( 
    IImage * This,
    /* [in] */ int y);


void __RPC_STUB IImage_put_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_y_Proxy( 
    IImage * This,
    /* [retval][out] */ int *y);


void __RPC_STUB IImage_get_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_height_Proxy( 
    IImage * This,
    /* [in] */ int height);


void __RPC_STUB IImage_put_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_height_Proxy( 
    IImage * This,
    /* [retval][out] */ int *height);


void __RPC_STUB IImage_get_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_width_Proxy( 
    IImage * This,
    /* [in] */ int width);


void __RPC_STUB IImage_put_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_width_Proxy( 
    IImage * This,
    /* [retval][out] */ int *width);


void __RPC_STUB IImage_get_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_zorder_Proxy( 
    IImage * This,
    /* [in] */ int zorder);


void __RPC_STUB IImage_put_zorder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_zorder_Proxy( 
    IImage * This,
    /* [retval][out] */ int *zorder);


void __RPC_STUB IImage_get_zorder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_opacity_Proxy( 
    IImage * This,
    int opacity);


void __RPC_STUB IImage_put_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_opacity_Proxy( 
    IImage * This,
    /* [retval][out] */ int *opacity);


void __RPC_STUB IImage_get_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_tooltip_Proxy( 
    IImage * This,
    /* [in] */ BSTR tooltip);


void __RPC_STUB IImage_put_tooltip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_tooltip_Proxy( 
    IImage * This,
    /* [retval][out] */ BSTR *tooltip);


void __RPC_STUB IImage_get_tooltip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_src_Proxy( 
    IImage * This,
    BSTR path);


void __RPC_STUB IImage_put_src_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_src_Proxy( 
    IImage * This,
    /* [retval][out] */ BSTR *path);


void __RPC_STUB IImage_get_src_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_fillmode_Proxy( 
    IImage * This,
    enum EFillMode mode);


void __RPC_STUB IImage_put_fillmode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_fillmode_Proxy( 
    IImage * This,
    /* [retval][out] */ enum EFillMode *mode);


void __RPC_STUB IImage_get_fillmode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_rotation_Proxy( 
    IImage * This,
    int rotation);


void __RPC_STUB IImage_put_rotation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_rotation_Proxy( 
    IImage * This,
    /* [retval][out] */ int *rotation);


void __RPC_STUB IImage_get_rotation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_rotation_x_Proxy( 
    IImage * This,
    /* [in] */ int x);


void __RPC_STUB IImage_put_rotation_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_rotation_x_Proxy( 
    IImage * This,
    /* [retval][out] */ int *x);


void __RPC_STUB IImage_get_rotation_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IImage_put_rotation_y_Proxy( 
    IImage * This,
    /* [in] */ int y);


void __RPC_STUB IImage_put_rotation_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IImage_get_rotation_y_Proxy( 
    IImage * This,
    /* [retval][out] */ int *y);


void __RPC_STUB IImage_get_rotation_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IImage_Reload_Proxy( 
    IImage * This);


void __RPC_STUB IImage_Reload_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IImage_INTERFACE_DEFINED__ */


#ifndef __IText_INTERFACE_DEFINED__
#define __IText_INTERFACE_DEFINED__

/* interface IText */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IText;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B29593E4-4041-4220-81F9-F25EC6CCD593")
    IText : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetControlEventHandler( 
            IUnknown *parent) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_name( 
            /* [retval][out] */ BSTR *name) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_display( 
            /* [in] */ VARIANT_BOOL display) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_display( 
            /* [retval][out] */ VARIANT_BOOL *display) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_visible( 
            /* [in] */ VARIANT_BOOL visible) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_visible( 
            /* [retval][out] */ VARIANT_BOOL *visible) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_x( 
            /* [in] */ int x) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_x( 
            /* [retval][out] */ int *x) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_y( 
            /* [in] */ int y) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_y( 
            /* [retval][out] */ int *y) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_height( 
            /* [in] */ int height) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_height( 
            /* [retval][out] */ int *height) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_width( 
            /* [in] */ int width) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_width( 
            /* [retval][out] */ int *width) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_zorder( 
            /* [in] */ int zorder) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_zorder( 
            /* [retval][out] */ int *zorder) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_opacity( 
            int opacity) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_opacity( 
            /* [retval][out] */ int *opacity) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_tooltip( 
            /* [in] */ BSTR tooltip) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_tooltip( 
            /* [retval][out] */ BSTR *tooltip) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_data( 
            /* [in] */ BSTR text) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_data( 
            /* [retval][out] */ BSTR *text) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_font( 
            /* [in] */ BSTR font) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_font( 
            /* [retval][out] */ BSTR *font) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_size( 
            int size) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_size( 
            /* [retval][out] */ int *size) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_wrap( 
            VARIANT_BOOL wrap) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_wrap( 
            /* [retval][out] */ VARIANT_BOOL *wrap) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IText * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IText * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IText * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IText * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IText * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IText * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IText * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IText * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IText * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IText * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetControlEventHandler )( 
            IText * This,
            IUnknown *parent);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_name )( 
            IText * This,
            /* [retval][out] */ BSTR *name);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_display )( 
            IText * This,
            /* [in] */ VARIANT_BOOL display);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_display )( 
            IText * This,
            /* [retval][out] */ VARIANT_BOOL *display);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_visible )( 
            IText * This,
            /* [in] */ VARIANT_BOOL visible);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_visible )( 
            IText * This,
            /* [retval][out] */ VARIANT_BOOL *visible);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_x )( 
            IText * This,
            /* [in] */ int x);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_x )( 
            IText * This,
            /* [retval][out] */ int *x);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_y )( 
            IText * This,
            /* [in] */ int y);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_y )( 
            IText * This,
            /* [retval][out] */ int *y);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_height )( 
            IText * This,
            /* [in] */ int height);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_height )( 
            IText * This,
            /* [retval][out] */ int *height);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_width )( 
            IText * This,
            /* [in] */ int width);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_width )( 
            IText * This,
            /* [retval][out] */ int *width);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_zorder )( 
            IText * This,
            /* [in] */ int zorder);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_zorder )( 
            IText * This,
            /* [retval][out] */ int *zorder);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_opacity )( 
            IText * This,
            int opacity);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_opacity )( 
            IText * This,
            /* [retval][out] */ int *opacity);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_tooltip )( 
            IText * This,
            /* [in] */ BSTR tooltip);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_tooltip )( 
            IText * This,
            /* [retval][out] */ BSTR *tooltip);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_data )( 
            IText * This,
            /* [in] */ BSTR text);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_data )( 
            IText * This,
            /* [retval][out] */ BSTR *text);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_font )( 
            IText * This,
            /* [in] */ BSTR font);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_font )( 
            IText * This,
            /* [retval][out] */ BSTR *font);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_size )( 
            IText * This,
            int size);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_size )( 
            IText * This,
            /* [retval][out] */ int *size);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_wrap )( 
            IText * This,
            VARIANT_BOOL wrap);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_wrap )( 
            IText * This,
            /* [retval][out] */ VARIANT_BOOL *wrap);
        
        END_INTERFACE
    } ITextVtbl;

    interface IText
    {
        CONST_VTBL struct ITextVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IText_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IText_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IText_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IText_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IText_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IText_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IText_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IText_Init(This,settings,skinManager)	\
    (This)->lpVtbl -> Init(This,settings,skinManager)

#define IText_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IText_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IText_SetControlEventHandler(This,parent)	\
    (This)->lpVtbl -> SetControlEventHandler(This,parent)

#define IText_get_name(This,name)	\
    (This)->lpVtbl -> get_name(This,name)

#define IText_put_display(This,display)	\
    (This)->lpVtbl -> put_display(This,display)

#define IText_get_display(This,display)	\
    (This)->lpVtbl -> get_display(This,display)

#define IText_put_visible(This,visible)	\
    (This)->lpVtbl -> put_visible(This,visible)

#define IText_get_visible(This,visible)	\
    (This)->lpVtbl -> get_visible(This,visible)

#define IText_put_x(This,x)	\
    (This)->lpVtbl -> put_x(This,x)

#define IText_get_x(This,x)	\
    (This)->lpVtbl -> get_x(This,x)

#define IText_put_y(This,y)	\
    (This)->lpVtbl -> put_y(This,y)

#define IText_get_y(This,y)	\
    (This)->lpVtbl -> get_y(This,y)

#define IText_put_height(This,height)	\
    (This)->lpVtbl -> put_height(This,height)

#define IText_get_height(This,height)	\
    (This)->lpVtbl -> get_height(This,height)

#define IText_put_width(This,width)	\
    (This)->lpVtbl -> put_width(This,width)

#define IText_get_width(This,width)	\
    (This)->lpVtbl -> get_width(This,width)

#define IText_put_zorder(This,zorder)	\
    (This)->lpVtbl -> put_zorder(This,zorder)

#define IText_get_zorder(This,zorder)	\
    (This)->lpVtbl -> get_zorder(This,zorder)

#define IText_put_opacity(This,opacity)	\
    (This)->lpVtbl -> put_opacity(This,opacity)

#define IText_get_opacity(This,opacity)	\
    (This)->lpVtbl -> get_opacity(This,opacity)

#define IText_put_tooltip(This,tooltip)	\
    (This)->lpVtbl -> put_tooltip(This,tooltip)

#define IText_get_tooltip(This,tooltip)	\
    (This)->lpVtbl -> get_tooltip(This,tooltip)

#define IText_put_data(This,text)	\
    (This)->lpVtbl -> put_data(This,text)

#define IText_get_data(This,text)	\
    (This)->lpVtbl -> get_data(This,text)

#define IText_put_font(This,font)	\
    (This)->lpVtbl -> put_font(This,font)

#define IText_get_font(This,font)	\
    (This)->lpVtbl -> get_font(This,font)

#define IText_put_size(This,size)	\
    (This)->lpVtbl -> put_size(This,size)

#define IText_get_size(This,size)	\
    (This)->lpVtbl -> get_size(This,size)

#define IText_put_wrap(This,wrap)	\
    (This)->lpVtbl -> put_wrap(This,wrap)

#define IText_get_wrap(This,wrap)	\
    (This)->lpVtbl -> get_wrap(This,wrap)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IText_Init_Proxy( 
    IText * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager);


void __RPC_STUB IText_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IText_MoveWindow_Proxy( 
    IText * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IText_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IText_GetControlRect_Proxy( 
    IText * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IText_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IText_SetControlEventHandler_Proxy( 
    IText * This,
    IUnknown *parent);


void __RPC_STUB IText_SetControlEventHandler_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_name_Proxy( 
    IText * This,
    /* [retval][out] */ BSTR *name);


void __RPC_STUB IText_get_name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_display_Proxy( 
    IText * This,
    /* [in] */ VARIANT_BOOL display);


void __RPC_STUB IText_put_display_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_display_Proxy( 
    IText * This,
    /* [retval][out] */ VARIANT_BOOL *display);


void __RPC_STUB IText_get_display_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_visible_Proxy( 
    IText * This,
    /* [in] */ VARIANT_BOOL visible);


void __RPC_STUB IText_put_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_visible_Proxy( 
    IText * This,
    /* [retval][out] */ VARIANT_BOOL *visible);


void __RPC_STUB IText_get_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_x_Proxy( 
    IText * This,
    /* [in] */ int x);


void __RPC_STUB IText_put_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_x_Proxy( 
    IText * This,
    /* [retval][out] */ int *x);


void __RPC_STUB IText_get_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_y_Proxy( 
    IText * This,
    /* [in] */ int y);


void __RPC_STUB IText_put_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_y_Proxy( 
    IText * This,
    /* [retval][out] */ int *y);


void __RPC_STUB IText_get_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_height_Proxy( 
    IText * This,
    /* [in] */ int height);


void __RPC_STUB IText_put_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_height_Proxy( 
    IText * This,
    /* [retval][out] */ int *height);


void __RPC_STUB IText_get_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_width_Proxy( 
    IText * This,
    /* [in] */ int width);


void __RPC_STUB IText_put_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_width_Proxy( 
    IText * This,
    /* [retval][out] */ int *width);


void __RPC_STUB IText_get_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_zorder_Proxy( 
    IText * This,
    /* [in] */ int zorder);


void __RPC_STUB IText_put_zorder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_zorder_Proxy( 
    IText * This,
    /* [retval][out] */ int *zorder);


void __RPC_STUB IText_get_zorder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_opacity_Proxy( 
    IText * This,
    int opacity);


void __RPC_STUB IText_put_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_opacity_Proxy( 
    IText * This,
    /* [retval][out] */ int *opacity);


void __RPC_STUB IText_get_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_tooltip_Proxy( 
    IText * This,
    /* [in] */ BSTR tooltip);


void __RPC_STUB IText_put_tooltip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_tooltip_Proxy( 
    IText * This,
    /* [retval][out] */ BSTR *tooltip);


void __RPC_STUB IText_get_tooltip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_data_Proxy( 
    IText * This,
    /* [in] */ BSTR text);


void __RPC_STUB IText_put_data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_data_Proxy( 
    IText * This,
    /* [retval][out] */ BSTR *text);


void __RPC_STUB IText_get_data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_font_Proxy( 
    IText * This,
    /* [in] */ BSTR font);


void __RPC_STUB IText_put_font_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_font_Proxy( 
    IText * This,
    /* [retval][out] */ BSTR *font);


void __RPC_STUB IText_get_font_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_size_Proxy( 
    IText * This,
    int size);


void __RPC_STUB IText_put_size_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_size_Proxy( 
    IText * This,
    /* [retval][out] */ int *size);


void __RPC_STUB IText_get_size_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IText_put_wrap_Proxy( 
    IText * This,
    VARIANT_BOOL wrap);


void __RPC_STUB IText_put_wrap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IText_get_wrap_Proxy( 
    IText * This,
    /* [retval][out] */ VARIANT_BOOL *wrap);


void __RPC_STUB IText_get_wrap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IText_INTERFACE_DEFINED__ */


#ifndef __IControlEvent_INTERFACE_DEFINED__
#define __IControlEvent_INTERFACE_DEFINED__

/* interface IControlEvent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IControlEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D4E88603-E066-402e-BA8F-1C2D1F01A2F7")
    IControlEvent : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_x( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_y( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_fromElement( 
            /* [retval][out] */ IDispatch **retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IControlEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IControlEvent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IControlEvent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IControlEvent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IControlEvent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IControlEvent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IControlEvent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IControlEvent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_x )( 
            IControlEvent * This,
            /* [retval][out] */ int *retVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_y )( 
            IControlEvent * This,
            /* [retval][out] */ int *retVal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_fromElement )( 
            IControlEvent * This,
            /* [retval][out] */ IDispatch **retVal);
        
        END_INTERFACE
    } IControlEventVtbl;

    interface IControlEvent
    {
        CONST_VTBL struct IControlEventVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IControlEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IControlEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IControlEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IControlEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IControlEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IControlEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IControlEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IControlEvent_get_x(This,retVal)	\
    (This)->lpVtbl -> get_x(This,retVal)

#define IControlEvent_get_y(This,retVal)	\
    (This)->lpVtbl -> get_y(This,retVal)

#define IControlEvent_get_fromElement(This,retVal)	\
    (This)->lpVtbl -> get_fromElement(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE IControlEvent_get_x_Proxy( 
    IControlEvent * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IControlEvent_get_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IControlEvent_get_y_Proxy( 
    IControlEvent * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IControlEvent_get_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IControlEvent_get_fromElement_Proxy( 
    IControlEvent * This,
    /* [retval][out] */ IDispatch **retVal);


void __RPC_STUB IControlEvent_get_fromElement_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IControlEvent_INTERFACE_DEFINED__ */


#ifndef __IControlEventHandler_INTERFACE_DEFINED__
#define __IControlEventHandler_INTERFACE_DEFINED__

/* interface IControlEventHandler */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IControlEventHandler;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("BFBF1B5A-342D-4359-BD15-887C02FD7C4B")
    IControlEventHandler : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnClick( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnDblClick( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseDown( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseEnter( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseExit( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseMove( 
            IControlEvent *event) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnMouseUp( 
            IControlEvent *event) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IControlEventHandlerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IControlEventHandler * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IControlEventHandler * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IControlEventHandler * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IControlEventHandler * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IControlEventHandler * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IControlEventHandler * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IControlEventHandler * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnClick )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnDblClick )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseDown )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseEnter )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseExit )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseMove )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        HRESULT ( STDMETHODCALLTYPE *OnMouseUp )( 
            IControlEventHandler * This,
            IControlEvent *event);
        
        END_INTERFACE
    } IControlEventHandlerVtbl;

    interface IControlEventHandler
    {
        CONST_VTBL struct IControlEventHandlerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IControlEventHandler_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IControlEventHandler_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IControlEventHandler_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IControlEventHandler_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IControlEventHandler_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IControlEventHandler_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IControlEventHandler_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IControlEventHandler_OnClick(This,event)	\
    (This)->lpVtbl -> OnClick(This,event)

#define IControlEventHandler_OnDblClick(This,event)	\
    (This)->lpVtbl -> OnDblClick(This,event)

#define IControlEventHandler_OnMouseDown(This,event)	\
    (This)->lpVtbl -> OnMouseDown(This,event)

#define IControlEventHandler_OnMouseEnter(This,event)	\
    (This)->lpVtbl -> OnMouseEnter(This,event)

#define IControlEventHandler_OnMouseExit(This,event)	\
    (This)->lpVtbl -> OnMouseExit(This,event)

#define IControlEventHandler_OnMouseMove(This,event)	\
    (This)->lpVtbl -> OnMouseMove(This,event)

#define IControlEventHandler_OnMouseUp(This,event)	\
    (This)->lpVtbl -> OnMouseUp(This,event)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IControlEventHandler_OnClick_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnDblClick_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnDblClick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnMouseDown_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnMouseDown_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnMouseEnter_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnMouseEnter_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnMouseExit_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnMouseExit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnMouseMove_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnMouseMove_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlEventHandler_OnMouseUp_Proxy( 
    IControlEventHandler * This,
    IControlEvent *event);


void __RPC_STUB IControlEventHandler_OnMouseUp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IControlEventHandler_INTERFACE_DEFINED__ */


#ifndef __IHwndHolder_INTERFACE_DEFINED__
#define __IHwndHolder_INTERFACE_DEFINED__

/* interface IHwndHolder */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IHwndHolder;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("98343A16-A0F6-4741-B485-F43F82C9C5F6")
    IHwndHolder : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE MoveWindow( 
            int x,
            int y,
            int width,
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetEmpty( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetWindow( 
            HWND window) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHwndHolderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHwndHolder * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHwndHolder * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHwndHolder * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IHwndHolder * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IHwndHolder * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IHwndHolder * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IHwndHolder * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *MoveWindow )( 
            IHwndHolder * This,
            int x,
            int y,
            int width,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlRect )( 
            IHwndHolder * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *SetEmpty )( 
            IHwndHolder * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetWindow )( 
            IHwndHolder * This,
            HWND window);
        
        END_INTERFACE
    } IHwndHolderVtbl;

    interface IHwndHolder
    {
        CONST_VTBL struct IHwndHolderVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHwndHolder_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHwndHolder_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHwndHolder_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHwndHolder_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IHwndHolder_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IHwndHolder_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IHwndHolder_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IHwndHolder_MoveWindow(This,x,y,width,height)	\
    (This)->lpVtbl -> MoveWindow(This,x,y,width,height)

#define IHwndHolder_GetControlRect(This,rect)	\
    (This)->lpVtbl -> GetControlRect(This,rect)

#define IHwndHolder_SetEmpty(This)	\
    (This)->lpVtbl -> SetEmpty(This)

#define IHwndHolder_SetWindow(This,window)	\
    (This)->lpVtbl -> SetWindow(This,window)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IHwndHolder_MoveWindow_Proxy( 
    IHwndHolder * This,
    int x,
    int y,
    int width,
    int height);


void __RPC_STUB IHwndHolder_MoveWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHwndHolder_GetControlRect_Proxy( 
    IHwndHolder * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB IHwndHolder_GetControlRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHwndHolder_SetEmpty_Proxy( 
    IHwndHolder * This);


void __RPC_STUB IHwndHolder_SetEmpty_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHwndHolder_SetWindow_Proxy( 
    IHwndHolder * This,
    HWND window);


void __RPC_STUB IHwndHolder_SetWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHwndHolder_INTERFACE_DEFINED__ */


#ifndef __IDetailsWndParent_INTERFACE_DEFINED__
#define __IDetailsWndParent_INTERFACE_DEFINED__

/* interface IDetailsWndParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDetailsWndParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("046FD764-6236-429c-B8D5-F6AAC3DAD63B")
    IDetailsWndParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnCreateDetailsWnd( 
            IUnknown *details) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnCloseDetailsWnd( 
            IUnknown *details) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDetailsWndParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDetailsWndParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDetailsWndParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDetailsWndParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDetailsWndParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDetailsWndParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDetailsWndParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDetailsWndParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnCreateDetailsWnd )( 
            IDetailsWndParent * This,
            IUnknown *details);
        
        HRESULT ( STDMETHODCALLTYPE *OnCloseDetailsWnd )( 
            IDetailsWndParent * This,
            IUnknown *details);
        
        END_INTERFACE
    } IDetailsWndParentVtbl;

    interface IDetailsWndParent
    {
        CONST_VTBL struct IDetailsWndParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDetailsWndParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDetailsWndParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDetailsWndParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDetailsWndParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDetailsWndParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDetailsWndParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDetailsWndParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDetailsWndParent_OnCreateDetailsWnd(This,details)	\
    (This)->lpVtbl -> OnCreateDetailsWnd(This,details)

#define IDetailsWndParent_OnCloseDetailsWnd(This,details)	\
    (This)->lpVtbl -> OnCloseDetailsWnd(This,details)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDetailsWndParent_OnCreateDetailsWnd_Proxy( 
    IDetailsWndParent * This,
    IUnknown *details);


void __RPC_STUB IDetailsWndParent_OnCreateDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWndParent_OnCloseDetailsWnd_Proxy( 
    IDetailsWndParent * This,
    IUnknown *details);


void __RPC_STUB IDetailsWndParent_OnCloseDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDetailsWndParent_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0299 */
/* [local] */ 


enum EDetailsStyle
    {	DS_NONE	= 0,
	DS_MOREBUTTON	= 0x1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0299_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0299_v0_0_s_ifspec;

#ifndef __IDetailsWndParent2_INTERFACE_DEFINED__
#define __IDetailsWndParent2_INTERFACE_DEFINED__

/* interface IDetailsWndParent2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDetailsWndParent2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D84E490A-1E06-413b-ADF6-92F52B9AC542")
    IDetailsWndParent2 : public IDetailsWndParent
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDetailsButtonClicked( 
            IUnknown *details,
            UINT btn) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDetailsWndParent2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDetailsWndParent2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDetailsWndParent2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDetailsWndParent2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDetailsWndParent2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDetailsWndParent2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDetailsWndParent2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDetailsWndParent2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnCreateDetailsWnd )( 
            IDetailsWndParent2 * This,
            IUnknown *details);
        
        HRESULT ( STDMETHODCALLTYPE *OnCloseDetailsWnd )( 
            IDetailsWndParent2 * This,
            IUnknown *details);
        
        HRESULT ( STDMETHODCALLTYPE *OnDetailsButtonClicked )( 
            IDetailsWndParent2 * This,
            IUnknown *details,
            UINT btn);
        
        END_INTERFACE
    } IDetailsWndParent2Vtbl;

    interface IDetailsWndParent2
    {
        CONST_VTBL struct IDetailsWndParent2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDetailsWndParent2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDetailsWndParent2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDetailsWndParent2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDetailsWndParent2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDetailsWndParent2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDetailsWndParent2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDetailsWndParent2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDetailsWndParent2_OnCreateDetailsWnd(This,details)	\
    (This)->lpVtbl -> OnCreateDetailsWnd(This,details)

#define IDetailsWndParent2_OnCloseDetailsWnd(This,details)	\
    (This)->lpVtbl -> OnCloseDetailsWnd(This,details)


#define IDetailsWndParent2_OnDetailsButtonClicked(This,details,btn)	\
    (This)->lpVtbl -> OnDetailsButtonClicked(This,details,btn)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDetailsWndParent2_OnDetailsButtonClicked_Proxy( 
    IDetailsWndParent2 * This,
    IUnknown *details,
    UINT btn);


void __RPC_STUB IDetailsWndParent2_OnDetailsButtonClicked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDetailsWndParent2_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0300 */
/* [local] */ 


enum EDetailFlags
    {	DC_NULL	= 0,
	DC_IGNOREORIGIN	= DC_NULL + 1,
	DC_IGNORESIZE	= DC_IGNOREORIGIN + 1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0300_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0300_v0_0_s_ifspec;

#ifndef __IDetailsWnd_INTERFACE_DEFINED__
#define __IDetailsWnd_INTERFACE_DEFINED__

/* interface IDetailsWnd */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDetailsWnd;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("41234821-D933-40b6-A1A6-5A856A4D8D32")
    IDetailsWnd : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterParent( 
            IDetailsWndParent *parent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCaption( 
            BSTR caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSize( 
            /* [retval][out] */ SIZE *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSize( 
            SIZE size,
            VARIANT_BOOL redraw) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetFixedSize( 
            VARIANT_BOOL fixed) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetInteriorRect( 
            /* [retval][out] */ RECT *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBkColor( 
            /* [retval][out] */ DWORD *argb) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AreaToOrigin( 
            RECT parentArea,
            /* [retval][out] */ POINT *retval) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Show( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Fade( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Hide( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PinWindow( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnpinWindow( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetInterior( 
            int hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetInterior( 
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetUserParam( 
            long param) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetUserParam( 
            /* [retval][out] */ long *param) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetUserUnk( 
            IUnknown *unk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetUserUnk( 
            /* [retval][out] */ IUnknown **unk) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawBackground( 
            IGraphics *graphics,
            const RECT *rc) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create2( 
            int hwndParent,
            IUnknown *panelConfig) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDetailsWndVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDetailsWnd * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDetailsWnd * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDetailsWnd * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDetailsWnd * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IDetailsWnd * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterParent )( 
            IDetailsWnd * This,
            IDetailsWndParent *parent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IDetailsWnd * This,
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IDetailsWnd * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IDetailsWnd * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            IDetailsWnd * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            IDetailsWnd * This,
            SIZE size,
            VARIANT_BOOL redraw);
        
        HRESULT ( STDMETHODCALLTYPE *SetFixedSize )( 
            IDetailsWnd * This,
            VARIANT_BOOL fixed);
        
        HRESULT ( STDMETHODCALLTYPE *GetInteriorRect )( 
            IDetailsWnd * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBkColor )( 
            IDetailsWnd * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *AreaToOrigin )( 
            IDetailsWnd * This,
            RECT parentArea,
            /* [retval][out] */ POINT *retval);
        
        HRESULT ( STDMETHODCALLTYPE *Show )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *Fade )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *Hide )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *PinWindow )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *UnpinWindow )( 
            IDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetInterior )( 
            IDetailsWnd * This,
            int hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetInterior )( 
            IDetailsWnd * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserParam )( 
            IDetailsWnd * This,
            long param);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserParam )( 
            IDetailsWnd * This,
            /* [retval][out] */ long *param);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserUnk )( 
            IDetailsWnd * This,
            IUnknown *unk);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserUnk )( 
            IDetailsWnd * This,
            /* [retval][out] */ IUnknown **unk);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            IDetailsWnd * This,
            IGraphics *graphics,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *Create2 )( 
            IDetailsWnd * This,
            int hwndParent,
            IUnknown *panelConfig);
        
        END_INTERFACE
    } IDetailsWndVtbl;

    interface IDetailsWnd
    {
        CONST_VTBL struct IDetailsWndVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDetailsWnd_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDetailsWnd_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDetailsWnd_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDetailsWnd_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDetailsWnd_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDetailsWnd_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDetailsWnd_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDetailsWnd_Init(This,settings,skinManager,panelConfig,parent,caption)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,panelConfig,parent,caption)

#define IDetailsWnd_RegisterParent(This,parent)	\
    (This)->lpVtbl -> RegisterParent(This,parent)

#define IDetailsWnd_Create(This,hwndParent,flags,origin,size)	\
    (This)->lpVtbl -> Create(This,hwndParent,flags,origin,size)

#define IDetailsWnd_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IDetailsWnd_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define IDetailsWnd_GetSize(This,retVal)	\
    (This)->lpVtbl -> GetSize(This,retVal)

#define IDetailsWnd_SetSize(This,size,redraw)	\
    (This)->lpVtbl -> SetSize(This,size,redraw)

#define IDetailsWnd_SetFixedSize(This,fixed)	\
    (This)->lpVtbl -> SetFixedSize(This,fixed)

#define IDetailsWnd_GetInteriorRect(This,retVal)	\
    (This)->lpVtbl -> GetInteriorRect(This,retVal)

#define IDetailsWnd_GetBkColor(This,argb)	\
    (This)->lpVtbl -> GetBkColor(This,argb)

#define IDetailsWnd_AreaToOrigin(This,parentArea,retval)	\
    (This)->lpVtbl -> AreaToOrigin(This,parentArea,retval)

#define IDetailsWnd_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IDetailsWnd_Fade(This)	\
    (This)->lpVtbl -> Fade(This)

#define IDetailsWnd_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define IDetailsWnd_PinWindow(This)	\
    (This)->lpVtbl -> PinWindow(This)

#define IDetailsWnd_UnpinWindow(This)	\
    (This)->lpVtbl -> UnpinWindow(This)

#define IDetailsWnd_SetInterior(This,hwnd)	\
    (This)->lpVtbl -> SetInterior(This,hwnd)

#define IDetailsWnd_GetInterior(This,retVal)	\
    (This)->lpVtbl -> GetInterior(This,retVal)

#define IDetailsWnd_SetUserParam(This,param)	\
    (This)->lpVtbl -> SetUserParam(This,param)

#define IDetailsWnd_GetUserParam(This,param)	\
    (This)->lpVtbl -> GetUserParam(This,param)

#define IDetailsWnd_SetUserUnk(This,unk)	\
    (This)->lpVtbl -> SetUserUnk(This,unk)

#define IDetailsWnd_GetUserUnk(This,unk)	\
    (This)->lpVtbl -> GetUserUnk(This,unk)

#define IDetailsWnd_DrawBackground(This,graphics,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,rc)

#define IDetailsWnd_Create2(This,hwndParent,panelConfig)	\
    (This)->lpVtbl -> Create2(This,hwndParent,panelConfig)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDetailsWnd_Init_Proxy( 
    IDetailsWnd * This,
    IGlobalSettings *settings,
    ISkinManager *skinManager,
    IUnknown *panelConfig,
    IDetailsWndParent *parent,
    BSTR caption);


void __RPC_STUB IDetailsWnd_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_RegisterParent_Proxy( 
    IDetailsWnd * This,
    IDetailsWndParent *parent);


void __RPC_STUB IDetailsWnd_RegisterParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_Create_Proxy( 
    IDetailsWnd * This,
    int hwndParent,
    int flags,
    /* [in] */ const POINT *origin,
    /* [in] */ const SIZE *size);


void __RPC_STUB IDetailsWnd_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetHwnd_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB IDetailsWnd_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetCaption_Proxy( 
    IDetailsWnd * This,
    BSTR caption);


void __RPC_STUB IDetailsWnd_SetCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetSize_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ SIZE *retVal);


void __RPC_STUB IDetailsWnd_GetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetSize_Proxy( 
    IDetailsWnd * This,
    SIZE size,
    VARIANT_BOOL redraw);


void __RPC_STUB IDetailsWnd_SetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetFixedSize_Proxy( 
    IDetailsWnd * This,
    VARIANT_BOOL fixed);


void __RPC_STUB IDetailsWnd_SetFixedSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetInteriorRect_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ RECT *retVal);


void __RPC_STUB IDetailsWnd_GetInteriorRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetBkColor_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ DWORD *argb);


void __RPC_STUB IDetailsWnd_GetBkColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_AreaToOrigin_Proxy( 
    IDetailsWnd * This,
    RECT parentArea,
    /* [retval][out] */ POINT *retval);


void __RPC_STUB IDetailsWnd_AreaToOrigin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_Show_Proxy( 
    IDetailsWnd * This);


void __RPC_STUB IDetailsWnd_Show_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_Fade_Proxy( 
    IDetailsWnd * This);


void __RPC_STUB IDetailsWnd_Fade_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_Hide_Proxy( 
    IDetailsWnd * This);


void __RPC_STUB IDetailsWnd_Hide_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_PinWindow_Proxy( 
    IDetailsWnd * This);


void __RPC_STUB IDetailsWnd_PinWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_UnpinWindow_Proxy( 
    IDetailsWnd * This);


void __RPC_STUB IDetailsWnd_UnpinWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetInterior_Proxy( 
    IDetailsWnd * This,
    int hwnd);


void __RPC_STUB IDetailsWnd_SetInterior_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetInterior_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB IDetailsWnd_GetInterior_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetUserParam_Proxy( 
    IDetailsWnd * This,
    long param);


void __RPC_STUB IDetailsWnd_SetUserParam_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetUserParam_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ long *param);


void __RPC_STUB IDetailsWnd_GetUserParam_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_SetUserUnk_Proxy( 
    IDetailsWnd * This,
    IUnknown *unk);


void __RPC_STUB IDetailsWnd_SetUserUnk_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_GetUserUnk_Proxy( 
    IDetailsWnd * This,
    /* [retval][out] */ IUnknown **unk);


void __RPC_STUB IDetailsWnd_GetUserUnk_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_DrawBackground_Proxy( 
    IDetailsWnd * This,
    IGraphics *graphics,
    const RECT *rc);


void __RPC_STUB IDetailsWnd_DrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IDetailsWnd_Create2_Proxy( 
    IDetailsWnd * This,
    int hwndParent,
    IUnknown *panelConfig);


void __RPC_STUB IDetailsWnd_Create2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDetailsWnd_INTERFACE_DEFINED__ */


#ifndef __ITextDetailsWnd_INTERFACE_DEFINED__
#define __ITextDetailsWnd_INTERFACE_DEFINED__

/* interface ITextDetailsWnd */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITextDetailsWnd;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CE5309BD-0B89-41d4-993C-D39CE35994C1")
    ITextDetailsWnd : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Append( 
            BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextDetailsWndVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextDetailsWnd * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextDetailsWnd * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextDetailsWnd * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextDetailsWnd * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            ITextDetailsWnd * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *Append )( 
            ITextDetailsWnd * This,
            BSTR text);
        
        END_INTERFACE
    } ITextDetailsWndVtbl;

    interface ITextDetailsWnd
    {
        CONST_VTBL struct ITextDetailsWndVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextDetailsWnd_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITextDetailsWnd_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITextDetailsWnd_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITextDetailsWnd_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITextDetailsWnd_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITextDetailsWnd_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITextDetailsWnd_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITextDetailsWnd_Set(This,text)	\
    (This)->lpVtbl -> Set(This,text)

#define ITextDetailsWnd_Append(This,text)	\
    (This)->lpVtbl -> Append(This,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITextDetailsWnd_Set_Proxy( 
    ITextDetailsWnd * This,
    BSTR text);


void __RPC_STUB ITextDetailsWnd_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextDetailsWnd_Append_Proxy( 
    ITextDetailsWnd * This,
    BSTR text);


void __RPC_STUB ITextDetailsWnd_Append_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITextDetailsWnd_INTERFACE_DEFINED__ */


#ifndef __ITextDetailsWnd2_INTERFACE_DEFINED__
#define __ITextDetailsWnd2_INTERFACE_DEFINED__

/* interface ITextDetailsWnd2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITextDetailsWnd2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9AAFF3F6-8B34-4e66-AC93-A295AEA7772C")
    ITextDetailsWnd2 : public IDetailsWnd
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Append( 
            BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextDetailsWnd2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextDetailsWnd2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextDetailsWnd2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextDetailsWnd2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextDetailsWnd2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ITextDetailsWnd2 * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterParent )( 
            ITextDetailsWnd2 * This,
            IDetailsWndParent *parent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ITextDetailsWnd2 * This,
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            ITextDetailsWnd2 * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            ITextDetailsWnd2 * This,
            SIZE size,
            VARIANT_BOOL redraw);
        
        HRESULT ( STDMETHODCALLTYPE *SetFixedSize )( 
            ITextDetailsWnd2 * This,
            VARIANT_BOOL fixed);
        
        HRESULT ( STDMETHODCALLTYPE *GetInteriorRect )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBkColor )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *AreaToOrigin )( 
            ITextDetailsWnd2 * This,
            RECT parentArea,
            /* [retval][out] */ POINT *retval);
        
        HRESULT ( STDMETHODCALLTYPE *Show )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Fade )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Hide )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *PinWindow )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *UnpinWindow )( 
            ITextDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetInterior )( 
            ITextDetailsWnd2 * This,
            int hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetInterior )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserParam )( 
            ITextDetailsWnd2 * This,
            long param);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserParam )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ long *param);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserUnk )( 
            ITextDetailsWnd2 * This,
            IUnknown *unk);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserUnk )( 
            ITextDetailsWnd2 * This,
            /* [retval][out] */ IUnknown **unk);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            ITextDetailsWnd2 * This,
            IGraphics *graphics,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *Create2 )( 
            ITextDetailsWnd2 * This,
            int hwndParent,
            IUnknown *panelConfig);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            ITextDetailsWnd2 * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *Append )( 
            ITextDetailsWnd2 * This,
            BSTR text);
        
        END_INTERFACE
    } ITextDetailsWnd2Vtbl;

    interface ITextDetailsWnd2
    {
        CONST_VTBL struct ITextDetailsWnd2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextDetailsWnd2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITextDetailsWnd2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITextDetailsWnd2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITextDetailsWnd2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITextDetailsWnd2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITextDetailsWnd2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITextDetailsWnd2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITextDetailsWnd2_Init(This,settings,skinManager,panelConfig,parent,caption)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,panelConfig,parent,caption)

#define ITextDetailsWnd2_RegisterParent(This,parent)	\
    (This)->lpVtbl -> RegisterParent(This,parent)

#define ITextDetailsWnd2_Create(This,hwndParent,flags,origin,size)	\
    (This)->lpVtbl -> Create(This,hwndParent,flags,origin,size)

#define ITextDetailsWnd2_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ITextDetailsWnd2_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define ITextDetailsWnd2_GetSize(This,retVal)	\
    (This)->lpVtbl -> GetSize(This,retVal)

#define ITextDetailsWnd2_SetSize(This,size,redraw)	\
    (This)->lpVtbl -> SetSize(This,size,redraw)

#define ITextDetailsWnd2_SetFixedSize(This,fixed)	\
    (This)->lpVtbl -> SetFixedSize(This,fixed)

#define ITextDetailsWnd2_GetInteriorRect(This,retVal)	\
    (This)->lpVtbl -> GetInteriorRect(This,retVal)

#define ITextDetailsWnd2_GetBkColor(This,argb)	\
    (This)->lpVtbl -> GetBkColor(This,argb)

#define ITextDetailsWnd2_AreaToOrigin(This,parentArea,retval)	\
    (This)->lpVtbl -> AreaToOrigin(This,parentArea,retval)

#define ITextDetailsWnd2_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define ITextDetailsWnd2_Fade(This)	\
    (This)->lpVtbl -> Fade(This)

#define ITextDetailsWnd2_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define ITextDetailsWnd2_PinWindow(This)	\
    (This)->lpVtbl -> PinWindow(This)

#define ITextDetailsWnd2_UnpinWindow(This)	\
    (This)->lpVtbl -> UnpinWindow(This)

#define ITextDetailsWnd2_SetInterior(This,hwnd)	\
    (This)->lpVtbl -> SetInterior(This,hwnd)

#define ITextDetailsWnd2_GetInterior(This,retVal)	\
    (This)->lpVtbl -> GetInterior(This,retVal)

#define ITextDetailsWnd2_SetUserParam(This,param)	\
    (This)->lpVtbl -> SetUserParam(This,param)

#define ITextDetailsWnd2_GetUserParam(This,param)	\
    (This)->lpVtbl -> GetUserParam(This,param)

#define ITextDetailsWnd2_SetUserUnk(This,unk)	\
    (This)->lpVtbl -> SetUserUnk(This,unk)

#define ITextDetailsWnd2_GetUserUnk(This,unk)	\
    (This)->lpVtbl -> GetUserUnk(This,unk)

#define ITextDetailsWnd2_DrawBackground(This,graphics,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,rc)

#define ITextDetailsWnd2_Create2(This,hwndParent,panelConfig)	\
    (This)->lpVtbl -> Create2(This,hwndParent,panelConfig)


#define ITextDetailsWnd2_Set(This,text)	\
    (This)->lpVtbl -> Set(This,text)

#define ITextDetailsWnd2_Append(This,text)	\
    (This)->lpVtbl -> Append(This,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITextDetailsWnd2_Set_Proxy( 
    ITextDetailsWnd2 * This,
    BSTR text);


void __RPC_STUB ITextDetailsWnd2_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ITextDetailsWnd2_Append_Proxy( 
    ITextDetailsWnd2 * This,
    BSTR text);


void __RPC_STUB ITextDetailsWnd2_Append_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITextDetailsWnd2_INTERFACE_DEFINED__ */


#ifndef __ILinkDetailsWnd_INTERFACE_DEFINED__
#define __ILinkDetailsWnd_INTERFACE_DEFINED__

/* interface ILinkDetailsWnd */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ILinkDetailsWnd;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("751768E1-88D9-4b31-A6BC-E997993D4E29")
    ILinkDetailsWnd : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILinkDetailsWndVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILinkDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILinkDetailsWnd * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILinkDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ILinkDetailsWnd * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ILinkDetailsWnd * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ILinkDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ILinkDetailsWnd * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            ILinkDetailsWnd * This,
            BSTR text);
        
        END_INTERFACE
    } ILinkDetailsWndVtbl;

    interface ILinkDetailsWnd
    {
        CONST_VTBL struct ILinkDetailsWndVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILinkDetailsWnd_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILinkDetailsWnd_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILinkDetailsWnd_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILinkDetailsWnd_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILinkDetailsWnd_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILinkDetailsWnd_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILinkDetailsWnd_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILinkDetailsWnd_Set(This,text)	\
    (This)->lpVtbl -> Set(This,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ILinkDetailsWnd_Set_Proxy( 
    ILinkDetailsWnd * This,
    BSTR text);


void __RPC_STUB ILinkDetailsWnd_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILinkDetailsWnd_INTERFACE_DEFINED__ */


#ifndef __ILinkDetailsWnd2_INTERFACE_DEFINED__
#define __ILinkDetailsWnd2_INTERFACE_DEFINED__

/* interface ILinkDetailsWnd2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ILinkDetailsWnd2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C4A87E34-7448-43bc-BF35-411DB1B03BAF")
    ILinkDetailsWnd2 : public IDetailsWnd
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILinkDetailsWnd2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILinkDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILinkDetailsWnd2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ILinkDetailsWnd2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ILinkDetailsWnd2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ILinkDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ILinkDetailsWnd2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ILinkDetailsWnd2 * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterParent )( 
            ILinkDetailsWnd2 * This,
            IDetailsWndParent *parent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ILinkDetailsWnd2 * This,
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            ILinkDetailsWnd2 * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            ILinkDetailsWnd2 * This,
            SIZE size,
            VARIANT_BOOL redraw);
        
        HRESULT ( STDMETHODCALLTYPE *SetFixedSize )( 
            ILinkDetailsWnd2 * This,
            VARIANT_BOOL fixed);
        
        HRESULT ( STDMETHODCALLTYPE *GetInteriorRect )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBkColor )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *AreaToOrigin )( 
            ILinkDetailsWnd2 * This,
            RECT parentArea,
            /* [retval][out] */ POINT *retval);
        
        HRESULT ( STDMETHODCALLTYPE *Show )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Fade )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Hide )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *PinWindow )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *UnpinWindow )( 
            ILinkDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetInterior )( 
            ILinkDetailsWnd2 * This,
            int hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetInterior )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserParam )( 
            ILinkDetailsWnd2 * This,
            long param);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserParam )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ long *param);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserUnk )( 
            ILinkDetailsWnd2 * This,
            IUnknown *unk);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserUnk )( 
            ILinkDetailsWnd2 * This,
            /* [retval][out] */ IUnknown **unk);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            ILinkDetailsWnd2 * This,
            IGraphics *graphics,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *Create2 )( 
            ILinkDetailsWnd2 * This,
            int hwndParent,
            IUnknown *panelConfig);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            ILinkDetailsWnd2 * This,
            BSTR text);
        
        END_INTERFACE
    } ILinkDetailsWnd2Vtbl;

    interface ILinkDetailsWnd2
    {
        CONST_VTBL struct ILinkDetailsWnd2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILinkDetailsWnd2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILinkDetailsWnd2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILinkDetailsWnd2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILinkDetailsWnd2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILinkDetailsWnd2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILinkDetailsWnd2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILinkDetailsWnd2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILinkDetailsWnd2_Init(This,settings,skinManager,panelConfig,parent,caption)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,panelConfig,parent,caption)

#define ILinkDetailsWnd2_RegisterParent(This,parent)	\
    (This)->lpVtbl -> RegisterParent(This,parent)

#define ILinkDetailsWnd2_Create(This,hwndParent,flags,origin,size)	\
    (This)->lpVtbl -> Create(This,hwndParent,flags,origin,size)

#define ILinkDetailsWnd2_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ILinkDetailsWnd2_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define ILinkDetailsWnd2_GetSize(This,retVal)	\
    (This)->lpVtbl -> GetSize(This,retVal)

#define ILinkDetailsWnd2_SetSize(This,size,redraw)	\
    (This)->lpVtbl -> SetSize(This,size,redraw)

#define ILinkDetailsWnd2_SetFixedSize(This,fixed)	\
    (This)->lpVtbl -> SetFixedSize(This,fixed)

#define ILinkDetailsWnd2_GetInteriorRect(This,retVal)	\
    (This)->lpVtbl -> GetInteriorRect(This,retVal)

#define ILinkDetailsWnd2_GetBkColor(This,argb)	\
    (This)->lpVtbl -> GetBkColor(This,argb)

#define ILinkDetailsWnd2_AreaToOrigin(This,parentArea,retval)	\
    (This)->lpVtbl -> AreaToOrigin(This,parentArea,retval)

#define ILinkDetailsWnd2_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define ILinkDetailsWnd2_Fade(This)	\
    (This)->lpVtbl -> Fade(This)

#define ILinkDetailsWnd2_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define ILinkDetailsWnd2_PinWindow(This)	\
    (This)->lpVtbl -> PinWindow(This)

#define ILinkDetailsWnd2_UnpinWindow(This)	\
    (This)->lpVtbl -> UnpinWindow(This)

#define ILinkDetailsWnd2_SetInterior(This,hwnd)	\
    (This)->lpVtbl -> SetInterior(This,hwnd)

#define ILinkDetailsWnd2_GetInterior(This,retVal)	\
    (This)->lpVtbl -> GetInterior(This,retVal)

#define ILinkDetailsWnd2_SetUserParam(This,param)	\
    (This)->lpVtbl -> SetUserParam(This,param)

#define ILinkDetailsWnd2_GetUserParam(This,param)	\
    (This)->lpVtbl -> GetUserParam(This,param)

#define ILinkDetailsWnd2_SetUserUnk(This,unk)	\
    (This)->lpVtbl -> SetUserUnk(This,unk)

#define ILinkDetailsWnd2_GetUserUnk(This,unk)	\
    (This)->lpVtbl -> GetUserUnk(This,unk)

#define ILinkDetailsWnd2_DrawBackground(This,graphics,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,rc)

#define ILinkDetailsWnd2_Create2(This,hwndParent,panelConfig)	\
    (This)->lpVtbl -> Create2(This,hwndParent,panelConfig)


#define ILinkDetailsWnd2_Set(This,text)	\
    (This)->lpVtbl -> Set(This,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ILinkDetailsWnd2_Set_Proxy( 
    ILinkDetailsWnd2 * This,
    BSTR text);


void __RPC_STUB ILinkDetailsWnd2_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILinkDetailsWnd2_INTERFACE_DEFINED__ */


#ifndef __IHTMLDetailsWnd_INTERFACE_DEFINED__
#define __IHTMLDetailsWnd_INTERFACE_DEFINED__

/* interface IHTMLDetailsWnd */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IHTMLDetailsWnd;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8B080798-B27F-4a3d-99BC-8D7CEF86E828")
    IHTMLDetailsWnd : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR body) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetExternal( 
            IDispatch *ext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowImages( 
            VARIANT_BOOL showImages) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHTMLDetailsWndVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHTMLDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHTMLDetailsWnd * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHTMLDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IHTMLDetailsWnd * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IHTMLDetailsWnd * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IHTMLDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IHTMLDetailsWnd * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            IHTMLDetailsWnd * This,
            BSTR body);
        
        HRESULT ( STDMETHODCALLTYPE *SetExternal )( 
            IHTMLDetailsWnd * This,
            IDispatch *ext);
        
        HRESULT ( STDMETHODCALLTYPE *ShowImages )( 
            IHTMLDetailsWnd * This,
            VARIANT_BOOL showImages);
        
        END_INTERFACE
    } IHTMLDetailsWndVtbl;

    interface IHTMLDetailsWnd
    {
        CONST_VTBL struct IHTMLDetailsWndVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHTMLDetailsWnd_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHTMLDetailsWnd_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHTMLDetailsWnd_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHTMLDetailsWnd_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IHTMLDetailsWnd_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IHTMLDetailsWnd_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IHTMLDetailsWnd_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IHTMLDetailsWnd_Set(This,body)	\
    (This)->lpVtbl -> Set(This,body)

#define IHTMLDetailsWnd_SetExternal(This,ext)	\
    (This)->lpVtbl -> SetExternal(This,ext)

#define IHTMLDetailsWnd_ShowImages(This,showImages)	\
    (This)->lpVtbl -> ShowImages(This,showImages)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd_Set_Proxy( 
    IHTMLDetailsWnd * This,
    BSTR body);


void __RPC_STUB IHTMLDetailsWnd_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd_SetExternal_Proxy( 
    IHTMLDetailsWnd * This,
    IDispatch *ext);


void __RPC_STUB IHTMLDetailsWnd_SetExternal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd_ShowImages_Proxy( 
    IHTMLDetailsWnd * This,
    VARIANT_BOOL showImages);


void __RPC_STUB IHTMLDetailsWnd_ShowImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHTMLDetailsWnd_INTERFACE_DEFINED__ */


#ifndef __IHTMLDetailsWnd2_INTERFACE_DEFINED__
#define __IHTMLDetailsWnd2_INTERFACE_DEFINED__

/* interface IHTMLDetailsWnd2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IHTMLDetailsWnd2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("BD3B0EE7-2C09-4ad3-BAC9-18E188654EA1")
    IHTMLDetailsWnd2 : public IDetailsWnd
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR body) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetExternal( 
            IDispatch *ext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowImages( 
            VARIANT_BOOL showImages) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHTMLDetailsWnd2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHTMLDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHTMLDetailsWnd2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IHTMLDetailsWnd2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IHTMLDetailsWnd2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IHTMLDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IHTMLDetailsWnd2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IHTMLDetailsWnd2 * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterParent )( 
            IHTMLDetailsWnd2 * This,
            IDetailsWndParent *parent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IHTMLDetailsWnd2 * This,
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IHTMLDetailsWnd2 * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            IHTMLDetailsWnd2 * This,
            SIZE size,
            VARIANT_BOOL redraw);
        
        HRESULT ( STDMETHODCALLTYPE *SetFixedSize )( 
            IHTMLDetailsWnd2 * This,
            VARIANT_BOOL fixed);
        
        HRESULT ( STDMETHODCALLTYPE *GetInteriorRect )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBkColor )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *AreaToOrigin )( 
            IHTMLDetailsWnd2 * This,
            RECT parentArea,
            /* [retval][out] */ POINT *retval);
        
        HRESULT ( STDMETHODCALLTYPE *Show )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Fade )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Hide )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *PinWindow )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *UnpinWindow )( 
            IHTMLDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetInterior )( 
            IHTMLDetailsWnd2 * This,
            int hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetInterior )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserParam )( 
            IHTMLDetailsWnd2 * This,
            long param);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserParam )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ long *param);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserUnk )( 
            IHTMLDetailsWnd2 * This,
            IUnknown *unk);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserUnk )( 
            IHTMLDetailsWnd2 * This,
            /* [retval][out] */ IUnknown **unk);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            IHTMLDetailsWnd2 * This,
            IGraphics *graphics,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *Create2 )( 
            IHTMLDetailsWnd2 * This,
            int hwndParent,
            IUnknown *panelConfig);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            IHTMLDetailsWnd2 * This,
            BSTR body);
        
        HRESULT ( STDMETHODCALLTYPE *SetExternal )( 
            IHTMLDetailsWnd2 * This,
            IDispatch *ext);
        
        HRESULT ( STDMETHODCALLTYPE *ShowImages )( 
            IHTMLDetailsWnd2 * This,
            VARIANT_BOOL showImages);
        
        END_INTERFACE
    } IHTMLDetailsWnd2Vtbl;

    interface IHTMLDetailsWnd2
    {
        CONST_VTBL struct IHTMLDetailsWnd2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHTMLDetailsWnd2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHTMLDetailsWnd2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHTMLDetailsWnd2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHTMLDetailsWnd2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IHTMLDetailsWnd2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IHTMLDetailsWnd2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IHTMLDetailsWnd2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IHTMLDetailsWnd2_Init(This,settings,skinManager,panelConfig,parent,caption)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,panelConfig,parent,caption)

#define IHTMLDetailsWnd2_RegisterParent(This,parent)	\
    (This)->lpVtbl -> RegisterParent(This,parent)

#define IHTMLDetailsWnd2_Create(This,hwndParent,flags,origin,size)	\
    (This)->lpVtbl -> Create(This,hwndParent,flags,origin,size)

#define IHTMLDetailsWnd2_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IHTMLDetailsWnd2_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define IHTMLDetailsWnd2_GetSize(This,retVal)	\
    (This)->lpVtbl -> GetSize(This,retVal)

#define IHTMLDetailsWnd2_SetSize(This,size,redraw)	\
    (This)->lpVtbl -> SetSize(This,size,redraw)

#define IHTMLDetailsWnd2_SetFixedSize(This,fixed)	\
    (This)->lpVtbl -> SetFixedSize(This,fixed)

#define IHTMLDetailsWnd2_GetInteriorRect(This,retVal)	\
    (This)->lpVtbl -> GetInteriorRect(This,retVal)

#define IHTMLDetailsWnd2_GetBkColor(This,argb)	\
    (This)->lpVtbl -> GetBkColor(This,argb)

#define IHTMLDetailsWnd2_AreaToOrigin(This,parentArea,retval)	\
    (This)->lpVtbl -> AreaToOrigin(This,parentArea,retval)

#define IHTMLDetailsWnd2_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IHTMLDetailsWnd2_Fade(This)	\
    (This)->lpVtbl -> Fade(This)

#define IHTMLDetailsWnd2_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define IHTMLDetailsWnd2_PinWindow(This)	\
    (This)->lpVtbl -> PinWindow(This)

#define IHTMLDetailsWnd2_UnpinWindow(This)	\
    (This)->lpVtbl -> UnpinWindow(This)

#define IHTMLDetailsWnd2_SetInterior(This,hwnd)	\
    (This)->lpVtbl -> SetInterior(This,hwnd)

#define IHTMLDetailsWnd2_GetInterior(This,retVal)	\
    (This)->lpVtbl -> GetInterior(This,retVal)

#define IHTMLDetailsWnd2_SetUserParam(This,param)	\
    (This)->lpVtbl -> SetUserParam(This,param)

#define IHTMLDetailsWnd2_GetUserParam(This,param)	\
    (This)->lpVtbl -> GetUserParam(This,param)

#define IHTMLDetailsWnd2_SetUserUnk(This,unk)	\
    (This)->lpVtbl -> SetUserUnk(This,unk)

#define IHTMLDetailsWnd2_GetUserUnk(This,unk)	\
    (This)->lpVtbl -> GetUserUnk(This,unk)

#define IHTMLDetailsWnd2_DrawBackground(This,graphics,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,rc)

#define IHTMLDetailsWnd2_Create2(This,hwndParent,panelConfig)	\
    (This)->lpVtbl -> Create2(This,hwndParent,panelConfig)


#define IHTMLDetailsWnd2_Set(This,body)	\
    (This)->lpVtbl -> Set(This,body)

#define IHTMLDetailsWnd2_SetExternal(This,ext)	\
    (This)->lpVtbl -> SetExternal(This,ext)

#define IHTMLDetailsWnd2_ShowImages(This,showImages)	\
    (This)->lpVtbl -> ShowImages(This,showImages)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd2_Set_Proxy( 
    IHTMLDetailsWnd2 * This,
    BSTR body);


void __RPC_STUB IHTMLDetailsWnd2_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd2_SetExternal_Proxy( 
    IHTMLDetailsWnd2 * This,
    IDispatch *ext);


void __RPC_STUB IHTMLDetailsWnd2_SetExternal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IHTMLDetailsWnd2_ShowImages_Proxy( 
    IHTMLDetailsWnd2 * This,
    VARIANT_BOOL showImages);


void __RPC_STUB IHTMLDetailsWnd2_ShowImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHTMLDetailsWnd2_INTERFACE_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd_INTERFACE_DEFINED__
#define __IWebBrowserDetailsWnd_INTERFACE_DEFINED__

/* interface IWebBrowserDetailsWnd */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IWebBrowserDetailsWnd;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B63CE24A-EF42-4912-B9F5-5232D830C0ED")
    IWebBrowserDetailsWnd : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR url) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowImages( 
            VARIANT_BOOL showImages) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IWebBrowserDetailsWndVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IWebBrowserDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IWebBrowserDetailsWnd * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IWebBrowserDetailsWnd * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IWebBrowserDetailsWnd * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IWebBrowserDetailsWnd * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IWebBrowserDetailsWnd * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IWebBrowserDetailsWnd * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            IWebBrowserDetailsWnd * This,
            BSTR url);
        
        HRESULT ( STDMETHODCALLTYPE *ShowImages )( 
            IWebBrowserDetailsWnd * This,
            VARIANT_BOOL showImages);
        
        END_INTERFACE
    } IWebBrowserDetailsWndVtbl;

    interface IWebBrowserDetailsWnd
    {
        CONST_VTBL struct IWebBrowserDetailsWndVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IWebBrowserDetailsWnd_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IWebBrowserDetailsWnd_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IWebBrowserDetailsWnd_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IWebBrowserDetailsWnd_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IWebBrowserDetailsWnd_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IWebBrowserDetailsWnd_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IWebBrowserDetailsWnd_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IWebBrowserDetailsWnd_Set(This,url)	\
    (This)->lpVtbl -> Set(This,url)

#define IWebBrowserDetailsWnd_ShowImages(This,showImages)	\
    (This)->lpVtbl -> ShowImages(This,showImages)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IWebBrowserDetailsWnd_Set_Proxy( 
    IWebBrowserDetailsWnd * This,
    BSTR url);


void __RPC_STUB IWebBrowserDetailsWnd_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IWebBrowserDetailsWnd_ShowImages_Proxy( 
    IWebBrowserDetailsWnd * This,
    VARIANT_BOOL showImages);


void __RPC_STUB IWebBrowserDetailsWnd_ShowImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IWebBrowserDetailsWnd_INTERFACE_DEFINED__ */


#ifndef __IWebBrowserDetailsWnd2_INTERFACE_DEFINED__
#define __IWebBrowserDetailsWnd2_INTERFACE_DEFINED__

/* interface IWebBrowserDetailsWnd2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IWebBrowserDetailsWnd2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F78EDDBB-FBB3-4349-9A6A-73DB6F9B9A8F")
    IWebBrowserDetailsWnd2 : public IDetailsWnd
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Set( 
            BSTR url) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowImages( 
            VARIANT_BOOL showImages) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IWebBrowserDetailsWnd2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IWebBrowserDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IWebBrowserDetailsWnd2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IWebBrowserDetailsWnd2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IWebBrowserDetailsWnd2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IWebBrowserDetailsWnd2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IWebBrowserDetailsWnd2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            IWebBrowserDetailsWnd2 * This,
            IGlobalSettings *settings,
            ISkinManager *skinManager,
            IUnknown *panelConfig,
            IDetailsWndParent *parent,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterParent )( 
            IWebBrowserDetailsWnd2 * This,
            IDetailsWndParent *parent);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IWebBrowserDetailsWnd2 * This,
            int hwndParent,
            int flags,
            /* [in] */ const POINT *origin,
            /* [in] */ const SIZE *size);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ int *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IWebBrowserDetailsWnd2 * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetSize )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            IWebBrowserDetailsWnd2 * This,
            SIZE size,
            VARIANT_BOOL redraw);
        
        HRESULT ( STDMETHODCALLTYPE *SetFixedSize )( 
            IWebBrowserDetailsWnd2 * This,
            VARIANT_BOOL fixed);
        
        HRESULT ( STDMETHODCALLTYPE *GetInteriorRect )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ RECT *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetBkColor )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ DWORD *argb);
        
        HRESULT ( STDMETHODCALLTYPE *AreaToOrigin )( 
            IWebBrowserDetailsWnd2 * This,
            RECT parentArea,
            /* [retval][out] */ POINT *retval);
        
        HRESULT ( STDMETHODCALLTYPE *Show )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Fade )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *Hide )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *PinWindow )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *UnpinWindow )( 
            IWebBrowserDetailsWnd2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetInterior )( 
            IWebBrowserDetailsWnd2 * This,
            int hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetInterior )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserParam )( 
            IWebBrowserDetailsWnd2 * This,
            long param);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserParam )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ long *param);
        
        HRESULT ( STDMETHODCALLTYPE *SetUserUnk )( 
            IWebBrowserDetailsWnd2 * This,
            IUnknown *unk);
        
        HRESULT ( STDMETHODCALLTYPE *GetUserUnk )( 
            IWebBrowserDetailsWnd2 * This,
            /* [retval][out] */ IUnknown **unk);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            IWebBrowserDetailsWnd2 * This,
            IGraphics *graphics,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *Create2 )( 
            IWebBrowserDetailsWnd2 * This,
            int hwndParent,
            IUnknown *panelConfig);
        
        HRESULT ( STDMETHODCALLTYPE *Set )( 
            IWebBrowserDetailsWnd2 * This,
            BSTR url);
        
        HRESULT ( STDMETHODCALLTYPE *ShowImages )( 
            IWebBrowserDetailsWnd2 * This,
            VARIANT_BOOL showImages);
        
        END_INTERFACE
    } IWebBrowserDetailsWnd2Vtbl;

    interface IWebBrowserDetailsWnd2
    {
        CONST_VTBL struct IWebBrowserDetailsWnd2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IWebBrowserDetailsWnd2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IWebBrowserDetailsWnd2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IWebBrowserDetailsWnd2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IWebBrowserDetailsWnd2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IWebBrowserDetailsWnd2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IWebBrowserDetailsWnd2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IWebBrowserDetailsWnd2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IWebBrowserDetailsWnd2_Init(This,settings,skinManager,panelConfig,parent,caption)	\
    (This)->lpVtbl -> Init(This,settings,skinManager,panelConfig,parent,caption)

#define IWebBrowserDetailsWnd2_RegisterParent(This,parent)	\
    (This)->lpVtbl -> RegisterParent(This,parent)

#define IWebBrowserDetailsWnd2_Create(This,hwndParent,flags,origin,size)	\
    (This)->lpVtbl -> Create(This,hwndParent,flags,origin,size)

#define IWebBrowserDetailsWnd2_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IWebBrowserDetailsWnd2_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define IWebBrowserDetailsWnd2_GetSize(This,retVal)	\
    (This)->lpVtbl -> GetSize(This,retVal)

#define IWebBrowserDetailsWnd2_SetSize(This,size,redraw)	\
    (This)->lpVtbl -> SetSize(This,size,redraw)

#define IWebBrowserDetailsWnd2_SetFixedSize(This,fixed)	\
    (This)->lpVtbl -> SetFixedSize(This,fixed)

#define IWebBrowserDetailsWnd2_GetInteriorRect(This,retVal)	\
    (This)->lpVtbl -> GetInteriorRect(This,retVal)

#define IWebBrowserDetailsWnd2_GetBkColor(This,argb)	\
    (This)->lpVtbl -> GetBkColor(This,argb)

#define IWebBrowserDetailsWnd2_AreaToOrigin(This,parentArea,retval)	\
    (This)->lpVtbl -> AreaToOrigin(This,parentArea,retval)

#define IWebBrowserDetailsWnd2_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IWebBrowserDetailsWnd2_Fade(This)	\
    (This)->lpVtbl -> Fade(This)

#define IWebBrowserDetailsWnd2_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define IWebBrowserDetailsWnd2_PinWindow(This)	\
    (This)->lpVtbl -> PinWindow(This)

#define IWebBrowserDetailsWnd2_UnpinWindow(This)	\
    (This)->lpVtbl -> UnpinWindow(This)

#define IWebBrowserDetailsWnd2_SetInterior(This,hwnd)	\
    (This)->lpVtbl -> SetInterior(This,hwnd)

#define IWebBrowserDetailsWnd2_GetInterior(This,retVal)	\
    (This)->lpVtbl -> GetInterior(This,retVal)

#define IWebBrowserDetailsWnd2_SetUserParam(This,param)	\
    (This)->lpVtbl -> SetUserParam(This,param)

#define IWebBrowserDetailsWnd2_GetUserParam(This,param)	\
    (This)->lpVtbl -> GetUserParam(This,param)

#define IWebBrowserDetailsWnd2_SetUserUnk(This,unk)	\
    (This)->lpVtbl -> SetUserUnk(This,unk)

#define IWebBrowserDetailsWnd2_GetUserUnk(This,unk)	\
    (This)->lpVtbl -> GetUserUnk(This,unk)

#define IWebBrowserDetailsWnd2_DrawBackground(This,graphics,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,rc)

#define IWebBrowserDetailsWnd2_Create2(This,hwndParent,panelConfig)	\
    (This)->lpVtbl -> Create2(This,hwndParent,panelConfig)


#define IWebBrowserDetailsWnd2_Set(This,url)	\
    (This)->lpVtbl -> Set(This,url)

#define IWebBrowserDetailsWnd2_ShowImages(This,showImages)	\
    (This)->lpVtbl -> ShowImages(This,showImages)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IWebBrowserDetailsWnd2_Set_Proxy( 
    IWebBrowserDetailsWnd2 * This,
    BSTR url);


void __RPC_STUB IWebBrowserDetailsWnd2_Set_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IWebBrowserDetailsWnd2_ShowImages_Proxy( 
    IWebBrowserDetailsWnd2 * This,
    VARIANT_BOOL showImages);


void __RPC_STUB IWebBrowserDetailsWnd2_ShowImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IWebBrowserDetailsWnd2_INTERFACE_DEFINED__ */


#ifndef __IControlFactory_INTERFACE_DEFINED__
#define __IControlFactory_INTERFACE_DEFINED__

/* interface IControlFactory */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IControlFactory;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("22CC67E0-5E43-4f17-9D94-F16CBE890B59")
    IControlFactory : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE CreateTextOutput( 
            /* [retval][out] */ ITextOutput **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateListOutput( 
            /* [retval][out] */ IListOutput **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateMarqueeOutput( 
            /* [retval][out] */ IMarqueeOutput **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateSkinButton( 
            /* [retval][out] */ ISkinButton **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateSkinProgressBar( 
            /* [retval][out] */ ISkinProgressBar **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateSkinSlider( 
            /* [retval][out] */ ISkinSlider **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateBarChart( 
            /* [retval][out] */ IBarChart **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateDetailsWnd( 
            /* [retval][out] */ IDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateTextDetailsWnd( 
            /* [retval][out] */ ITextDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateLinkDetailsWnd( 
            /* [retval][out] */ ILinkDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateHTMLDetailsWnd( 
            /* [retval][out] */ IHTMLDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateWebBrowserDetailsWnd( 
            /* [retval][out] */ IWebBrowserDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InteriorToDetailsSize( 
            SIZE interior,
            BSTR caption,
            /* [retval][out] */ SIZE *detailsSize) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE HideAllDetails( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsDetailsDisplayed( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreatePopupMenu( 
            /* [retval][out] */ HMENU *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InsertMenuSeparator( 
            /* [in] */ int hMenu,
            int pos) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InsertMenuItem( 
            /* [in] */ int hMenu,
            int pos,
            BSTR caption,
            int command) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateDetailsWnd2( 
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateTextDetailsWnd2( 
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ ITextDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateLinkDetailsWnd2( 
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ ILinkDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateHTMLDetailsWnd2( 
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IHTMLDetailsWnd **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateWebBrowserDetailsWnd2( 
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IWebBrowserDetailsWnd **retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IControlFactoryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IControlFactory * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IControlFactory * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IControlFactory * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IControlFactory * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IControlFactory * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IControlFactory * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IControlFactory * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *CreateTextOutput )( 
            IControlFactory * This,
            /* [retval][out] */ ITextOutput **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateListOutput )( 
            IControlFactory * This,
            /* [retval][out] */ IListOutput **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateMarqueeOutput )( 
            IControlFactory * This,
            /* [retval][out] */ IMarqueeOutput **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateSkinButton )( 
            IControlFactory * This,
            /* [retval][out] */ ISkinButton **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateSkinProgressBar )( 
            IControlFactory * This,
            /* [retval][out] */ ISkinProgressBar **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateSkinSlider )( 
            IControlFactory * This,
            /* [retval][out] */ ISkinSlider **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateBarChart )( 
            IControlFactory * This,
            /* [retval][out] */ IBarChart **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateDetailsWnd )( 
            IControlFactory * This,
            /* [retval][out] */ IDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateTextDetailsWnd )( 
            IControlFactory * This,
            /* [retval][out] */ ITextDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateLinkDetailsWnd )( 
            IControlFactory * This,
            /* [retval][out] */ ILinkDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateHTMLDetailsWnd )( 
            IControlFactory * This,
            /* [retval][out] */ IHTMLDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateWebBrowserDetailsWnd )( 
            IControlFactory * This,
            /* [retval][out] */ IWebBrowserDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *InteriorToDetailsSize )( 
            IControlFactory * This,
            SIZE interior,
            BSTR caption,
            /* [retval][out] */ SIZE *detailsSize);
        
        HRESULT ( STDMETHODCALLTYPE *HideAllDetails )( 
            IControlFactory * This);
        
        HRESULT ( STDMETHODCALLTYPE *IsDetailsDisplayed )( 
            IControlFactory * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreatePopupMenu )( 
            IControlFactory * This,
            /* [retval][out] */ HMENU *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *InsertMenuSeparator )( 
            IControlFactory * This,
            /* [in] */ int hMenu,
            int pos);
        
        HRESULT ( STDMETHODCALLTYPE *InsertMenuItem )( 
            IControlFactory * This,
            /* [in] */ int hMenu,
            int pos,
            BSTR caption,
            int command);
        
        HRESULT ( STDMETHODCALLTYPE *CreateDetailsWnd2 )( 
            IControlFactory * This,
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateTextDetailsWnd2 )( 
            IControlFactory * This,
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ ITextDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateLinkDetailsWnd2 )( 
            IControlFactory * This,
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ ILinkDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateHTMLDetailsWnd2 )( 
            IControlFactory * This,
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IHTMLDetailsWnd **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *CreateWebBrowserDetailsWnd2 )( 
            IControlFactory * This,
            BSTR panel,
            VARIANT_BOOL click,
            DWORD style,
            /* [retval][out] */ IWebBrowserDetailsWnd **retVal);
        
        END_INTERFACE
    } IControlFactoryVtbl;

    interface IControlFactory
    {
        CONST_VTBL struct IControlFactoryVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IControlFactory_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IControlFactory_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IControlFactory_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IControlFactory_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IControlFactory_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IControlFactory_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IControlFactory_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IControlFactory_CreateTextOutput(This,retVal)	\
    (This)->lpVtbl -> CreateTextOutput(This,retVal)

#define IControlFactory_CreateListOutput(This,retVal)	\
    (This)->lpVtbl -> CreateListOutput(This,retVal)

#define IControlFactory_CreateMarqueeOutput(This,retVal)	\
    (This)->lpVtbl -> CreateMarqueeOutput(This,retVal)

#define IControlFactory_CreateSkinButton(This,retVal)	\
    (This)->lpVtbl -> CreateSkinButton(This,retVal)

#define IControlFactory_CreateSkinProgressBar(This,retVal)	\
    (This)->lpVtbl -> CreateSkinProgressBar(This,retVal)

#define IControlFactory_CreateSkinSlider(This,retVal)	\
    (This)->lpVtbl -> CreateSkinSlider(This,retVal)

#define IControlFactory_CreateBarChart(This,retVal)	\
    (This)->lpVtbl -> CreateBarChart(This,retVal)

#define IControlFactory_CreateDetailsWnd(This,retVal)	\
    (This)->lpVtbl -> CreateDetailsWnd(This,retVal)

#define IControlFactory_CreateTextDetailsWnd(This,retVal)	\
    (This)->lpVtbl -> CreateTextDetailsWnd(This,retVal)

#define IControlFactory_CreateLinkDetailsWnd(This,retVal)	\
    (This)->lpVtbl -> CreateLinkDetailsWnd(This,retVal)

#define IControlFactory_CreateHTMLDetailsWnd(This,retVal)	\
    (This)->lpVtbl -> CreateHTMLDetailsWnd(This,retVal)

#define IControlFactory_CreateWebBrowserDetailsWnd(This,retVal)	\
    (This)->lpVtbl -> CreateWebBrowserDetailsWnd(This,retVal)

#define IControlFactory_InteriorToDetailsSize(This,interior,caption,detailsSize)	\
    (This)->lpVtbl -> InteriorToDetailsSize(This,interior,caption,detailsSize)

#define IControlFactory_HideAllDetails(This)	\
    (This)->lpVtbl -> HideAllDetails(This)

#define IControlFactory_IsDetailsDisplayed(This,retVal)	\
    (This)->lpVtbl -> IsDetailsDisplayed(This,retVal)

#define IControlFactory_CreatePopupMenu(This,retVal)	\
    (This)->lpVtbl -> CreatePopupMenu(This,retVal)

#define IControlFactory_InsertMenuSeparator(This,hMenu,pos)	\
    (This)->lpVtbl -> InsertMenuSeparator(This,hMenu,pos)

#define IControlFactory_InsertMenuItem(This,hMenu,pos,caption,command)	\
    (This)->lpVtbl -> InsertMenuItem(This,hMenu,pos,caption,command)

#define IControlFactory_CreateDetailsWnd2(This,panel,click,style,retVal)	\
    (This)->lpVtbl -> CreateDetailsWnd2(This,panel,click,style,retVal)

#define IControlFactory_CreateTextDetailsWnd2(This,panel,click,style,retVal)	\
    (This)->lpVtbl -> CreateTextDetailsWnd2(This,panel,click,style,retVal)

#define IControlFactory_CreateLinkDetailsWnd2(This,panel,click,style,retVal)	\
    (This)->lpVtbl -> CreateLinkDetailsWnd2(This,panel,click,style,retVal)

#define IControlFactory_CreateHTMLDetailsWnd2(This,panel,click,style,retVal)	\
    (This)->lpVtbl -> CreateHTMLDetailsWnd2(This,panel,click,style,retVal)

#define IControlFactory_CreateWebBrowserDetailsWnd2(This,panel,click,style,retVal)	\
    (This)->lpVtbl -> CreateWebBrowserDetailsWnd2(This,panel,click,style,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IControlFactory_CreateTextOutput_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ITextOutput **retVal);


void __RPC_STUB IControlFactory_CreateTextOutput_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateListOutput_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IListOutput **retVal);


void __RPC_STUB IControlFactory_CreateListOutput_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateMarqueeOutput_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IMarqueeOutput **retVal);


void __RPC_STUB IControlFactory_CreateMarqueeOutput_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateSkinButton_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ISkinButton **retVal);


void __RPC_STUB IControlFactory_CreateSkinButton_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateSkinProgressBar_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ISkinProgressBar **retVal);


void __RPC_STUB IControlFactory_CreateSkinProgressBar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateSkinSlider_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ISkinSlider **retVal);


void __RPC_STUB IControlFactory_CreateSkinSlider_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateBarChart_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IBarChart **retVal);


void __RPC_STUB IControlFactory_CreateBarChart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateDetailsWnd_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateTextDetailsWnd_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ITextDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateTextDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateLinkDetailsWnd_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ ILinkDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateLinkDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateHTMLDetailsWnd_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IHTMLDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateHTMLDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateWebBrowserDetailsWnd_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ IWebBrowserDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateWebBrowserDetailsWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_InteriorToDetailsSize_Proxy( 
    IControlFactory * This,
    SIZE interior,
    BSTR caption,
    /* [retval][out] */ SIZE *detailsSize);


void __RPC_STUB IControlFactory_InteriorToDetailsSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_HideAllDetails_Proxy( 
    IControlFactory * This);


void __RPC_STUB IControlFactory_HideAllDetails_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_IsDetailsDisplayed_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IControlFactory_IsDetailsDisplayed_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreatePopupMenu_Proxy( 
    IControlFactory * This,
    /* [retval][out] */ HMENU *retVal);


void __RPC_STUB IControlFactory_CreatePopupMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_InsertMenuSeparator_Proxy( 
    IControlFactory * This,
    /* [in] */ int hMenu,
    int pos);


void __RPC_STUB IControlFactory_InsertMenuSeparator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_InsertMenuItem_Proxy( 
    IControlFactory * This,
    /* [in] */ int hMenu,
    int pos,
    BSTR caption,
    int command);


void __RPC_STUB IControlFactory_InsertMenuItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateDetailsWnd2_Proxy( 
    IControlFactory * This,
    BSTR panel,
    VARIANT_BOOL click,
    DWORD style,
    /* [retval][out] */ IDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateDetailsWnd2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateTextDetailsWnd2_Proxy( 
    IControlFactory * This,
    BSTR panel,
    VARIANT_BOOL click,
    DWORD style,
    /* [retval][out] */ ITextDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateTextDetailsWnd2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateLinkDetailsWnd2_Proxy( 
    IControlFactory * This,
    BSTR panel,
    VARIANT_BOOL click,
    DWORD style,
    /* [retval][out] */ ILinkDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateLinkDetailsWnd2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateHTMLDetailsWnd2_Proxy( 
    IControlFactory * This,
    BSTR panel,
    VARIANT_BOOL click,
    DWORD style,
    /* [retval][out] */ IHTMLDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateHTMLDetailsWnd2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IControlFactory_CreateWebBrowserDetailsWnd2_Proxy( 
    IControlFactory * This,
    BSTR panel,
    VARIANT_BOOL click,
    DWORD style,
    /* [retval][out] */ IWebBrowserDetailsWnd **retVal);


void __RPC_STUB IControlFactory_CreateWebBrowserDetailsWnd2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IControlFactory_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0310 */
/* [local] */ 


enum EPanelFlags
    {	PF_OBLIGATORY_PANEL	= 0x1,
	PF_HIDDEN_PANEL	= 0x2,
	PF_UNDOCKED_PANEL	= 0x4
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0310_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0310_v0_0_s_ifspec;

#ifndef __ISidebar_INTERFACE_DEFINED__
#define __ISidebar_INTERFACE_DEFINED__

/* interface ISidebar */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISidebar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E8BFA187-1CA7-46e4-A30E-FB9EDCCC6BBB")
    ISidebar : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetPanel( 
            BSTR panelClass,
            /* [retval][out] */ IUnknown **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterPanel( 
            BSTR panelClass,
            BSTR panelCaption,
            BSTR panelDescription,
            int himagelist,
            BSTR panelIcon,
            BSTR panelCategory,
            BSTR categoryIcon,
            BSTR panelFiles,
            BSTR panelCanvas,
            int pluginCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetTranslator( 
            /* [retval][out] */ ITranslator **manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSkinManager( 
            /* [retval][out] */ ISkinManager **manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAlertManager( 
            /* [retval][out] */ IAlertManager **manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCommandManager( 
            /* [retval][out] */ ICommandManager **manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetGlobalSettings( 
            /* [retval][out] */ IGlobalSettings **settings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControlFactory( 
            /* [retval][out] */ IControlFactory **factory) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateGraphics( 
            int hdc,
            /* [retval][out] */ IGraphics **graphics) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OpenXml( 
            BSTR filePath,
            /* [out] */ BSTR *errorMsg,
            /* [retval][out] */ IXmlNode **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetVersion( 
            /* [out] */ int *major,
            /* [out] */ int *minor,
            /* [retval][out] */ int *build) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSettingsDir( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SaveConfiguration( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Log( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterPanel2( 
            BSTR panelClass,
            BSTR panelCaption,
            BSTR panelDescription,
            int himagelist,
            BSTR panelIcon,
            BSTR panelCategory,
            BSTR categoryIcon,
            BSTR panelFiles,
            BSTR panelCanvas,
            int panelFlags,
            int pluginCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CreateXml( 
            BSTR rootTag,
            /* [retval][out] */ IXmlBuilder **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SaveXml( 
            IXmlBuilder *xml,
            BSTR filePath,
            /* [out] */ BSTR *errorMsg) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DownloadFile( 
            BSTR filePath,
            BSTR url,
            VARIANT_BOOL reload,
            /* [retval][out] */ BSTR *__MIDL_0011) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE MsgBox( 
            BSTR text,
            /* [optional][in] */ VARIANT caption,
            /* [optional][in] */ VARIANT flags,
            /* [retval][out] */ int *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterCmdLineExtension( 
            BSTR identifier,
            BSTR prefix,
            BSTR caption,
            BSTR category,
            BSTR description,
            IXmlNode *forms,
            int pluginCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetInstallDir( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Trace( 
            BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OpenRSS( 
            BSTR filePath,
            /* [out] */ BSTR *errorMsg,
            /* [retval][out] */ IRSSFeed **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPlugin( 
            int pluginCookie,
            /* [retval][out] */ IUnknown **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPlugin2( 
            BSTR pluginName,
            /* [retval][out] */ IUnknown **retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetPluginsCount( 
            /* [retval][out] */ int *retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISidebarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISidebar * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISidebar * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISidebar * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISidebar * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISidebar * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISidebar * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISidebar * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetPanel )( 
            ISidebar * This,
            BSTR panelClass,
            /* [retval][out] */ IUnknown **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterPanel )( 
            ISidebar * This,
            BSTR panelClass,
            BSTR panelCaption,
            BSTR panelDescription,
            int himagelist,
            BSTR panelIcon,
            BSTR panelCategory,
            BSTR categoryIcon,
            BSTR panelFiles,
            BSTR panelCanvas,
            int pluginCookie);
        
        HRESULT ( STDMETHODCALLTYPE *GetTranslator )( 
            ISidebar * This,
            /* [retval][out] */ ITranslator **manager);
        
        HRESULT ( STDMETHODCALLTYPE *GetSkinManager )( 
            ISidebar * This,
            /* [retval][out] */ ISkinManager **manager);
        
        HRESULT ( STDMETHODCALLTYPE *GetAlertManager )( 
            ISidebar * This,
            /* [retval][out] */ IAlertManager **manager);
        
        HRESULT ( STDMETHODCALLTYPE *GetCommandManager )( 
            ISidebar * This,
            /* [retval][out] */ ICommandManager **manager);
        
        HRESULT ( STDMETHODCALLTYPE *GetGlobalSettings )( 
            ISidebar * This,
            /* [retval][out] */ IGlobalSettings **settings);
        
        HRESULT ( STDMETHODCALLTYPE *GetControlFactory )( 
            ISidebar * This,
            /* [retval][out] */ IControlFactory **factory);
        
        HRESULT ( STDMETHODCALLTYPE *CreateGraphics )( 
            ISidebar * This,
            int hdc,
            /* [retval][out] */ IGraphics **graphics);
        
        HRESULT ( STDMETHODCALLTYPE *OpenXml )( 
            ISidebar * This,
            BSTR filePath,
            /* [out] */ BSTR *errorMsg,
            /* [retval][out] */ IXmlNode **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetVersion )( 
            ISidebar * This,
            /* [out] */ int *major,
            /* [out] */ int *minor,
            /* [retval][out] */ int *build);
        
        HRESULT ( STDMETHODCALLTYPE *GetSettingsDir )( 
            ISidebar * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SaveConfiguration )( 
            ISidebar * This);
        
        HRESULT ( STDMETHODCALLTYPE *Log )( 
            ISidebar * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterPanel2 )( 
            ISidebar * This,
            BSTR panelClass,
            BSTR panelCaption,
            BSTR panelDescription,
            int himagelist,
            BSTR panelIcon,
            BSTR panelCategory,
            BSTR categoryIcon,
            BSTR panelFiles,
            BSTR panelCanvas,
            int panelFlags,
            int pluginCookie);
        
        HRESULT ( STDMETHODCALLTYPE *CreateXml )( 
            ISidebar * This,
            BSTR rootTag,
            /* [retval][out] */ IXmlBuilder **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SaveXml )( 
            ISidebar * This,
            IXmlBuilder *xml,
            BSTR filePath,
            /* [out] */ BSTR *errorMsg);
        
        HRESULT ( STDMETHODCALLTYPE *DownloadFile )( 
            ISidebar * This,
            BSTR filePath,
            BSTR url,
            VARIANT_BOOL reload,
            /* [retval][out] */ BSTR *__MIDL_0011);
        
        HRESULT ( STDMETHODCALLTYPE *MsgBox )( 
            ISidebar * This,
            BSTR text,
            /* [optional][in] */ VARIANT caption,
            /* [optional][in] */ VARIANT flags,
            /* [retval][out] */ int *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterCmdLineExtension )( 
            ISidebar * This,
            BSTR identifier,
            BSTR prefix,
            BSTR caption,
            BSTR category,
            BSTR description,
            IXmlNode *forms,
            int pluginCookie);
        
        HRESULT ( STDMETHODCALLTYPE *GetInstallDir )( 
            ISidebar * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Trace )( 
            ISidebar * This,
            BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *OpenRSS )( 
            ISidebar * This,
            BSTR filePath,
            /* [out] */ BSTR *errorMsg,
            /* [retval][out] */ IRSSFeed **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetPlugin )( 
            ISidebar * This,
            int pluginCookie,
            /* [retval][out] */ IUnknown **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetPlugin2 )( 
            ISidebar * This,
            BSTR pluginName,
            /* [retval][out] */ IUnknown **retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetPluginsCount )( 
            ISidebar * This,
            /* [retval][out] */ int *retVal);
        
        END_INTERFACE
    } ISidebarVtbl;

    interface ISidebar
    {
        CONST_VTBL struct ISidebarVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISidebar_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISidebar_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISidebar_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISidebar_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISidebar_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISidebar_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISidebar_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISidebar_GetPanel(This,panelClass,retVal)	\
    (This)->lpVtbl -> GetPanel(This,panelClass,retVal)

#define ISidebar_RegisterPanel(This,panelClass,panelCaption,panelDescription,himagelist,panelIcon,panelCategory,categoryIcon,panelFiles,panelCanvas,pluginCookie)	\
    (This)->lpVtbl -> RegisterPanel(This,panelClass,panelCaption,panelDescription,himagelist,panelIcon,panelCategory,categoryIcon,panelFiles,panelCanvas,pluginCookie)

#define ISidebar_GetTranslator(This,manager)	\
    (This)->lpVtbl -> GetTranslator(This,manager)

#define ISidebar_GetSkinManager(This,manager)	\
    (This)->lpVtbl -> GetSkinManager(This,manager)

#define ISidebar_GetAlertManager(This,manager)	\
    (This)->lpVtbl -> GetAlertManager(This,manager)

#define ISidebar_GetCommandManager(This,manager)	\
    (This)->lpVtbl -> GetCommandManager(This,manager)

#define ISidebar_GetGlobalSettings(This,settings)	\
    (This)->lpVtbl -> GetGlobalSettings(This,settings)

#define ISidebar_GetControlFactory(This,factory)	\
    (This)->lpVtbl -> GetControlFactory(This,factory)

#define ISidebar_CreateGraphics(This,hdc,graphics)	\
    (This)->lpVtbl -> CreateGraphics(This,hdc,graphics)

#define ISidebar_OpenXml(This,filePath,errorMsg,retVal)	\
    (This)->lpVtbl -> OpenXml(This,filePath,errorMsg,retVal)

#define ISidebar_GetVersion(This,major,minor,build)	\
    (This)->lpVtbl -> GetVersion(This,major,minor,build)

#define ISidebar_GetSettingsDir(This,retVal)	\
    (This)->lpVtbl -> GetSettingsDir(This,retVal)

#define ISidebar_SaveConfiguration(This)	\
    (This)->lpVtbl -> SaveConfiguration(This)

#define ISidebar_Log(This,text)	\
    (This)->lpVtbl -> Log(This,text)

#define ISidebar_RegisterPanel2(This,panelClass,panelCaption,panelDescription,himagelist,panelIcon,panelCategory,categoryIcon,panelFiles,panelCanvas,panelFlags,pluginCookie)	\
    (This)->lpVtbl -> RegisterPanel2(This,panelClass,panelCaption,panelDescription,himagelist,panelIcon,panelCategory,categoryIcon,panelFiles,panelCanvas,panelFlags,pluginCookie)

#define ISidebar_CreateXml(This,rootTag,retVal)	\
    (This)->lpVtbl -> CreateXml(This,rootTag,retVal)

#define ISidebar_SaveXml(This,xml,filePath,errorMsg)	\
    (This)->lpVtbl -> SaveXml(This,xml,filePath,errorMsg)

#define ISidebar_DownloadFile(This,filePath,url,reload,__MIDL_0011)	\
    (This)->lpVtbl -> DownloadFile(This,filePath,url,reload,__MIDL_0011)

#define ISidebar_MsgBox(This,text,caption,flags,retVal)	\
    (This)->lpVtbl -> MsgBox(This,text,caption,flags,retVal)

#define ISidebar_RegisterCmdLineExtension(This,identifier,prefix,caption,category,description,forms,pluginCookie)	\
    (This)->lpVtbl -> RegisterCmdLineExtension(This,identifier,prefix,caption,category,description,forms,pluginCookie)

#define ISidebar_GetInstallDir(This,retVal)	\
    (This)->lpVtbl -> GetInstallDir(This,retVal)

#define ISidebar_Trace(This,text)	\
    (This)->lpVtbl -> Trace(This,text)

#define ISidebar_OpenRSS(This,filePath,errorMsg,retVal)	\
    (This)->lpVtbl -> OpenRSS(This,filePath,errorMsg,retVal)

#define ISidebar_GetPlugin(This,pluginCookie,retVal)	\
    (This)->lpVtbl -> GetPlugin(This,pluginCookie,retVal)

#define ISidebar_GetPlugin2(This,pluginName,retVal)	\
    (This)->lpVtbl -> GetPlugin2(This,pluginName,retVal)

#define ISidebar_GetPluginsCount(This,retVal)	\
    (This)->lpVtbl -> GetPluginsCount(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISidebar_GetPanel_Proxy( 
    ISidebar * This,
    BSTR panelClass,
    /* [retval][out] */ IUnknown **retVal);


void __RPC_STUB ISidebar_GetPanel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_RegisterPanel_Proxy( 
    ISidebar * This,
    BSTR panelClass,
    BSTR panelCaption,
    BSTR panelDescription,
    int himagelist,
    BSTR panelIcon,
    BSTR panelCategory,
    BSTR categoryIcon,
    BSTR panelFiles,
    BSTR panelCanvas,
    int pluginCookie);


void __RPC_STUB ISidebar_RegisterPanel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetTranslator_Proxy( 
    ISidebar * This,
    /* [retval][out] */ ITranslator **manager);


void __RPC_STUB ISidebar_GetTranslator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetSkinManager_Proxy( 
    ISidebar * This,
    /* [retval][out] */ ISkinManager **manager);


void __RPC_STUB ISidebar_GetSkinManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetAlertManager_Proxy( 
    ISidebar * This,
    /* [retval][out] */ IAlertManager **manager);


void __RPC_STUB ISidebar_GetAlertManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetCommandManager_Proxy( 
    ISidebar * This,
    /* [retval][out] */ ICommandManager **manager);


void __RPC_STUB ISidebar_GetCommandManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetGlobalSettings_Proxy( 
    ISidebar * This,
    /* [retval][out] */ IGlobalSettings **settings);


void __RPC_STUB ISidebar_GetGlobalSettings_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetControlFactory_Proxy( 
    ISidebar * This,
    /* [retval][out] */ IControlFactory **factory);


void __RPC_STUB ISidebar_GetControlFactory_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_CreateGraphics_Proxy( 
    ISidebar * This,
    int hdc,
    /* [retval][out] */ IGraphics **graphics);


void __RPC_STUB ISidebar_CreateGraphics_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_OpenXml_Proxy( 
    ISidebar * This,
    BSTR filePath,
    /* [out] */ BSTR *errorMsg,
    /* [retval][out] */ IXmlNode **retVal);


void __RPC_STUB ISidebar_OpenXml_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetVersion_Proxy( 
    ISidebar * This,
    /* [out] */ int *major,
    /* [out] */ int *minor,
    /* [retval][out] */ int *build);


void __RPC_STUB ISidebar_GetVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetSettingsDir_Proxy( 
    ISidebar * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ISidebar_GetSettingsDir_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_SaveConfiguration_Proxy( 
    ISidebar * This);


void __RPC_STUB ISidebar_SaveConfiguration_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_Log_Proxy( 
    ISidebar * This,
    BSTR text);


void __RPC_STUB ISidebar_Log_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_RegisterPanel2_Proxy( 
    ISidebar * This,
    BSTR panelClass,
    BSTR panelCaption,
    BSTR panelDescription,
    int himagelist,
    BSTR panelIcon,
    BSTR panelCategory,
    BSTR categoryIcon,
    BSTR panelFiles,
    BSTR panelCanvas,
    int panelFlags,
    int pluginCookie);


void __RPC_STUB ISidebar_RegisterPanel2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_CreateXml_Proxy( 
    ISidebar * This,
    BSTR rootTag,
    /* [retval][out] */ IXmlBuilder **retVal);


void __RPC_STUB ISidebar_CreateXml_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_SaveXml_Proxy( 
    ISidebar * This,
    IXmlBuilder *xml,
    BSTR filePath,
    /* [out] */ BSTR *errorMsg);


void __RPC_STUB ISidebar_SaveXml_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_DownloadFile_Proxy( 
    ISidebar * This,
    BSTR filePath,
    BSTR url,
    VARIANT_BOOL reload,
    /* [retval][out] */ BSTR *__MIDL_0011);


void __RPC_STUB ISidebar_DownloadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_MsgBox_Proxy( 
    ISidebar * This,
    BSTR text,
    /* [optional][in] */ VARIANT caption,
    /* [optional][in] */ VARIANT flags,
    /* [retval][out] */ int *retVal);


void __RPC_STUB ISidebar_MsgBox_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_RegisterCmdLineExtension_Proxy( 
    ISidebar * This,
    BSTR identifier,
    BSTR prefix,
    BSTR caption,
    BSTR category,
    BSTR description,
    IXmlNode *forms,
    int pluginCookie);


void __RPC_STUB ISidebar_RegisterCmdLineExtension_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetInstallDir_Proxy( 
    ISidebar * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB ISidebar_GetInstallDir_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_Trace_Proxy( 
    ISidebar * This,
    BSTR text);


void __RPC_STUB ISidebar_Trace_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_OpenRSS_Proxy( 
    ISidebar * This,
    BSTR filePath,
    /* [out] */ BSTR *errorMsg,
    /* [retval][out] */ IRSSFeed **retVal);


void __RPC_STUB ISidebar_OpenRSS_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetPlugin_Proxy( 
    ISidebar * This,
    int pluginCookie,
    /* [retval][out] */ IUnknown **retVal);


void __RPC_STUB ISidebar_GetPlugin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetPlugin2_Proxy( 
    ISidebar * This,
    BSTR pluginName,
    /* [retval][out] */ IUnknown **retVal);


void __RPC_STUB ISidebar_GetPlugin2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebar_GetPluginsCount_Proxy( 
    ISidebar * This,
    /* [retval][out] */ int *retVal);


void __RPC_STUB ISidebar_GetPluginsCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISidebar_INTERFACE_DEFINED__ */


#ifndef __ISidebarWindow_INTERFACE_DEFINED__
#define __ISidebarWindow_INTERFACE_DEFINED__

/* interface ISidebarWindow */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISidebarWindow;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("56C3A2BC-02A7-447f-B985-EE06A32EA4D9")
    ISidebarWindow : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ HWND *hwnd) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISidebarWindowVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISidebarWindow * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISidebarWindow * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISidebarWindow * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISidebarWindow * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISidebarWindow * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISidebarWindow * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISidebarWindow * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ISidebarWindow * This,
            /* [retval][out] */ HWND *hwnd);
        
        END_INTERFACE
    } ISidebarWindowVtbl;

    interface ISidebarWindow
    {
        CONST_VTBL struct ISidebarWindowVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISidebarWindow_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISidebarWindow_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISidebarWindow_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISidebarWindow_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISidebarWindow_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISidebarWindow_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISidebarWindow_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISidebarWindow_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ISidebarWindow_GetHwnd_Proxy( 
    ISidebarWindow * This,
    /* [retval][out] */ HWND *hwnd);


void __RPC_STUB ISidebarWindow_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISidebarWindow_INTERFACE_DEFINED__ */


#ifndef __IPanelParent_INTERFACE_DEFINED__
#define __IPanelParent_INTERFACE_DEFINED__

/* interface IPanelParent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelParent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("530C544E-AAEA-4e50-B3C9-7521244C15B2")
    IPanelParent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ActivatePanel( 
            int panelCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCaption( 
            int panelCookie,
            BSTR caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawBackground( 
            IGraphics *graphics,
            int panelCookie,
            const RECT *rc) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawPanelBackground( 
            IGraphics *graphics,
            int panelCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DrawControlBackground( 
            IGraphics *graphics,
            int panelCookie,
            int hwndControl) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ArrangePanels( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InvalidatePanel( 
            int hwnd,
            const RECT *rc,
            VARIANT_BOOL bErase) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelParentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelParent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelParent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelParent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelParent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelParent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelParent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *ActivatePanel )( 
            IPanelParent * This,
            int panelCookie);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IPanelParent * This,
            int panelCookie,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *DrawBackground )( 
            IPanelParent * This,
            IGraphics *graphics,
            int panelCookie,
            const RECT *rc);
        
        HRESULT ( STDMETHODCALLTYPE *DrawPanelBackground )( 
            IPanelParent * This,
            IGraphics *graphics,
            int panelCookie);
        
        HRESULT ( STDMETHODCALLTYPE *DrawControlBackground )( 
            IPanelParent * This,
            IGraphics *graphics,
            int panelCookie,
            int hwndControl);
        
        HRESULT ( STDMETHODCALLTYPE *ArrangePanels )( 
            IPanelParent * This);
        
        HRESULT ( STDMETHODCALLTYPE *InvalidatePanel )( 
            IPanelParent * This,
            int hwnd,
            const RECT *rc,
            VARIANT_BOOL bErase);
        
        END_INTERFACE
    } IPanelParentVtbl;

    interface IPanelParent
    {
        CONST_VTBL struct IPanelParentVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelParent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelParent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelParent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelParent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelParent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelParent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelParent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelParent_ActivatePanel(This,panelCookie)	\
    (This)->lpVtbl -> ActivatePanel(This,panelCookie)

#define IPanelParent_SetCaption(This,panelCookie,caption)	\
    (This)->lpVtbl -> SetCaption(This,panelCookie,caption)

#define IPanelParent_DrawBackground(This,graphics,panelCookie,rc)	\
    (This)->lpVtbl -> DrawBackground(This,graphics,panelCookie,rc)

#define IPanelParent_DrawPanelBackground(This,graphics,panelCookie)	\
    (This)->lpVtbl -> DrawPanelBackground(This,graphics,panelCookie)

#define IPanelParent_DrawControlBackground(This,graphics,panelCookie,hwndControl)	\
    (This)->lpVtbl -> DrawControlBackground(This,graphics,panelCookie,hwndControl)

#define IPanelParent_ArrangePanels(This)	\
    (This)->lpVtbl -> ArrangePanels(This)

#define IPanelParent_InvalidatePanel(This,hwnd,rc,bErase)	\
    (This)->lpVtbl -> InvalidatePanel(This,hwnd,rc,bErase)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelParent_ActivatePanel_Proxy( 
    IPanelParent * This,
    int panelCookie);


void __RPC_STUB IPanelParent_ActivatePanel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_SetCaption_Proxy( 
    IPanelParent * This,
    int panelCookie,
    BSTR caption);


void __RPC_STUB IPanelParent_SetCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_DrawBackground_Proxy( 
    IPanelParent * This,
    IGraphics *graphics,
    int panelCookie,
    const RECT *rc);


void __RPC_STUB IPanelParent_DrawBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_DrawPanelBackground_Proxy( 
    IPanelParent * This,
    IGraphics *graphics,
    int panelCookie);


void __RPC_STUB IPanelParent_DrawPanelBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_DrawControlBackground_Proxy( 
    IPanelParent * This,
    IGraphics *graphics,
    int panelCookie,
    int hwndControl);


void __RPC_STUB IPanelParent_DrawControlBackground_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_ArrangePanels_Proxy( 
    IPanelParent * This);


void __RPC_STUB IPanelParent_ArrangePanels_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelParent_InvalidatePanel_Proxy( 
    IPanelParent * This,
    int hwnd,
    const RECT *rc,
    VARIANT_BOOL bErase);


void __RPC_STUB IPanelParent_InvalidatePanel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelParent_INTERFACE_DEFINED__ */


#ifndef __IPanelConfig_INTERFACE_DEFINED__
#define __IPanelConfig_INTERFACE_DEFINED__

/* interface IPanelConfig */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelConfig;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0F6E4D48-FEA9-41d5-81C5-FA07CBA56E1A")
    IPanelConfig : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE AutoFit( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetAutoFit( 
            VARIANT_BOOL autofit) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDetailsSize( 
            /* [retval][out] */ SIZE *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetDetailsSize( 
            SIZE retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AutoStretch( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetAutoStretch( 
            VARIANT_BOOL autostretch) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsExpanded( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Expand( 
            VARIANT_BOOL expand) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHeight( 
            /* [retval][out] */ int *height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetHeight( 
            int height) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowCaption( 
            VARIANT_BOOL caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsCaptionVisible( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NeedUpdate( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetConfigRoot( 
            /* [retval][out] */ IXmlNode **node) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsUndocked( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetUndocked( 
            VARIANT_BOOL undocked) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SupportsOffScreen( 
            /* [retval][out] */ VARIANT_BOOL *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Load( 
            IXmlNode *settings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Save( 
            IXmlBuilder *settings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE InitSetting( 
            /* [in] */ BSTR name,
            /* [in] */ VARIANT default_value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSetting( 
            /* [in] */ BSTR name,
            /* [retval][out] */ VARIANT *value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSetting( 
            /* [in] */ BSTR name,
            /* [in] */ VARIANT value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddCustomValue( 
            /* [in] */ BSTR name,
            /* [in] */ BSTR value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCustomValues( 
            /* [in] */ BSTR name,
            /* [retval][out] */ BSTR *values) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ClearCustomValues( 
            /* [in] */ BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Copy( 
            /* [in] */ IPanelConfig *config) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LoadEx( 
            IXmlNode *settings,
            VARIANT_BOOL panelSettings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SaveEx( 
            IXmlBuilder *settings,
            VARIANT_BOOL panelSettings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCaption( 
            BSTR caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetCaption( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetConfigPath( 
            /* [retval][out] */ BSTR *retVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelConfigVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelConfig * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelConfig * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelConfig * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelConfig * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelConfig * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelConfig * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelConfig * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *AutoFit )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetAutoFit )( 
            IPanelConfig * This,
            VARIANT_BOOL autofit);
        
        HRESULT ( STDMETHODCALLTYPE *GetDetailsSize )( 
            IPanelConfig * This,
            /* [retval][out] */ SIZE *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetDetailsSize )( 
            IPanelConfig * This,
            SIZE retVal);
        
        HRESULT ( STDMETHODCALLTYPE *AutoStretch )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetAutoStretch )( 
            IPanelConfig * This,
            VARIANT_BOOL autostretch);
        
        HRESULT ( STDMETHODCALLTYPE *IsExpanded )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Expand )( 
            IPanelConfig * This,
            VARIANT_BOOL expand);
        
        HRESULT ( STDMETHODCALLTYPE *GetHeight )( 
            IPanelConfig * This,
            /* [retval][out] */ int *height);
        
        HRESULT ( STDMETHODCALLTYPE *SetHeight )( 
            IPanelConfig * This,
            int height);
        
        HRESULT ( STDMETHODCALLTYPE *ShowCaption )( 
            IPanelConfig * This,
            VARIANT_BOOL caption);
        
        HRESULT ( STDMETHODCALLTYPE *IsCaptionVisible )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *NeedUpdate )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetConfigRoot )( 
            IPanelConfig * This,
            /* [retval][out] */ IXmlNode **node);
        
        HRESULT ( STDMETHODCALLTYPE *IsUndocked )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetUndocked )( 
            IPanelConfig * This,
            VARIANT_BOOL undocked);
        
        HRESULT ( STDMETHODCALLTYPE *SupportsOffScreen )( 
            IPanelConfig * This,
            /* [retval][out] */ VARIANT_BOOL *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *Load )( 
            IPanelConfig * This,
            IXmlNode *settings);
        
        HRESULT ( STDMETHODCALLTYPE *Save )( 
            IPanelConfig * This,
            IXmlBuilder *settings);
        
        HRESULT ( STDMETHODCALLTYPE *InitSetting )( 
            IPanelConfig * This,
            /* [in] */ BSTR name,
            /* [in] */ VARIANT default_value);
        
        HRESULT ( STDMETHODCALLTYPE *GetSetting )( 
            IPanelConfig * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ VARIANT *value);
        
        HRESULT ( STDMETHODCALLTYPE *SetSetting )( 
            IPanelConfig * This,
            /* [in] */ BSTR name,
            /* [in] */ VARIANT value);
        
        HRESULT ( STDMETHODCALLTYPE *AddCustomValue )( 
            IPanelConfig * This,
            /* [in] */ BSTR name,
            /* [in] */ BSTR value);
        
        HRESULT ( STDMETHODCALLTYPE *GetCustomValues )( 
            IPanelConfig * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ BSTR *values);
        
        HRESULT ( STDMETHODCALLTYPE *ClearCustomValues )( 
            IPanelConfig * This,
            /* [in] */ BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE *Copy )( 
            IPanelConfig * This,
            /* [in] */ IPanelConfig *config);
        
        HRESULT ( STDMETHODCALLTYPE *LoadEx )( 
            IPanelConfig * This,
            IXmlNode *settings,
            VARIANT_BOOL panelSettings);
        
        HRESULT ( STDMETHODCALLTYPE *SaveEx )( 
            IPanelConfig * This,
            IXmlBuilder *settings,
            VARIANT_BOOL panelSettings);
        
        HRESULT ( STDMETHODCALLTYPE *SetCaption )( 
            IPanelConfig * This,
            BSTR caption);
        
        HRESULT ( STDMETHODCALLTYPE *GetCaption )( 
            IPanelConfig * This,
            /* [retval][out] */ BSTR *retVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetConfigPath )( 
            IPanelConfig * This,
            /* [retval][out] */ BSTR *retVal);
        
        END_INTERFACE
    } IPanelConfigVtbl;

    interface IPanelConfig
    {
        CONST_VTBL struct IPanelConfigVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelConfig_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelConfig_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelConfig_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelConfig_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelConfig_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelConfig_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelConfig_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelConfig_AutoFit(This,retVal)	\
    (This)->lpVtbl -> AutoFit(This,retVal)

#define IPanelConfig_SetAutoFit(This,autofit)	\
    (This)->lpVtbl -> SetAutoFit(This,autofit)

#define IPanelConfig_GetDetailsSize(This,retVal)	\
    (This)->lpVtbl -> GetDetailsSize(This,retVal)

#define IPanelConfig_SetDetailsSize(This,retVal)	\
    (This)->lpVtbl -> SetDetailsSize(This,retVal)

#define IPanelConfig_AutoStretch(This,retVal)	\
    (This)->lpVtbl -> AutoStretch(This,retVal)

#define IPanelConfig_SetAutoStretch(This,autostretch)	\
    (This)->lpVtbl -> SetAutoStretch(This,autostretch)

#define IPanelConfig_IsExpanded(This,retVal)	\
    (This)->lpVtbl -> IsExpanded(This,retVal)

#define IPanelConfig_Expand(This,expand)	\
    (This)->lpVtbl -> Expand(This,expand)

#define IPanelConfig_GetHeight(This,height)	\
    (This)->lpVtbl -> GetHeight(This,height)

#define IPanelConfig_SetHeight(This,height)	\
    (This)->lpVtbl -> SetHeight(This,height)

#define IPanelConfig_ShowCaption(This,caption)	\
    (This)->lpVtbl -> ShowCaption(This,caption)

#define IPanelConfig_IsCaptionVisible(This,retVal)	\
    (This)->lpVtbl -> IsCaptionVisible(This,retVal)

#define IPanelConfig_NeedUpdate(This,retVal)	\
    (This)->lpVtbl -> NeedUpdate(This,retVal)

#define IPanelConfig_GetConfigRoot(This,node)	\
    (This)->lpVtbl -> GetConfigRoot(This,node)

#define IPanelConfig_IsUndocked(This,retVal)	\
    (This)->lpVtbl -> IsUndocked(This,retVal)

#define IPanelConfig_SetUndocked(This,undocked)	\
    (This)->lpVtbl -> SetUndocked(This,undocked)

#define IPanelConfig_SupportsOffScreen(This,retVal)	\
    (This)->lpVtbl -> SupportsOffScreen(This,retVal)

#define IPanelConfig_Load(This,settings)	\
    (This)->lpVtbl -> Load(This,settings)

#define IPanelConfig_Save(This,settings)	\
    (This)->lpVtbl -> Save(This,settings)

#define IPanelConfig_InitSetting(This,name,default_value)	\
    (This)->lpVtbl -> InitSetting(This,name,default_value)

#define IPanelConfig_GetSetting(This,name,value)	\
    (This)->lpVtbl -> GetSetting(This,name,value)

#define IPanelConfig_SetSetting(This,name,value)	\
    (This)->lpVtbl -> SetSetting(This,name,value)

#define IPanelConfig_AddCustomValue(This,name,value)	\
    (This)->lpVtbl -> AddCustomValue(This,name,value)

#define IPanelConfig_GetCustomValues(This,name,values)	\
    (This)->lpVtbl -> GetCustomValues(This,name,values)

#define IPanelConfig_ClearCustomValues(This,name)	\
    (This)->lpVtbl -> ClearCustomValues(This,name)

#define IPanelConfig_Copy(This,config)	\
    (This)->lpVtbl -> Copy(This,config)

#define IPanelConfig_LoadEx(This,settings,panelSettings)	\
    (This)->lpVtbl -> LoadEx(This,settings,panelSettings)

#define IPanelConfig_SaveEx(This,settings,panelSettings)	\
    (This)->lpVtbl -> SaveEx(This,settings,panelSettings)

#define IPanelConfig_SetCaption(This,caption)	\
    (This)->lpVtbl -> SetCaption(This,caption)

#define IPanelConfig_GetCaption(This,retVal)	\
    (This)->lpVtbl -> GetCaption(This,retVal)

#define IPanelConfig_GetConfigPath(This,retVal)	\
    (This)->lpVtbl -> GetConfigPath(This,retVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelConfig_AutoFit_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_AutoFit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetAutoFit_Proxy( 
    IPanelConfig * This,
    VARIANT_BOOL autofit);


void __RPC_STUB IPanelConfig_SetAutoFit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetDetailsSize_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ SIZE *retVal);


void __RPC_STUB IPanelConfig_GetDetailsSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetDetailsSize_Proxy( 
    IPanelConfig * This,
    SIZE retVal);


void __RPC_STUB IPanelConfig_SetDetailsSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_AutoStretch_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_AutoStretch_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetAutoStretch_Proxy( 
    IPanelConfig * This,
    VARIANT_BOOL autostretch);


void __RPC_STUB IPanelConfig_SetAutoStretch_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_IsExpanded_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_IsExpanded_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_Expand_Proxy( 
    IPanelConfig * This,
    VARIANT_BOOL expand);


void __RPC_STUB IPanelConfig_Expand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetHeight_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ int *height);


void __RPC_STUB IPanelConfig_GetHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetHeight_Proxy( 
    IPanelConfig * This,
    int height);


void __RPC_STUB IPanelConfig_SetHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_ShowCaption_Proxy( 
    IPanelConfig * This,
    VARIANT_BOOL caption);


void __RPC_STUB IPanelConfig_ShowCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_IsCaptionVisible_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_IsCaptionVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_NeedUpdate_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_NeedUpdate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetConfigRoot_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ IXmlNode **node);


void __RPC_STUB IPanelConfig_GetConfigRoot_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_IsUndocked_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_IsUndocked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetUndocked_Proxy( 
    IPanelConfig * This,
    VARIANT_BOOL undocked);


void __RPC_STUB IPanelConfig_SetUndocked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SupportsOffScreen_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ VARIANT_BOOL *retVal);


void __RPC_STUB IPanelConfig_SupportsOffScreen_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_Load_Proxy( 
    IPanelConfig * This,
    IXmlNode *settings);


void __RPC_STUB IPanelConfig_Load_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_Save_Proxy( 
    IPanelConfig * This,
    IXmlBuilder *settings);


void __RPC_STUB IPanelConfig_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_InitSetting_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name,
    /* [in] */ VARIANT default_value);


void __RPC_STUB IPanelConfig_InitSetting_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetSetting_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ VARIANT *value);


void __RPC_STUB IPanelConfig_GetSetting_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetSetting_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name,
    /* [in] */ VARIANT value);


void __RPC_STUB IPanelConfig_SetSetting_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_AddCustomValue_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name,
    /* [in] */ BSTR value);


void __RPC_STUB IPanelConfig_AddCustomValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetCustomValues_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ BSTR *values);


void __RPC_STUB IPanelConfig_GetCustomValues_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_ClearCustomValues_Proxy( 
    IPanelConfig * This,
    /* [in] */ BSTR name);


void __RPC_STUB IPanelConfig_ClearCustomValues_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_Copy_Proxy( 
    IPanelConfig * This,
    /* [in] */ IPanelConfig *config);


void __RPC_STUB IPanelConfig_Copy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_LoadEx_Proxy( 
    IPanelConfig * This,
    IXmlNode *settings,
    VARIANT_BOOL panelSettings);


void __RPC_STUB IPanelConfig_LoadEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SaveEx_Proxy( 
    IPanelConfig * This,
    IXmlBuilder *settings,
    VARIANT_BOOL panelSettings);


void __RPC_STUB IPanelConfig_SaveEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_SetCaption_Proxy( 
    IPanelConfig * This,
    BSTR caption);


void __RPC_STUB IPanelConfig_SetCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetCaption_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IPanelConfig_GetCaption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelConfig_GetConfigPath_Proxy( 
    IPanelConfig * This,
    /* [retval][out] */ BSTR *retVal);


void __RPC_STUB IPanelConfig_GetConfigPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelConfig_INTERFACE_DEFINED__ */


#ifndef __ICanvas_INTERFACE_DEFINED__
#define __ICanvas_INTERFACE_DEFINED__

/* interface ICanvas */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICanvas;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CEB71778-454B-4a1d-8786-182297354580")
    ICanvas : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            BSTR canvasName,
            BSTR panelName,
            ISidebar *sidebar,
            IPanelParent *panelParent,
            IPanelConfig *panelConfig,
            BSTR configPath,
            int cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Create( 
            HWND hwndParent) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Reload( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControl( 
            BSTR idctrl,
            /* [retval][out] */ IDispatch **ctrl) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetWindowRect( 
            /* [retval][out] */ RECT *rect) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ int *hwnd) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_visible( 
            /* [in] */ VARIANT_BOOL visible) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_visible( 
            /* [retval][out] */ VARIANT_BOOL *visible) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_x( 
            /* [in] */ int x) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_x( 
            /* [retval][out] */ int *x) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_y( 
            /* [in] */ int y) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_y( 
            /* [retval][out] */ int *y) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_height( 
            /* [in] */ int height) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_height( 
            /* [retval][out] */ int *height) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_width( 
            /* [in] */ int width) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_width( 
            /* [retval][out] */ int *width) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_opacity( 
            int opacity) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_opacity( 
            /* [retval][out] */ int *opacity) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICanvasVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICanvas * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICanvas * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICanvas * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICanvas * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICanvas * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICanvas * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICanvas * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ICanvas * This,
            BSTR canvasName,
            BSTR panelName,
            ISidebar *sidebar,
            IPanelParent *panelParent,
            IPanelConfig *panelConfig,
            BSTR configPath,
            int cookie);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            ICanvas * This,
            HWND hwndParent);
        
        HRESULT ( STDMETHODCALLTYPE *Reload )( 
            ICanvas * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetControl )( 
            ICanvas * This,
            BSTR idctrl,
            /* [retval][out] */ IDispatch **ctrl);
        
        HRESULT ( STDMETHODCALLTYPE *GetWindowRect )( 
            ICanvas * This,
            /* [retval][out] */ RECT *rect);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            ICanvas * This,
            /* [retval][out] */ int *hwnd);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_visible )( 
            ICanvas * This,
            /* [in] */ VARIANT_BOOL visible);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_visible )( 
            ICanvas * This,
            /* [retval][out] */ VARIANT_BOOL *visible);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_x )( 
            ICanvas * This,
            /* [in] */ int x);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_x )( 
            ICanvas * This,
            /* [retval][out] */ int *x);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_y )( 
            ICanvas * This,
            /* [in] */ int y);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_y )( 
            ICanvas * This,
            /* [retval][out] */ int *y);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_height )( 
            ICanvas * This,
            /* [in] */ int height);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_height )( 
            ICanvas * This,
            /* [retval][out] */ int *height);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_width )( 
            ICanvas * This,
            /* [in] */ int width);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_width )( 
            ICanvas * This,
            /* [retval][out] */ int *width);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_opacity )( 
            ICanvas * This,
            int opacity);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_opacity )( 
            ICanvas * This,
            /* [retval][out] */ int *opacity);
        
        END_INTERFACE
    } ICanvasVtbl;

    interface ICanvas
    {
        CONST_VTBL struct ICanvasVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICanvas_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICanvas_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICanvas_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICanvas_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICanvas_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICanvas_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICanvas_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICanvas_Init(This,canvasName,panelName,sidebar,panelParent,panelConfig,configPath,cookie)	\
    (This)->lpVtbl -> Init(This,canvasName,panelName,sidebar,panelParent,panelConfig,configPath,cookie)

#define ICanvas_Create(This,hwndParent)	\
    (This)->lpVtbl -> Create(This,hwndParent)

#define ICanvas_Reload(This)	\
    (This)->lpVtbl -> Reload(This)

#define ICanvas_GetControl(This,idctrl,ctrl)	\
    (This)->lpVtbl -> GetControl(This,idctrl,ctrl)

#define ICanvas_GetWindowRect(This,rect)	\
    (This)->lpVtbl -> GetWindowRect(This,rect)

#define ICanvas_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define ICanvas_put_visible(This,visible)	\
    (This)->lpVtbl -> put_visible(This,visible)

#define ICanvas_get_visible(This,visible)	\
    (This)->lpVtbl -> get_visible(This,visible)

#define ICanvas_put_x(This,x)	\
    (This)->lpVtbl -> put_x(This,x)

#define ICanvas_get_x(This,x)	\
    (This)->lpVtbl -> get_x(This,x)

#define ICanvas_put_y(This,y)	\
    (This)->lpVtbl -> put_y(This,y)

#define ICanvas_get_y(This,y)	\
    (This)->lpVtbl -> get_y(This,y)

#define ICanvas_put_height(This,height)	\
    (This)->lpVtbl -> put_height(This,height)

#define ICanvas_get_height(This,height)	\
    (This)->lpVtbl -> get_height(This,height)

#define ICanvas_put_width(This,width)	\
    (This)->lpVtbl -> put_width(This,width)

#define ICanvas_get_width(This,width)	\
    (This)->lpVtbl -> get_width(This,width)

#define ICanvas_put_opacity(This,opacity)	\
    (This)->lpVtbl -> put_opacity(This,opacity)

#define ICanvas_get_opacity(This,opacity)	\
    (This)->lpVtbl -> get_opacity(This,opacity)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICanvas_Init_Proxy( 
    ICanvas * This,
    BSTR canvasName,
    BSTR panelName,
    ISidebar *sidebar,
    IPanelParent *panelParent,
    IPanelConfig *panelConfig,
    BSTR configPath,
    int cookie);


void __RPC_STUB ICanvas_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICanvas_Create_Proxy( 
    ICanvas * This,
    HWND hwndParent);


void __RPC_STUB ICanvas_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICanvas_Reload_Proxy( 
    ICanvas * This);


void __RPC_STUB ICanvas_Reload_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICanvas_GetControl_Proxy( 
    ICanvas * This,
    BSTR idctrl,
    /* [retval][out] */ IDispatch **ctrl);


void __RPC_STUB ICanvas_GetControl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICanvas_GetWindowRect_Proxy( 
    ICanvas * This,
    /* [retval][out] */ RECT *rect);


void __RPC_STUB ICanvas_GetWindowRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICanvas_GetHwnd_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *hwnd);


void __RPC_STUB ICanvas_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_visible_Proxy( 
    ICanvas * This,
    /* [in] */ VARIANT_BOOL visible);


void __RPC_STUB ICanvas_put_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_visible_Proxy( 
    ICanvas * This,
    /* [retval][out] */ VARIANT_BOOL *visible);


void __RPC_STUB ICanvas_get_visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_x_Proxy( 
    ICanvas * This,
    /* [in] */ int x);


void __RPC_STUB ICanvas_put_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_x_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *x);


void __RPC_STUB ICanvas_get_x_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_y_Proxy( 
    ICanvas * This,
    /* [in] */ int y);


void __RPC_STUB ICanvas_put_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_y_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *y);


void __RPC_STUB ICanvas_get_y_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_height_Proxy( 
    ICanvas * This,
    /* [in] */ int height);


void __RPC_STUB ICanvas_put_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_height_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *height);


void __RPC_STUB ICanvas_get_height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_width_Proxy( 
    ICanvas * This,
    /* [in] */ int width);


void __RPC_STUB ICanvas_put_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_width_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *width);


void __RPC_STUB ICanvas_get_width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_opacity_Proxy( 
    ICanvas * This,
    int opacity);


void __RPC_STUB ICanvas_put_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_opacity_Proxy( 
    ICanvas * This,
    /* [retval][out] */ int *opacity);


void __RPC_STUB ICanvas_get_opacity_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICanvas_INTERFACE_DEFINED__ */


#ifndef __ISidebarSite_INTERFACE_DEFINED__
#define __ISidebarSite_INTERFACE_DEFINED__

/* interface ISidebarSite */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISidebarSite;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("92A4E8F6-9468-4a00-856E-4D6A34A466F4")
    ISidebarSite : public IDispatch
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_sidebar( 
            /* [retval][out] */ ISidebar **sidebar) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_config( 
            /* [retval][out] */ IPanelConfig **configuration) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_canvas( 
            /* [retval][out] */ ICanvas **canvas) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_parent( 
            /* [retval][out] */ IPanelParent **parent) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_cookie( 
            /* [retval][out] */ int *cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetControl( 
            BSTR idctrl,
            /* [retval][out] */ IDispatch **ctrl) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTimer( 
            /* [in] */ BSTR routine,
            /* [in] */ int interval,
            /* [optional][in] */ VARIANT obj) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE StopTimer( 
            /* [optional][in] */ VARIANT param) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DownloadFile( 
            BSTR filePath,
            BSTR url,
            BSTR routine,
            /* [optional][in] */ VARIANT obj) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShowAlert( 
            BSTR caption,
            BSTR routine,
            /* [optional][in] */ VARIANT obj) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DebugBreak( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISidebarSiteVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISidebarSite * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISidebarSite * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISidebarSite * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISidebarSite * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISidebarSite * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISidebarSite * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISidebarSite * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_sidebar )( 
            ISidebarSite * This,
            /* [retval][out] */ ISidebar **sidebar);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_config )( 
            ISidebarSite * This,
            /* [retval][out] */ IPanelConfig **configuration);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_canvas )( 
            ISidebarSite * This,
            /* [retval][out] */ ICanvas **canvas);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_parent )( 
            ISidebarSite * This,
            /* [retval][out] */ IPanelParent **parent);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_cookie )( 
            ISidebarSite * This,
            /* [retval][out] */ int *cookie);
        
        HRESULT ( STDMETHODCALLTYPE *GetControl )( 
            ISidebarSite * This,
            BSTR idctrl,
            /* [retval][out] */ IDispatch **ctrl);
        
        HRESULT ( STDMETHODCALLTYPE *SetTimer )( 
            ISidebarSite * This,
            /* [in] */ BSTR routine,
            /* [in] */ int interval,
            /* [optional][in] */ VARIANT obj);
        
        HRESULT ( STDMETHODCALLTYPE *StopTimer )( 
            ISidebarSite * This,
            /* [optional][in] */ VARIANT param);
        
        HRESULT ( STDMETHODCALLTYPE *DownloadFile )( 
            ISidebarSite * This,
            BSTR filePath,
            BSTR url,
            BSTR routine,
            /* [optional][in] */ VARIANT obj);
        
        HRESULT ( STDMETHODCALLTYPE *ShowAlert )( 
            ISidebarSite * This,
            BSTR caption,
            BSTR routine,
            /* [optional][in] */ VARIANT obj);
        
        HRESULT ( STDMETHODCALLTYPE *DebugBreak )( 
            ISidebarSite * This);
        
        END_INTERFACE
    } ISidebarSiteVtbl;

    interface ISidebarSite
    {
        CONST_VTBL struct ISidebarSiteVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISidebarSite_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISidebarSite_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISidebarSite_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISidebarSite_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISidebarSite_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISidebarSite_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISidebarSite_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISidebarSite_get_sidebar(This,sidebar)	\
    (This)->lpVtbl -> get_sidebar(This,sidebar)

#define ISidebarSite_get_config(This,configuration)	\
    (This)->lpVtbl -> get_config(This,configuration)

#define ISidebarSite_get_canvas(This,canvas)	\
    (This)->lpVtbl -> get_canvas(This,canvas)

#define ISidebarSite_get_parent(This,parent)	\
    (This)->lpVtbl -> get_parent(This,parent)

#define ISidebarSite_get_cookie(This,cookie)	\
    (This)->lpVtbl -> get_cookie(This,cookie)

#define ISidebarSite_GetControl(This,idctrl,ctrl)	\
    (This)->lpVtbl -> GetControl(This,idctrl,ctrl)

#define ISidebarSite_SetTimer(This,routine,interval,obj)	\
    (This)->lpVtbl -> SetTimer(This,routine,interval,obj)

#define ISidebarSite_StopTimer(This,param)	\
    (This)->lpVtbl -> StopTimer(This,param)

#define ISidebarSite_DownloadFile(This,filePath,url,routine,obj)	\
    (This)->lpVtbl -> DownloadFile(This,filePath,url,routine,obj)

#define ISidebarSite_ShowAlert(This,caption,routine,obj)	\
    (This)->lpVtbl -> ShowAlert(This,caption,routine,obj)

#define ISidebarSite_DebugBreak(This)	\
    (This)->lpVtbl -> DebugBreak(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISidebarSite_get_sidebar_Proxy( 
    ISidebarSite * This,
    /* [retval][out] */ ISidebar **sidebar);


void __RPC_STUB ISidebarSite_get_sidebar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISidebarSite_get_config_Proxy( 
    ISidebarSite * This,
    /* [retval][out] */ IPanelConfig **configuration);


void __RPC_STUB ISidebarSite_get_config_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISidebarSite_get_canvas_Proxy( 
    ISidebarSite * This,
    /* [retval][out] */ ICanvas **canvas);


void __RPC_STUB ISidebarSite_get_canvas_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISidebarSite_get_parent_Proxy( 
    ISidebarSite * This,
    /* [retval][out] */ IPanelParent **parent);


void __RPC_STUB ISidebarSite_get_parent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE ISidebarSite_get_cookie_Proxy( 
    ISidebarSite * This,
    /* [retval][out] */ int *cookie);


void __RPC_STUB ISidebarSite_get_cookie_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_GetControl_Proxy( 
    ISidebarSite * This,
    BSTR idctrl,
    /* [retval][out] */ IDispatch **ctrl);


void __RPC_STUB ISidebarSite_GetControl_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_SetTimer_Proxy( 
    ISidebarSite * This,
    /* [in] */ BSTR routine,
    /* [in] */ int interval,
    /* [optional][in] */ VARIANT obj);


void __RPC_STUB ISidebarSite_SetTimer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_StopTimer_Proxy( 
    ISidebarSite * This,
    /* [optional][in] */ VARIANT param);


void __RPC_STUB ISidebarSite_StopTimer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_DownloadFile_Proxy( 
    ISidebarSite * This,
    BSTR filePath,
    BSTR url,
    BSTR routine,
    /* [optional][in] */ VARIANT obj);


void __RPC_STUB ISidebarSite_DownloadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_ShowAlert_Proxy( 
    ISidebarSite * This,
    BSTR caption,
    BSTR routine,
    /* [optional][in] */ VARIANT obj);


void __RPC_STUB ISidebarSite_ShowAlert_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISidebarSite_DebugBreak_Proxy( 
    ISidebarSite * This);


void __RPC_STUB ISidebarSite_DebugBreak_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISidebarSite_INTERFACE_DEFINED__ */


#ifndef __IPanelContextMenu_INTERFACE_DEFINED__
#define __IPanelContextMenu_INTERFACE_DEFINED__

/* interface IPanelContextMenu */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelContextMenu;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AFDAB0BD-DB1B-462f-A7B3-9A941B8C9DA4")
    IPanelContextMenu : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetContextMenu( 
            POINT pt,
            /* [retval][out] */ HMENU *menu) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelContextMenuVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelContextMenu * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelContextMenu * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelContextMenu * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelContextMenu * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelContextMenu * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelContextMenu * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelContextMenu * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetContextMenu )( 
            IPanelContextMenu * This,
            POINT pt,
            /* [retval][out] */ HMENU *menu);
        
        END_INTERFACE
    } IPanelContextMenuVtbl;

    interface IPanelContextMenu
    {
        CONST_VTBL struct IPanelContextMenuVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelContextMenu_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelContextMenu_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelContextMenu_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelContextMenu_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelContextMenu_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelContextMenu_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelContextMenu_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelContextMenu_GetContextMenu(This,pt,menu)	\
    (This)->lpVtbl -> GetContextMenu(This,pt,menu)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelContextMenu_GetContextMenu_Proxy( 
    IPanelContextMenu * This,
    POINT pt,
    /* [retval][out] */ HMENU *menu);


void __RPC_STUB IPanelContextMenu_GetContextMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelContextMenu_INTERFACE_DEFINED__ */


#ifndef __IPanelProperties_INTERFACE_DEFINED__
#define __IPanelProperties_INTERFACE_DEFINED__

/* interface IPanelProperties */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelProperties;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("BE3396F9-EA15-41cb-8E93-66037B4DF602")
    IPanelProperties : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ShowProperties( 
            int hwnd) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelPropertiesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelProperties * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelProperties * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelProperties * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelProperties * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelProperties * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelProperties * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelProperties * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *ShowProperties )( 
            IPanelProperties * This,
            int hwnd);
        
        END_INTERFACE
    } IPanelPropertiesVtbl;

    interface IPanelProperties
    {
        CONST_VTBL struct IPanelPropertiesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelProperties_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelProperties_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelProperties_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelProperties_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelProperties_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelProperties_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelProperties_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelProperties_ShowProperties(This,hwnd)	\
    (This)->lpVtbl -> ShowProperties(This,hwnd)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelProperties_ShowProperties_Proxy( 
    IPanelProperties * This,
    int hwnd);


void __RPC_STUB IPanelProperties_ShowProperties_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelProperties_INTERFACE_DEFINED__ */


#ifndef __IPanelFileHandler_INTERFACE_DEFINED__
#define __IPanelFileHandler_INTERFACE_DEFINED__

/* interface IPanelFileHandler */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelFileHandler;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8BB9B89E-C2B9-4b04-A974-98C911B14A0F")
    IPanelFileHandler : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE HandleFile( 
            BSTR file) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelFileHandlerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelFileHandler * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelFileHandler * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelFileHandler * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelFileHandler * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelFileHandler * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelFileHandler * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelFileHandler * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *HandleFile )( 
            IPanelFileHandler * This,
            BSTR file);
        
        END_INTERFACE
    } IPanelFileHandlerVtbl;

    interface IPanelFileHandler
    {
        CONST_VTBL struct IPanelFileHandlerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelFileHandler_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelFileHandler_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelFileHandler_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelFileHandler_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelFileHandler_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelFileHandler_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelFileHandler_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelFileHandler_HandleFile(This,file)	\
    (This)->lpVtbl -> HandleFile(This,file)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelFileHandler_HandleFile_Proxy( 
    IPanelFileHandler * This,
    BSTR file);


void __RPC_STUB IPanelFileHandler_HandleFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelFileHandler_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0319 */
/* [local] */ 


enum EPanelNotification
    {	SC_LANGUAGE	= 0x1,
	SC_SKIN	= 0x2,
	SC_TRANSPARENCY	= 0x4,
	SC_POPUPS	= 0x8,
	SC_SCRIPTS	= 0x10
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0319_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0319_v0_0_s_ifspec;

#ifndef __IPanelNotification_INTERFACE_DEFINED__
#define __IPanelNotification_INTERFACE_DEFINED__

/* interface IPanelNotification */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelNotification;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6B028BEF-2D5D-4a40-8290-8F7D1EDC3679")
    IPanelNotification : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE SettingsChanged( 
            int flags) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelNotificationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelNotification * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelNotification * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelNotification * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelNotification * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelNotification * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelNotification * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelNotification * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *SettingsChanged )( 
            IPanelNotification * This,
            int flags);
        
        END_INTERFACE
    } IPanelNotificationVtbl;

    interface IPanelNotification
    {
        CONST_VTBL struct IPanelNotificationVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelNotification_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelNotification_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelNotification_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelNotification_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelNotification_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelNotification_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelNotification_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelNotification_SettingsChanged(This,flags)	\
    (This)->lpVtbl -> SettingsChanged(This,flags)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelNotification_SettingsChanged_Proxy( 
    IPanelNotification * This,
    int flags);


void __RPC_STUB IPanelNotification_SettingsChanged_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelNotification_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0320 */
/* [local] */ 


enum EPanelEvent
    {	PE_REMOVED	= 0x1,
	PE_MOUSEHOVER	= 0x2,
	PE_MOUSELEAVE	= 0x3,
	PE_SIDEBARHIDDEN	= 0x4,
	PE_SIDEBARDISPLAYED	= 0x5,
	PE_UNDOCKED	= 0x6,
	PE_CANCLOSE	= 0x7,
	PE_TESTSKIN	= 0x8,
	PE_SIDEBARMOVED	= 0x9,
	PE_DETAILSDISPLAYED	= 0xa,
	PE_DETAILSCLOSED	= 0xb
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0320_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0320_v0_0_s_ifspec;

#ifndef __IPanelEvent_INTERFACE_DEFINED__
#define __IPanelEvent_INTERFACE_DEFINED__

/* interface IPanelEvent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("272CDFBA-82A3-4ec5-AE7A-9F05F1780DA7")
    IPanelEvent : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnPanelEvent( 
            int eventId,
            int flags) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelEvent * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelEvent * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelEvent * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelEvent * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelEvent * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelEvent * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelEvent * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *OnPanelEvent )( 
            IPanelEvent * This,
            int eventId,
            int flags);
        
        END_INTERFACE
    } IPanelEventVtbl;

    interface IPanelEvent
    {
        CONST_VTBL struct IPanelEventVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelEvent_OnPanelEvent(This,eventId,flags)	\
    (This)->lpVtbl -> OnPanelEvent(This,eventId,flags)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelEvent_OnPanelEvent_Proxy( 
    IPanelEvent * This,
    int eventId,
    int flags);


void __RPC_STUB IPanelEvent_OnPanelEvent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelEvent_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0321 */
/* [local] */ 


enum EPanelPolicy
    {	PP_ALLOW_MOVE	= 0x1,
	PP_ALLOW_COLLAPSE	= PP_ALLOW_MOVE + 1,
	PP_ALLOW_CHANGE_HEIGHT	= PP_ALLOW_COLLAPSE + 1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0321_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0321_v0_0_s_ifspec;

#ifndef __IPanelPolicy_INTERFACE_DEFINED__
#define __IPanelPolicy_INTERFACE_DEFINED__

/* interface IPanelPolicy */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelPolicy;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B63C51BF-C5CE-4863-AFC2-6ACDE419FD69")
    IPanelPolicy : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetPolicy( 
            int policy,
            /* [retval][out] */ VARIANT_BOOL *enabled) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelPolicyVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelPolicy * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelPolicy * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelPolicy * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelPolicy * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelPolicy * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelPolicy * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelPolicy * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetPolicy )( 
            IPanelPolicy * This,
            int policy,
            /* [retval][out] */ VARIANT_BOOL *enabled);
        
        END_INTERFACE
    } IPanelPolicyVtbl;

    interface IPanelPolicy
    {
        CONST_VTBL struct IPanelPolicyVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelPolicy_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelPolicy_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelPolicy_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelPolicy_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelPolicy_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelPolicy_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelPolicy_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelPolicy_GetPolicy(This,policy,enabled)	\
    (This)->lpVtbl -> GetPolicy(This,policy,enabled)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelPolicy_GetPolicy_Proxy( 
    IPanelPolicy * This,
    int policy,
    /* [retval][out] */ VARIANT_BOOL *enabled);


void __RPC_STUB IPanelPolicy_GetPolicy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelPolicy_INTERFACE_DEFINED__ */


#ifndef __IPanelWindow_INTERFACE_DEFINED__
#define __IPanelWindow_INTERFACE_DEFINED__

/* interface IPanelWindow */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelWindow;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("16BC2827-86A8-4ee3-8758-4223EED78D26")
    IPanelWindow : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetHwnd( 
            /* [retval][out] */ HWND *hwnd) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetFitHeight( 
            int width,
            /* [retval][out] */ int *height) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelWindowVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelWindow * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelWindow * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelWindow * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelWindow * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelWindow * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelWindow * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelWindow * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetHwnd )( 
            IPanelWindow * This,
            /* [retval][out] */ HWND *hwnd);
        
        HRESULT ( STDMETHODCALLTYPE *GetFitHeight )( 
            IPanelWindow * This,
            int width,
            /* [retval][out] */ int *height);
        
        END_INTERFACE
    } IPanelWindowVtbl;

    interface IPanelWindow
    {
        CONST_VTBL struct IPanelWindowVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelWindow_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelWindow_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelWindow_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelWindow_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelWindow_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelWindow_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelWindow_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelWindow_GetHwnd(This,hwnd)	\
    (This)->lpVtbl -> GetHwnd(This,hwnd)

#define IPanelWindow_GetFitHeight(This,width,height)	\
    (This)->lpVtbl -> GetFitHeight(This,width,height)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelWindow_GetHwnd_Proxy( 
    IPanelWindow * This,
    /* [retval][out] */ HWND *hwnd);


void __RPC_STUB IPanelWindow_GetHwnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanelWindow_GetFitHeight_Proxy( 
    IPanelWindow * This,
    int width,
    /* [retval][out] */ int *height);


void __RPC_STUB IPanelWindow_GetFitHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelWindow_INTERFACE_DEFINED__ */


#ifndef __IPanel_INTERFACE_DEFINED__
#define __IPanel_INTERFACE_DEFINED__

/* interface IPanel */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanel;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E1FC4C05-8CE9-4188-B929-203415B8D172")
    IPanel : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Create( 
            int hwndParent,
            ISidebar *sidebar,
            IPanelParent *parent,
            IPanelConfig *config,
            ICanvas *canvas,
            IXmlNode *configRoot,
            IXmlNode *panelConfig,
            IXmlNode *settingsRoot,
            IXmlNode *panelSettings,
            int cookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Save( 
            IXmlBuilder *panelItem,
            IXmlBuilder *settingsRoot) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Tick( 
            VARIANT_BOOL minute,
            /* [retval][out] */ VARIANT_BOOL *heightChanged) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanel * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanel * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanel * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanel * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanel * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanel * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanel * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Create )( 
            IPanel * This,
            int hwndParent,
            ISidebar *sidebar,
            IPanelParent *parent,
            IPanelConfig *config,
            ICanvas *canvas,
            IXmlNode *configRoot,
            IXmlNode *panelConfig,
            IXmlNode *settingsRoot,
            IXmlNode *panelSettings,
            int cookie);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            IPanel * This);
        
        HRESULT ( STDMETHODCALLTYPE *Save )( 
            IPanel * This,
            IXmlBuilder *panelItem,
            IXmlBuilder *settingsRoot);
        
        HRESULT ( STDMETHODCALLTYPE *Tick )( 
            IPanel * This,
            VARIANT_BOOL minute,
            /* [retval][out] */ VARIANT_BOOL *heightChanged);
        
        END_INTERFACE
    } IPanelVtbl;

    interface IPanel
    {
        CONST_VTBL struct IPanelVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanel_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanel_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanel_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanel_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanel_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanel_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanel_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanel_Create(This,hwndParent,sidebar,parent,config,canvas,configRoot,panelConfig,settingsRoot,panelSettings,cookie)	\
    (This)->lpVtbl -> Create(This,hwndParent,sidebar,parent,config,canvas,configRoot,panelConfig,settingsRoot,panelSettings,cookie)

#define IPanel_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IPanel_Save(This,panelItem,settingsRoot)	\
    (This)->lpVtbl -> Save(This,panelItem,settingsRoot)

#define IPanel_Tick(This,minute,heightChanged)	\
    (This)->lpVtbl -> Tick(This,minute,heightChanged)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanel_Create_Proxy( 
    IPanel * This,
    int hwndParent,
    ISidebar *sidebar,
    IPanelParent *parent,
    IPanelConfig *config,
    ICanvas *canvas,
    IXmlNode *configRoot,
    IXmlNode *panelConfig,
    IXmlNode *settingsRoot,
    IXmlNode *panelSettings,
    int cookie);


void __RPC_STUB IPanel_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanel_Close_Proxy( 
    IPanel * This);


void __RPC_STUB IPanel_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanel_Save_Proxy( 
    IPanel * This,
    IXmlBuilder *panelItem,
    IXmlBuilder *settingsRoot);


void __RPC_STUB IPanel_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPanel_Tick_Proxy( 
    IPanel * This,
    VARIANT_BOOL minute,
    /* [retval][out] */ VARIANT_BOOL *heightChanged);


void __RPC_STUB IPanel_Tick_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanel_INTERFACE_DEFINED__ */


#ifndef __IPerfmonTicket_INTERFACE_DEFINED__
#define __IPerfmonTicket_INTERFACE_DEFINED__

/* interface IPerfmonTicket */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPerfmonTicket;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("21A9063D-7AF8-4f15-8595-39D3085F4F52")
    IPerfmonTicket : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetMinimalSize( 
            /* [retval][out] */ SIZE *size) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPerfmonTicketVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPerfmonTicket * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPerfmonTicket * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPerfmonTicket * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPerfmonTicket * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPerfmonTicket * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPerfmonTicket * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPerfmonTicket * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetMinimalSize )( 
            IPerfmonTicket * This,
            /* [retval][out] */ SIZE *size);
        
        END_INTERFACE
    } IPerfmonTicketVtbl;

    interface IPerfmonTicket
    {
        CONST_VTBL struct IPerfmonTicketVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPerfmonTicket_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPerfmonTicket_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPerfmonTicket_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPerfmonTicket_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPerfmonTicket_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPerfmonTicket_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPerfmonTicket_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPerfmonTicket_GetMinimalSize(This,size)	\
    (This)->lpVtbl -> GetMinimalSize(This,size)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPerfmonTicket_GetMinimalSize_Proxy( 
    IPerfmonTicket * This,
    /* [retval][out] */ SIZE *size);


void __RPC_STUB IPerfmonTicket_GetMinimalSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPerfmonTicket_INTERFACE_DEFINED__ */


#ifndef __IPanelCreator_INTERFACE_DEFINED__
#define __IPanelCreator_INTERFACE_DEFINED__

/* interface IPanelCreator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelCreator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AD1577BD-164B-44e5-84CA-98324DDC2C40")
    IPanelCreator : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE CreatePanel( 
            IPanel **panel,
            BSTR panelClass) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelCreatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelCreator * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelCreator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelCreator * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelCreator * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelCreator * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelCreator * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelCreator * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *CreatePanel )( 
            IPanelCreator * This,
            IPanel **panel,
            BSTR panelClass);
        
        END_INTERFACE
    } IPanelCreatorVtbl;

    interface IPanelCreator
    {
        CONST_VTBL struct IPanelCreatorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelCreator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelCreator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelCreator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelCreator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelCreator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelCreator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelCreator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelCreator_CreatePanel(This,panel,panelClass)	\
    (This)->lpVtbl -> CreatePanel(This,panel,panelClass)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelCreator_CreatePanel_Proxy( 
    IPanelCreator * This,
    IPanel **panel,
    BSTR panelClass);


void __RPC_STUB IPanelCreator_CreatePanel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelCreator_INTERFACE_DEFINED__ */


#ifndef __IPanelCreatorEvents_INTERFACE_DEFINED__
#define __IPanelCreatorEvents_INTERFACE_DEFINED__

/* interface IPanelCreatorEvents */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPanelCreatorEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B6223221-29EE-4286-9A47-CC08E46A5EAF")
    IPanelCreatorEvents : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE PanelCreated( 
            IPanel *panel) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPanelCreatorEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPanelCreatorEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPanelCreatorEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPanelCreatorEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPanelCreatorEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPanelCreatorEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPanelCreatorEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPanelCreatorEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *PanelCreated )( 
            IPanelCreatorEvents * This,
            IPanel *panel);
        
        END_INTERFACE
    } IPanelCreatorEventsVtbl;

    interface IPanelCreatorEvents
    {
        CONST_VTBL struct IPanelCreatorEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPanelCreatorEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPanelCreatorEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPanelCreatorEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPanelCreatorEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPanelCreatorEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPanelCreatorEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPanelCreatorEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPanelCreatorEvents_PanelCreated(This,panel)	\
    (This)->lpVtbl -> PanelCreated(This,panel)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPanelCreatorEvents_PanelCreated_Proxy( 
    IPanelCreatorEvents * This,
    IPanel *panel);


void __RPC_STUB IPanelCreatorEvents_PanelCreated_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPanelCreatorEvents_INTERFACE_DEFINED__ */


#ifndef __IPlugin_INTERFACE_DEFINED__
#define __IPlugin_INTERFACE_DEFINED__

/* interface IPlugin */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPlugin;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5CDF749C-33B9-45f7-B80D-15E9B29D00E4")
    IPlugin : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Load( 
            /* [out] */ BSTR *author,
            /* [out] */ BSTR *authorEMail,
            /* [out] */ BSTR *description,
            /* [out] */ BSTR *website,
            int sidebarBuild,
            ISidebar *sidebar,
            IXmlNode *pluginConfig,
            int pluginCookie) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Unload( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnPluginLoaded( 
            BSTR plugin) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPluginVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPlugin * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPlugin * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPlugin * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPlugin * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPlugin * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPlugin * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPlugin * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Load )( 
            IPlugin * This,
            /* [out] */ BSTR *author,
            /* [out] */ BSTR *authorEMail,
            /* [out] */ BSTR *description,
            /* [out] */ BSTR *website,
            int sidebarBuild,
            ISidebar *sidebar,
            IXmlNode *pluginConfig,
            int pluginCookie);
        
        HRESULT ( STDMETHODCALLTYPE *Unload )( 
            IPlugin * This);
        
        HRESULT ( STDMETHODCALLTYPE *OnPluginLoaded )( 
            IPlugin * This,
            BSTR plugin);
        
        END_INTERFACE
    } IPluginVtbl;

    interface IPlugin
    {
        CONST_VTBL struct IPluginVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPlugin_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPlugin_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPlugin_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPlugin_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPlugin_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPlugin_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPlugin_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPlugin_Load(This,author,authorEMail,description,website,sidebarBuild,sidebar,pluginConfig,pluginCookie)	\
    (This)->lpVtbl -> Load(This,author,authorEMail,description,website,sidebarBuild,sidebar,pluginConfig,pluginCookie)

#define IPlugin_Unload(This)	\
    (This)->lpVtbl -> Unload(This)

#define IPlugin_OnPluginLoaded(This,plugin)	\
    (This)->lpVtbl -> OnPluginLoaded(This,plugin)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPlugin_Load_Proxy( 
    IPlugin * This,
    /* [out] */ BSTR *author,
    /* [out] */ BSTR *authorEMail,
    /* [out] */ BSTR *description,
    /* [out] */ BSTR *website,
    int sidebarBuild,
    ISidebar *sidebar,
    IXmlNode *pluginConfig,
    int pluginCookie);


void __RPC_STUB IPlugin_Load_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPlugin_Unload_Proxy( 
    IPlugin * This);


void __RPC_STUB IPlugin_Unload_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IPlugin_OnPluginLoaded_Proxy( 
    IPlugin * This,
    BSTR plugin);


void __RPC_STUB IPlugin_OnPluginLoaded_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPlugin_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_dsidebar_0328 */
/* [local] */ 


enum EPropSheetPage
    {	PSP_ABOUT	= 0x1
    } ;


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0328_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0328_v0_0_s_ifspec;

#ifndef __IPluginProperties_INTERFACE_DEFINED__
#define __IPluginProperties_INTERFACE_DEFINED__

/* interface IPluginProperties */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPluginProperties;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F3FE3755-9047-4b22-9382-805933C60C95")
    IPluginProperties : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ReplacePage( 
            enum EPropSheetPage pageId,
            /* [retval][out] */ int *hpage) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPluginPropertiesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPluginProperties * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPluginProperties * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPluginProperties * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPluginProperties * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPluginProperties * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPluginProperties * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPluginProperties * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *ReplacePage )( 
            IPluginProperties * This,
            enum EPropSheetPage pageId,
            /* [retval][out] */ int *hpage);
        
        END_INTERFACE
    } IPluginPropertiesVtbl;

    interface IPluginProperties
    {
        CONST_VTBL struct IPluginPropertiesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPluginProperties_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPluginProperties_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPluginProperties_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPluginProperties_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPluginProperties_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPluginProperties_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPluginProperties_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPluginProperties_ReplacePage(This,pageId,hpage)	\
    (This)->lpVtbl -> ReplacePage(This,pageId,hpage)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IPluginProperties_ReplacePage_Proxy( 
    IPluginProperties * This,
    enum EPropSheetPage pageId,
    /* [retval][out] */ int *hpage);


void __RPC_STUB IPluginProperties_ReplacePage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPluginProperties_INTERFACE_DEFINED__ */


#ifndef __IFormField_INTERFACE_DEFINED__
#define __IFormField_INTERFACE_DEFINED__

/* interface IFormField */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IFormField;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("EF9A3240-4D9C-4054-821B-F8F473DC9E6D")
    IFormField : public IDispatch
    {
    public:
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_value( 
            /* [in] */ BSTR val) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_value( 
            /* [retval][out] */ BSTR *val) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_name( 
            /* [retval][out] */ BSTR *val) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFormFieldVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFormField * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFormField * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFormField * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFormField * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFormField * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFormField * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFormField * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE *put_value )( 
            IFormField * This,
            /* [in] */ BSTR val);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_value )( 
            IFormField * This,
            /* [retval][out] */ BSTR *val);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE *get_name )( 
            IFormField * This,
            /* [retval][out] */ BSTR *val);
        
        END_INTERFACE
    } IFormFieldVtbl;

    interface IFormField
    {
        CONST_VTBL struct IFormFieldVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFormField_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IFormField_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IFormField_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IFormField_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IFormField_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IFormField_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IFormField_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IFormField_put_value(This,val)	\
    (This)->lpVtbl -> put_value(This,val)

#define IFormField_get_value(This,val)	\
    (This)->lpVtbl -> get_value(This,val)

#define IFormField_get_name(This,val)	\
    (This)->lpVtbl -> get_name(This,val)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propput] */ HRESULT STDMETHODCALLTYPE IFormField_put_value_Proxy( 
    IFormField * This,
    /* [in] */ BSTR val);


void __RPC_STUB IFormField_put_value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IFormField_get_value_Proxy( 
    IFormField * This,
    /* [retval][out] */ BSTR *val);


void __RPC_STUB IFormField_get_value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IFormField_get_name_Proxy( 
    IFormField * This,
    /* [retval][out] */ BSTR *val);


void __RPC_STUB IFormField_get_name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IFormField_INTERFACE_DEFINED__ */


#ifndef __IForm_INTERFACE_DEFINED__
#define __IForm_INTERFACE_DEFINED__

/* interface IForm */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IForm;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("97E22DE4-4191-423f-8BA6-025D9D109196")
    IForm : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetField( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IFormField **val) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetKey( 
            /* [retval][out] */ BSTR *name) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFormVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IForm * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IForm * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IForm * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IForm * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IForm * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IForm * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IForm * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *GetField )( 
            IForm * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IFormField **val);
        
        HRESULT ( STDMETHODCALLTYPE *GetKey )( 
            IForm * This,
            /* [retval][out] */ BSTR *name);
        
        END_INTERFACE
    } IFormVtbl;

    interface IForm
    {
        CONST_VTBL struct IFormVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IForm_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IForm_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IForm_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IForm_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IForm_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IForm_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IForm_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IForm_GetField(This,name,val)	\
    (This)->lpVtbl -> GetField(This,name,val)

#define IForm_GetKey(This,name)	\
    (This)->lpVtbl -> GetKey(This,name)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IForm_GetField_Proxy( 
    IForm * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IFormField **val);


void __RPC_STUB IForm_GetField_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IForm_GetKey_Proxy( 
    IForm * This,
    /* [retval][out] */ BSTR *name);


void __RPC_STUB IForm_GetKey_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IForm_INTERFACE_DEFINED__ */


#ifndef __ICmdLinePanel_INTERFACE_DEFINED__
#define __ICmdLinePanel_INTERFACE_DEFINED__

/* interface ICmdLinePanel */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICmdLinePanel;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("113178CA-FC7A-41cc-BF0A-41B2A0F841AF")
    ICmdLinePanel : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Msg( 
            /* [in] */ BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Log( 
            /* [in] */ BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetForm( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IForm **form) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SendForm( 
            /* [in] */ IForm *form) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ShellExecute( 
            /* [in] */ BSTR strDoc,
            /* [optional][in] */ VARIANT param) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DisplayText( 
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AppendText( 
            /* [in] */ BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DisplayHTML( 
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DisplayWebPage( 
            /* [in] */ BSTR url,
            /* [optional][in] */ VARIANT caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DisplayLink( 
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetText( 
            /* [in] */ BSTR text) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICmdLinePanelVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICmdLinePanel * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICmdLinePanel * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICmdLinePanel * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICmdLinePanel * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICmdLinePanel * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICmdLinePanel * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICmdLinePanel * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Msg )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *Log )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *GetForm )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IForm **form);
        
        HRESULT ( STDMETHODCALLTYPE *SendForm )( 
            ICmdLinePanel * This,
            /* [in] */ IForm *form);
        
        HRESULT ( STDMETHODCALLTYPE *ShellExecute )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR strDoc,
            /* [optional][in] */ VARIANT param);
        
        HRESULT ( STDMETHODCALLTYPE *DisplayText )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption);
        
        HRESULT ( STDMETHODCALLTYPE *AppendText )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *DisplayHTML )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption);
        
        HRESULT ( STDMETHODCALLTYPE *DisplayWebPage )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR url,
            /* [optional][in] */ VARIANT caption);
        
        HRESULT ( STDMETHODCALLTYPE *DisplayLink )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text,
            /* [optional][in] */ VARIANT caption);
        
        HRESULT ( STDMETHODCALLTYPE *SetText )( 
            ICmdLinePanel * This,
            /* [in] */ BSTR text);
        
        END_INTERFACE
    } ICmdLinePanelVtbl;

    interface ICmdLinePanel
    {
        CONST_VTBL struct ICmdLinePanelVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdLinePanel_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdLinePanel_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdLinePanel_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICmdLinePanel_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICmdLinePanel_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICmdLinePanel_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICmdLinePanel_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICmdLinePanel_Msg(This,text)	\
    (This)->lpVtbl -> Msg(This,text)

#define ICmdLinePanel_Log(This,text)	\
    (This)->lpVtbl -> Log(This,text)

#define ICmdLinePanel_GetForm(This,name,form)	\
    (This)->lpVtbl -> GetForm(This,name,form)

#define ICmdLinePanel_SendForm(This,form)	\
    (This)->lpVtbl -> SendForm(This,form)

#define ICmdLinePanel_ShellExecute(This,strDoc,param)	\
    (This)->lpVtbl -> ShellExecute(This,strDoc,param)

#define ICmdLinePanel_DisplayText(This,text,caption)	\
    (This)->lpVtbl -> DisplayText(This,text,caption)

#define ICmdLinePanel_AppendText(This,text)	\
    (This)->lpVtbl -> AppendText(This,text)

#define ICmdLinePanel_DisplayHTML(This,text,caption)	\
    (This)->lpVtbl -> DisplayHTML(This,text,caption)

#define ICmdLinePanel_DisplayWebPage(This,url,caption)	\
    (This)->lpVtbl -> DisplayWebPage(This,url,caption)

#define ICmdLinePanel_DisplayLink(This,text,caption)	\
    (This)->lpVtbl -> DisplayLink(This,text,caption)

#define ICmdLinePanel_SetText(This,text)	\
    (This)->lpVtbl -> SetText(This,text)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICmdLinePanel_Msg_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLinePanel_Msg_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_Log_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLinePanel_Log_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_GetForm_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IForm **form);


void __RPC_STUB ICmdLinePanel_GetForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_SendForm_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ IForm *form);


void __RPC_STUB ICmdLinePanel_SendForm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_ShellExecute_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR strDoc,
    /* [optional][in] */ VARIANT param);


void __RPC_STUB ICmdLinePanel_ShellExecute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_DisplayText_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text,
    /* [optional][in] */ VARIANT caption);


void __RPC_STUB ICmdLinePanel_DisplayText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_AppendText_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLinePanel_AppendText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_DisplayHTML_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text,
    /* [optional][in] */ VARIANT caption);


void __RPC_STUB ICmdLinePanel_DisplayHTML_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_DisplayWebPage_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR url,
    /* [optional][in] */ VARIANT caption);


void __RPC_STUB ICmdLinePanel_DisplayWebPage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_DisplayLink_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text,
    /* [optional][in] */ VARIANT caption);


void __RPC_STUB ICmdLinePanel_DisplayLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLinePanel_SetText_Proxy( 
    ICmdLinePanel * This,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLinePanel_SetText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICmdLinePanel_INTERFACE_DEFINED__ */


#ifndef __ICmdLineExecutor_INTERFACE_DEFINED__
#define __ICmdLineExecutor_INTERFACE_DEFINED__

/* interface ICmdLineExecutor */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICmdLineExecutor;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("606EEAB0-7C93-4d4a-81A6-2C875DEDFCC8")
    ICmdLineExecutor : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Execute( 
            ICmdLinePanel *panel) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICmdLineExecutorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICmdLineExecutor * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICmdLineExecutor * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICmdLineExecutor * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICmdLineExecutor * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICmdLineExecutor * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICmdLineExecutor * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICmdLineExecutor * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Execute )( 
            ICmdLineExecutor * This,
            ICmdLinePanel *panel);
        
        END_INTERFACE
    } ICmdLineExecutorVtbl;

    interface ICmdLineExecutor
    {
        CONST_VTBL struct ICmdLineExecutorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdLineExecutor_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdLineExecutor_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdLineExecutor_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICmdLineExecutor_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICmdLineExecutor_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICmdLineExecutor_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICmdLineExecutor_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICmdLineExecutor_Execute(This,panel)	\
    (This)->lpVtbl -> Execute(This,panel)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICmdLineExecutor_Execute_Proxy( 
    ICmdLineExecutor * This,
    ICmdLinePanel *panel);


void __RPC_STUB ICmdLineExecutor_Execute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICmdLineExecutor_INTERFACE_DEFINED__ */


#ifndef __ICmdLineSuggestion_INTERFACE_DEFINED__
#define __ICmdLineSuggestion_INTERFACE_DEFINED__

/* interface ICmdLineSuggestion */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICmdLineSuggestion;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("48FE3933-2265-46fb-8242-5D7F44B8AA91")
    ICmdLineSuggestion : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ BSTR caption,
            /* [in] */ BSTR cmdLine,
            VARIANT_BOOL select) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddEx( 
            /* [in] */ BSTR caption,
            /* [retval][out] */ int *index) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetSelect( 
            /* [in] */ int index,
            VARIANT_BOOL select) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIcon( 
            /* [in] */ int index,
            HICON icon) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetTooltip( 
            /* [in] */ int index,
            /* [in] */ BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetCommand( 
            /* [in] */ int index,
            /* [in] */ BSTR text) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetExecutor( 
            /* [in] */ int index,
            /* [in] */ ICmdLineExecutor *executor) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICmdLineSuggestionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICmdLineSuggestion * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICmdLineSuggestion * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICmdLineSuggestion * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICmdLineSuggestion * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICmdLineSuggestion * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICmdLineSuggestion * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICmdLineSuggestion * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Add )( 
            ICmdLineSuggestion * This,
            /* [in] */ BSTR caption,
            /* [in] */ BSTR cmdLine,
            VARIANT_BOOL select);
        
        HRESULT ( STDMETHODCALLTYPE *AddEx )( 
            ICmdLineSuggestion * This,
            /* [in] */ BSTR caption,
            /* [retval][out] */ int *index);
        
        HRESULT ( STDMETHODCALLTYPE *SetSelect )( 
            ICmdLineSuggestion * This,
            /* [in] */ int index,
            VARIANT_BOOL select);
        
        HRESULT ( STDMETHODCALLTYPE *SetIcon )( 
            ICmdLineSuggestion * This,
            /* [in] */ int index,
            HICON icon);
        
        HRESULT ( STDMETHODCALLTYPE *SetTooltip )( 
            ICmdLineSuggestion * This,
            /* [in] */ int index,
            /* [in] */ BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *SetCommand )( 
            ICmdLineSuggestion * This,
            /* [in] */ int index,
            /* [in] */ BSTR text);
        
        HRESULT ( STDMETHODCALLTYPE *SetExecutor )( 
            ICmdLineSuggestion * This,
            /* [in] */ int index,
            /* [in] */ ICmdLineExecutor *executor);
        
        END_INTERFACE
    } ICmdLineSuggestionVtbl;

    interface ICmdLineSuggestion
    {
        CONST_VTBL struct ICmdLineSuggestionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdLineSuggestion_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdLineSuggestion_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdLineSuggestion_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICmdLineSuggestion_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICmdLineSuggestion_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICmdLineSuggestion_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICmdLineSuggestion_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICmdLineSuggestion_Add(This,caption,cmdLine,select)	\
    (This)->lpVtbl -> Add(This,caption,cmdLine,select)

#define ICmdLineSuggestion_AddEx(This,caption,index)	\
    (This)->lpVtbl -> AddEx(This,caption,index)

#define ICmdLineSuggestion_SetSelect(This,index,select)	\
    (This)->lpVtbl -> SetSelect(This,index,select)

#define ICmdLineSuggestion_SetIcon(This,index,icon)	\
    (This)->lpVtbl -> SetIcon(This,index,icon)

#define ICmdLineSuggestion_SetTooltip(This,index,text)	\
    (This)->lpVtbl -> SetTooltip(This,index,text)

#define ICmdLineSuggestion_SetCommand(This,index,text)	\
    (This)->lpVtbl -> SetCommand(This,index,text)

#define ICmdLineSuggestion_SetExecutor(This,index,executor)	\
    (This)->lpVtbl -> SetExecutor(This,index,executor)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_Add_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ BSTR caption,
    /* [in] */ BSTR cmdLine,
    VARIANT_BOOL select);


void __RPC_STUB ICmdLineSuggestion_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_AddEx_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ BSTR caption,
    /* [retval][out] */ int *index);


void __RPC_STUB ICmdLineSuggestion_AddEx_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_SetSelect_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ int index,
    VARIANT_BOOL select);


void __RPC_STUB ICmdLineSuggestion_SetSelect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_SetIcon_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ int index,
    HICON icon);


void __RPC_STUB ICmdLineSuggestion_SetIcon_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_SetTooltip_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ int index,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLineSuggestion_SetTooltip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_SetCommand_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ int index,
    /* [in] */ BSTR text);


void __RPC_STUB ICmdLineSuggestion_SetCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineSuggestion_SetExecutor_Proxy( 
    ICmdLineSuggestion * This,
    /* [in] */ int index,
    /* [in] */ ICmdLineExecutor *executor);


void __RPC_STUB ICmdLineSuggestion_SetExecutor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICmdLineSuggestion_INTERFACE_DEFINED__ */


#ifndef __ICmdLineExtension_INTERFACE_DEFINED__
#define __ICmdLineExtension_INTERFACE_DEFINED__

/* interface ICmdLineExtension */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICmdLineExtension;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A70D3D4C-457A-487a-B8AC-680CA06B631A")
    ICmdLineExtension : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Init( 
            ISidebar *sidebar,
            IXmlNode *extSettings) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Save( 
            IXmlBuilder *extItem) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Execute( 
            ICmdLinePanel *panel,
            /* [in] */ BSTR cmdLine) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Match( 
            /* [in] */ BSTR cmdLine,
            /* [retval][out] */ VARIANT_BOOL *match) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Suggest( 
            ICmdLineSuggestion *fill,
            /* [in] */ BSTR prefix,
            /* [in] */ BSTR cmdLine) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICmdLineExtensionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICmdLineExtension * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICmdLineExtension * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICmdLineExtension * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICmdLineExtension * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICmdLineExtension * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICmdLineExtension * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICmdLineExtension * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *Init )( 
            ICmdLineExtension * This,
            ISidebar *sidebar,
            IXmlNode *extSettings);
        
        HRESULT ( STDMETHODCALLTYPE *Close )( 
            ICmdLineExtension * This);
        
        HRESULT ( STDMETHODCALLTYPE *Save )( 
            ICmdLineExtension * This,
            IXmlBuilder *extItem);
        
        HRESULT ( STDMETHODCALLTYPE *Execute )( 
            ICmdLineExtension * This,
            ICmdLinePanel *panel,
            /* [in] */ BSTR cmdLine);
        
        HRESULT ( STDMETHODCALLTYPE *Match )( 
            ICmdLineExtension * This,
            /* [in] */ BSTR cmdLine,
            /* [retval][out] */ VARIANT_BOOL *match);
        
        HRESULT ( STDMETHODCALLTYPE *Suggest )( 
            ICmdLineExtension * This,
            ICmdLineSuggestion *fill,
            /* [in] */ BSTR prefix,
            /* [in] */ BSTR cmdLine);
        
        END_INTERFACE
    } ICmdLineExtensionVtbl;

    interface ICmdLineExtension
    {
        CONST_VTBL struct ICmdLineExtensionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdLineExtension_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdLineExtension_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdLineExtension_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICmdLineExtension_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICmdLineExtension_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICmdLineExtension_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICmdLineExtension_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICmdLineExtension_Init(This,sidebar,extSettings)	\
    (This)->lpVtbl -> Init(This,sidebar,extSettings)

#define ICmdLineExtension_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define ICmdLineExtension_Save(This,extItem)	\
    (This)->lpVtbl -> Save(This,extItem)

#define ICmdLineExtension_Execute(This,panel,cmdLine)	\
    (This)->lpVtbl -> Execute(This,panel,cmdLine)

#define ICmdLineExtension_Match(This,cmdLine,match)	\
    (This)->lpVtbl -> Match(This,cmdLine,match)

#define ICmdLineExtension_Suggest(This,fill,prefix,cmdLine)	\
    (This)->lpVtbl -> Suggest(This,fill,prefix,cmdLine)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICmdLineExtension_Init_Proxy( 
    ICmdLineExtension * This,
    ISidebar *sidebar,
    IXmlNode *extSettings);


void __RPC_STUB ICmdLineExtension_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineExtension_Close_Proxy( 
    ICmdLineExtension * This);


void __RPC_STUB ICmdLineExtension_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineExtension_Save_Proxy( 
    ICmdLineExtension * This,
    IXmlBuilder *extItem);


void __RPC_STUB ICmdLineExtension_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineExtension_Execute_Proxy( 
    ICmdLineExtension * This,
    ICmdLinePanel *panel,
    /* [in] */ BSTR cmdLine);


void __RPC_STUB ICmdLineExtension_Execute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineExtension_Match_Proxy( 
    ICmdLineExtension * This,
    /* [in] */ BSTR cmdLine,
    /* [retval][out] */ VARIANT_BOOL *match);


void __RPC_STUB ICmdLineExtension_Match_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ICmdLineExtension_Suggest_Proxy( 
    ICmdLineExtension * This,
    ICmdLineSuggestion *fill,
    /* [in] */ BSTR prefix,
    /* [in] */ BSTR cmdLine);


void __RPC_STUB ICmdLineExtension_Suggest_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICmdLineExtension_INTERFACE_DEFINED__ */


#ifndef __ICmdLineExtCreator_INTERFACE_DEFINED__
#define __ICmdLineExtCreator_INTERFACE_DEFINED__

/* interface ICmdLineExtCreator */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICmdLineExtCreator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B48CBC46-66DD-4a8c-9121-12D16C43C697")
    ICmdLineExtCreator : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE CreateExtension( 
            BSTR identifier,
            /* [retval][out] */ ICmdLineExtension **panel) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICmdLineExtCreatorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICmdLineExtCreator * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICmdLineExtCreator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICmdLineExtCreator * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICmdLineExtCreator * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICmdLineExtCreator * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICmdLineExtCreator * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICmdLineExtCreator * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE *CreateExtension )( 
            ICmdLineExtCreator * This,
            BSTR identifier,
            /* [retval][out] */ ICmdLineExtension **panel);
        
        END_INTERFACE
    } ICmdLineExtCreatorVtbl;

    interface ICmdLineExtCreator
    {
        CONST_VTBL struct ICmdLineExtCreatorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdLineExtCreator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdLineExtCreator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdLineExtCreator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICmdLineExtCreator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICmdLineExtCreator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICmdLineExtCreator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICmdLineExtCreator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICmdLineExtCreator_CreateExtension(This,identifier,panel)	\
    (This)->lpVtbl -> CreateExtension(This,identifier,panel)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ICmdLineExtCreator_CreateExtension_Proxy( 
    ICmdLineExtCreator * This,
    BSTR identifier,
    /* [retval][out] */ ICmdLineExtension **panel);


void __RPC_STUB ICmdLineExtCreator_CreateExtension_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICmdLineExtCreator_INTERFACE_DEFINED__ */



#ifndef __DesktopSidebarLib_LIBRARY_DEFINED__
#define __DesktopSidebarLib_LIBRARY_DEFINED__

/* library DesktopSidebarLib */
/* [helpstring][version][uuid] */ 








































































EXTERN_C const IID LIBID_DesktopSidebarLib;

EXTERN_C const CLSID CLSID_Sidebar;

#ifdef __cplusplus

class DECLSPEC_UUID("C6989308-E794-4e97-A516-17F04BB03198")
Sidebar;
#endif
#endif /* __DesktopSidebarLib_LIBRARY_DEFINED__ */

/* interface __MIDL_itf_dsidebar_0336 */
/* [local] */ 

#pragma warning( default: 4430)


extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0336_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_dsidebar_0336_v0_0_s_ifspec;

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  HBITMAP_UserSize(     unsigned long *, unsigned long            , HBITMAP * ); 
unsigned char * __RPC_USER  HBITMAP_UserMarshal(  unsigned long *, unsigned char *, HBITMAP * ); 
unsigned char * __RPC_USER  HBITMAP_UserUnmarshal(unsigned long *, unsigned char *, HBITMAP * ); 
void                      __RPC_USER  HBITMAP_UserFree(     unsigned long *, HBITMAP * ); 

unsigned long             __RPC_USER  HICON_UserSize(     unsigned long *, unsigned long            , HICON * ); 
unsigned char * __RPC_USER  HICON_UserMarshal(  unsigned long *, unsigned char *, HICON * ); 
unsigned char * __RPC_USER  HICON_UserUnmarshal(unsigned long *, unsigned char *, HICON * ); 
void                      __RPC_USER  HICON_UserFree(     unsigned long *, HICON * ); 

unsigned long             __RPC_USER  HMENU_UserSize(     unsigned long *, unsigned long            , HMENU * ); 
unsigned char * __RPC_USER  HMENU_UserMarshal(  unsigned long *, unsigned char *, HMENU * ); 
unsigned char * __RPC_USER  HMENU_UserUnmarshal(unsigned long *, unsigned char *, HMENU * ); 
void                      __RPC_USER  HMENU_UserFree(     unsigned long *, HMENU * ); 

unsigned long             __RPC_USER  HWND_UserSize(     unsigned long *, unsigned long            , HWND * ); 
unsigned char * __RPC_USER  HWND_UserMarshal(  unsigned long *, unsigned char *, HWND * ); 
unsigned char * __RPC_USER  HWND_UserUnmarshal(unsigned long *, unsigned char *, HWND * ); 
void                      __RPC_USER  HWND_UserFree(     unsigned long *, HWND * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


