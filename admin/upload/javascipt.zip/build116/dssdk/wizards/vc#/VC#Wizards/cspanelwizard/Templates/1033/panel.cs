using System;
using System.Windows.Forms;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Runtime.InteropServices;
using DesktopSidebar;


namespace [! output SAFE_PROJECT_NAME]
{
    public class Panel : IPanel, IPanelWindow, ITextOutputParent 
    {
        IPanelParent m_panelParent;
        int m_panelCookie;

        ITextOutput m_output;

        public Panel()
        {
        }
    
        // IPanel implementation
        public void Create(
            int hwndParent, 
            Sidebar Sidebar, 
            IPanelParent parent, 
            IPanelConfig config, 
            ICanvas canvas,
            IXmlNode configRoot,
            IXmlNode panelConfig,
            IXmlNode settingsRoot,
            IXmlNode panelSettings,
            int cookie)
        {
            m_panelParent=parent;
            m_panelCookie=cookie;

            m_panelParent.SetCaption(m_panelCookie,"[! output SAFE_PROJECT_NAME] Caption");

            m_output=Sidebar.GetControlFactory().CreateTextOutput();
            m_output.Init(Sidebar.GetGlobalSettings(),Sidebar.GetSkinManager(),this,true);
            m_output.Create(hwndParent,true);
            m_output.SetText("This is [! output SAFE_PROJECT_NAME] ");
        }

        public System.IntPtr GetHwnd()
        {
            return (IntPtr)m_output.GetHwnd();
        }

        public int GetFitHeight(int width)
        {
            return m_output.GetFitHeight();
        }

        public void Close()
        {
            m_output.Close();
            m_output=null;
        }

        public bool Tick(bool minute)
        {
            return false;
        }

        public void Save(IXmlBuilder panelSettings, IXmlBuilder settingsRoot)
        {
        }

        
        // ITextOutputParent implementation
        public void OnClick(ITextOutput textOutput, bool dblclk)
        {
            MessageBox.Show("Hello!!!");
        }

        public void OnDrawBackground(ITextOutput textOutput, IGraphics graphics)
        {
            m_panelParent.DrawControlBackground(graphics,m_panelCookie,m_output.GetHwnd());
        }

        public void OnMouseLeave(ITextOutput textOutput)
        {
        }

        public void OnShowDetails(ITextOutput textOutput)
        {
        }

        public void OnMouseHover(ITextOutput textOutput)
        {
        }

    }
}
