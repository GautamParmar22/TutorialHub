using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using DesktopSidebar;

namespace [! output SAFE_PROJECT_NAME]
{
	public class Panel : System.Windows.Forms.UserControl,
		IPanel, IPanelWindow
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Panel()
		{
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Panel
			// 
			this.Name = "Panel";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);

		}
		#endregion


		IPanelParent m_panelParent;
		int m_panelCookie;
		Sidebar m_sidebar;

		#region Win32API Declarations

		[DllImport("user32.dll", EntryPoint="SetParent")]
		static extern int SetParent(int hwndChild, int hwndNewParent);

		#endregion
	
		#region IPanel Members

		public void Create(int hwndParent, Sidebar sidebar, IPanelParent parent, IPanelConfig config, ICanvas canvas, IXmlNode configRoot, IXmlNode panelConfig, IXmlNode settingsRoot, IXmlNode panelSettings, int cookie)
		{
			m_sidebar = sidebar;
			m_panelParent=parent;
			m_panelCookie=cookie;
			SetParent((int)Handle,hwndParent);
			m_panelParent.SetCaption(m_panelCookie,"[! output SAFE_PROJECT_NAME]");
			
			this.SetStyle(ControlStyles.DoubleBuffer, true);
			this.SetStyle(ControlStyles.AllPaintingInWmPaint, true); 
			
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		public void Close()
		{
		}

		public bool Tick(bool minute)
		{
			return false;
		}

		public void Save(IXmlBuilder panelItem, IXmlBuilder settingsRoot)
		{
		}

		#endregion
	
		#region IPanelWindow Members

		public int GetFitHeight(int width)
		{
			return Height;
		}

		public System.IntPtr GetHwnd()
		{
			return Handle;
		}

		#endregion

		private void Panel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			IntPtr hdc=e.Graphics.GetHdc();
			IGraphics graphics=m_sidebar.CreateGraphics((int)hdc);
			m_panelParent.DrawPanelBackground(graphics,m_panelCookie);
			e.Graphics.ReleaseHdc(hdc);
		}
	}
}
