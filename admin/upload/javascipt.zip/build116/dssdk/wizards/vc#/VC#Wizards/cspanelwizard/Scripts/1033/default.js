function GetDSInstallDir()
{
    var WshShell = new ActiveXObject("WScript.Shell");
    var installDir=WshShell.RegRead("HKCU\\Software\\Idea2\\Sidebar\\1.0\\installDir")
    return installDir;
}

function OnFinish(selProj, selObj)
{
    var oldSuppressUIValue = true;
	try
	{
        oldSuppressUIValue = dte.SuppressUI;
		var strProjectPath = wizard.FindSymbol('PROJECT_PATH');
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');
        var strSafeProjectName = CreateSafeName(strProjectName);
		wizard.AddSymbol("SAFE_PROJECT_NAME", strSafeProjectName);

		var proj = CreateCSharpProject(strProjectName, strProjectPath, "defaultDSP.csproj");
        AddReferences(proj);

        var InfFile = CreateInfFile();
		AddFilesToCSharpProject(proj, strProjectName, strProjectPath, InfFile, false);
		InfFile.Delete();

		proj.Save();
	}
	catch(e)
	{
		if (e.description.length != 0)
		    SetErrorInfo(e);
		return e.number
	}
    finally
    {
   		dte.SuppressUI = oldSuppressUIValue;
   		if( InfFile )
			InfFile.Delete();
    }
}

function AddReferences(oProj)
{
	var refmanager = GetCSharpReferenceManager(oProj);
	var bExpanded = IsReferencesNodeExpanded(oProj)
	refmanager.Add("System");
	refmanager.Add("System.Data");
	refmanager.Add("System.XML");
	refmanager.Add("System.Drawing");
	refmanager.Add("System.Windows.Forms");

    var fso = new ActiveXObject("Scripting.FileSystemObject");
    if (fso.FileExists(GetDSInstallDir()+"\\dssdk\\dsidebarpia.dll"))
    {
	    refmanager.Add(GetDSInstallDir()+"\\dssdk\\dsidebarpia.dll");
    }
	if(!bExpanded)
		CollapseReferencesNode(oProj);
}

function GetCSharpTargetName(strName, strProjectName)
{
	try
	{
		// TODO: set the name of the rendered file based on the template filename
		var strTarget = strName;

		if (strName == 'plugin.dsplugin')
			strTarget = wizard.FindSymbol("SAFE_PROJECT_NAME")+".dsplugin";

		return strTarget; 
	}
	catch(e)
	{
		throw e;
	}
}

function DoOpenFile(strName)
{
	var bOpen = false;
    
	switch (strName)
	{
		case "panel.cs":
			bOpen = true;
			break;
		case "plugin.cs":
			bOpen = true;
			break;
	}
	return bOpen; 
}

function SetFileProperties(oFileItem, strFileName)
{
    if(strFileName == "panel.cs" || strFileName == "plugin.cs" || strFileName == "assemblyinfo.cs")
    {
        oFileItem.Properties("SubType").Value = "Code";
    }
    if(strFileName == "icon.bmp")
    {
        oFileItem.Properties("BuildAction").Value = 3;
    }
}

