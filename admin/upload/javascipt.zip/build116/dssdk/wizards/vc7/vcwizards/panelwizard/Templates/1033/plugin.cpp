#include "stdafx.h"
#include "[! output PANEL_NAME].h"
#include "resource.h"

#include <sstream>

class CPlugin :
    public CComObjectRootEx<CComSingleThreadModel>,
    public IDispatchImpl<IPlugin, &IID_IPlugin, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelCreator, &IID_IPanelCreator, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{

public:

    BEGIN_COM_MAP(CPlugin)
        COM_INTERFACE_ENTRY_IID(IID_IPlugin,IPlugin)
        COM_INTERFACE_ENTRY_IID(IID_IPanelCreator,IPanelCreator)
    END_COM_MAP()

    STDMETHOD(Load)(
        BSTR* author,
        BSTR* authorEMail,
        BSTR* description,
        BSTR* homepage,
        int sidebarBuild,
        ISidebar* sidebar,
        IXmlNode* pluginConfig,
        int pluginCookie);
    STDMETHOD(Unload)();
    STDMETHOD(CreatePanel)(
        IPanel** panel,
        BSTR panelClass);

    STDMETHOD(OnPluginLoaded)(BSTR name);
};

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::OnPluginLoaded(BSTR name)
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::Load(
    BSTR* author,
    BSTR* authorEMail,
    BSTR* description,
    BSTR* homepage,
    int sidebarBuild,
    ISidebar* pSidebar,
    IXmlNode* pPluginConfig,
    int pluginCookie) 
{
    // TODO: Update these informations
    *author=SysAllocString(L"Your name");
    *authorEMail=SysAllocString(L"your@e-mail.adress.com");
    *description=SysAllocString(L"");
    *homepage=SysAllocString(L"www.yourwebsite.com");

    char szPath[_MAX_PATH];
    GetModuleFileName(_AtlBaseModule.GetResourceInstance(),szPath,sizeof(szPath));

    std::stringstream panelIcon;
    panelIcon<<szPath<<","<<IDB_ICONS<<",0";

    std::stringstream categoryIcon;
    categoryIcon<<szPath<<","<<IDB_ICONS<<",1";

    CSidebar sidebar(pSidebar);
    sidebar.RegisterPanel(
        "[! output PANEL_NAME]",
        "[! output PANEL_NAME] Caption", 
        "[! output PANEL_NAME] Description",
        0,
        panelIcon.str(),
        "Your panel category",
        categoryIcon.str(),
        "",
        "",
        pluginCookie);

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::Unload()
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::CreatePanel(
    IPanel** panel,
    BSTR panelClass)
{
    if (!wcscmp(panelClass,L"[! output PANEL_NAME]"))
    {
        CComObject<[! output CPANEL_NAME]>* pPanel;
        if (SUCCEEDED(CComObject<[! output CPANEL_NAME]>::CreateInstance(&pPanel)))
        {
            return pPanel->QueryInterface(IID_IPanel,(void**)panel);
        }
    }
    return E_FAIL;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) HRESULT STDAPICALLTYPE PluginEntryPoint(IPlugin** plugin)
{
    CComObject<CPlugin>* pPlugin;
    if (SUCCEEDED(CComObject<CPlugin>::CreateInstance(&pPlugin)))
    {
        return pPlugin->QueryInterface(IID_IPlugin,(void**)plugin);
    }
    else
    {
        return E_FAIL;
    }
}

class C[! output PROJECT_NAME]Module : public CAtlDllModuleT< C[! output PROJECT_NAME]Module > {
public :

};

C[! output PROJECT_NAME]Module _Module;

// DLL Entry Point
extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
    hInstance;
    return _Module.DllMain(dwReason, lpReserved); 
}


// Used to determine whether the DLL can be unloaded by OLE
STDAPI DllCanUnloadNow(void)
{
    return _Module.DllCanUnloadNow();
}


// Returns a class factory to create an object of the requested type
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.DllGetClassObject(rclsid, riid, ppv);
}


// DllRegisterServer - Adds entries to the system registry
STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.DllRegisterServer();
}


// DllUnregisterServer - Removes entries from the system registry
STDAPI DllUnregisterServer(void)
{
    return _Module.DllUnregisterServer();
}
