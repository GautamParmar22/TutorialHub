    #include "stdafx.h"
#include "[! output PANEL_NAME].h"
#include "resource.h"

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
[! output CPANEL_NAME]::[! output CPANEL_NAME]()
[!if GENERATE_CONTEXTMENU]
:CCommandTargetImpl<[! output CPANEL_NAME]>(this)
[!endif]
{
[!if GENERATE_CONTEXTMENU]
    addCommand("[!output PANEL_NAME].samplecommand",OnCmdSample);
[!endif]
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
[! output CPANEL_NAME]::~[! output CPANEL_NAME]()
{
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::Create(
    int parentWnd, 
    ISidebar* sidebar,
    IPanelParent* parent,
	IPanelConfig* config,
    ICanvas* canvas,
    IXmlNode* configRoot,
    IXmlNode* panelConfig,
    IXmlNode* settingsRoot,
    IXmlNode* panelSettings,
    int cookie)
{
    m_sidebar=CSidebar(sidebar);
    m_panelParent=CPanelParent(parent);
    m_panelConfig=CPanelConfig(config);
    m_panelCookie=cookie;

    m_panelParent.SetCaption(cookie,"[! output PANEL_NAME]");

    [!if APPTYPE_TEXTOUTPUT]

    m_output=m_sidebar.GetControlFactory().CreateTextOutput();
    m_output.Init(m_sidebar.GetGlobalSettings(),m_sidebar.GetSkinManager(),this,true);
    m_output.Create((HWND)parentWnd,true);
    
    m_output.SetText("This is [! output PANEL_NAME]");
    [!endif]


    [!if APPTYPE_LISTOUTPUT]

    m_output=m_sidebar.GetControlFactory().CreateListOutput();
    m_output.Init(m_sidebar.GetGlobalSettings(),m_sidebar.GetSkinManager(),this,true);
    m_output.Create((HWND)parentWnd,true);
    
    CListRow fr=m_output.AddRow();
    fr.SetText("This is first row");
    CListRow sr=m_output.AddRow();
    sr.SetText("This is second row");
    CListRow tr=m_output.AddRow();
    tr.SetText("This is third row");
    [!endif]

    [!if APPTYPE_CUSTOM]
    CWindowImpl<[! output CPANEL_NAME]>::Create( (HWND)parentWnd, CWindow::rcDefault, _T("[! output PANEL_NAME]"), WS_CHILD|WS_VISIBLE );
    [!endif]

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::Close()
{
    [!if APPTYPE_TEXTOUTPUT]
    m_output.Close();
    m_output.Release();
    [!endif]

    [!if APPTYPE_LISTOUTPUT]
    m_output.Close();
    m_output.Release();
    [!endif]

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::GetFitHeight(int width, int* height)
{
    [!if APPTYPE_TEXTOUTPUT]
    *height=m_output.GetFitHeight();
    [!endif]

    [!if APPTYPE_LISTOUTPUT]
    *height=m_output.GetFitHeight(width);
    [!endif]

    [!if APPTYPE_CUSTOM]
    *height=100;
    [!endif]

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::GetHwnd(HWND* hwnd)
{
    [!if APPTYPE_TEXTOUTPUT]
    *hwnd=m_output.GetHwnd();
    [!endif]
    
    [!if APPTYPE_LISTOUTPUT]
    *hwnd=m_output.GetHwnd();
    [!endif]

    [!if APPTYPE_CUSTOM]
    *hwnd=m_hWnd;
    [!endif]

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::Tick(VARIANT_BOOL m, VARIANT_BOOL* heightChanged)
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::Save(IXmlBuilder* config, IXmlBuilder* globals)
{
    return S_OK;
}

[!if APPTYPE_TEXTOUTPUT]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnDrawBackground(CTextOutput& output, CGraphics graphics)
{
    m_panelParent.DrawControlBackground(graphics,m_panelCookie,output.GetHwnd());
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnClick(CTextOutput& output, bool /*dbclk*/)
{
    ::MessageBox(output.GetHwnd(),"Hello!!!",0,0);
}

[!if GENERATE_DETAILS]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnShowDetails(CTextOutput& output)
{
    if (CTextDetailsWnd details = m_sidebar.GetControlFactory().CreateTextDetailsWnd("[! output PANEL_NAME]"))
    {
        details.Init(m_sidebar.GetGlobalSettings(),m_sidebar.GetSkinManager(),m_panelConfig, this, "Example");
        details.Create(output.GetHwnd());
        details.Set("Sample text");
        output.TakeoverDetails(details);
    }
}
[!endif]

[!endif]

[!if APPTYPE_LISTOUTPUT]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnDrawBackground(CListOutput& list, CGraphics graphics)
{
    m_panelParent.DrawControlBackground(graphics,m_panelCookie,list.GetHwnd());
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnClick(CListOutput& list, CListRow* row, bool dbclk)
{
    ::MessageBox(list.GetHwnd(),"Hello!!!",0,0);
}

[!if GENERATE_DETAILS]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnShowDetails(CListOutput& list, CListRow* row)
{
    if (CTextDetailsWnd details = m_sidebar.GetControlFactory().CreateTextDetailsWnd("[! output PANEL_NAME]"))
    {
        details.Init(m_sidebar.GetGlobalSettings(),m_sidebar.GetSkinManager(),m_panelConfig, this, "Example");
        details.Create(list.GetHwnd());
        details.Set("Sample text");
        list.TakeoverDetails(details, *row);
    }
}
[!endif]

[!endif]

[!if APPTYPE_CUSTOM]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT [! output CPANEL_NAME]::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    PAINTSTRUCT ps;
    BeginPaint(&ps);
    OnPaintImpl(ps.hdc);
    EndPaint(&ps);
    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT [! output CPANEL_NAME]::OnPrintClient(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    OnPaintImpl((HDC)wParam);
    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnPaintImpl(HDC hdc)
{
    RECT rc;
    GetClientRect(&rc);

    // You can use skin engine to draw content
    CGraphics skinGraphics(m_sidebar.CreateGraphics(hdc));
    CSkinManager skinManager=m_sidebar.GetSkinManager();
    CSkinElement skin=skinManager.Get(sePanel, Normal);
    skin.DrawRect(skinGraphics,rc,m_panelParent,m_panelCookie);
    skinGraphics.Release();

    // or GDI+ 
    Graphics gdiGraphics(hdc);
    Pen pen(Color(255,0,0),3);
    gdiGraphics.DrawLine(&pen,Point(0,0),Point(rc.right,rc.bottom));
    gdiGraphics.DrawLine(&pen,Point(0,rc.bottom),Point(rc.right,0));
}
[!endif]


[!if GENERATE_PROPERTIES]

namespace {

class CPanelProp : public CDialogImpl<CPanelProp> { 
public:


    BEGIN_MSG_MAP(CPanelProp)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
    END_MSG_MAP()
    

    /*-----------------------------------------------------------------------------
    -----------------------------------------------------------------------------*/
    BOOL OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& handled)
    {
        return TRUE;
    }
    

};

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
UINT CALLBACK PropPageCallback(HWND hWnd, UINT uMsg, LPPROPSHEETPAGE ppsp)
{
    ATLASSERT(hWnd == NULL);
    if(uMsg == PSPCB_CREATE)
    {
        CDialogImplBase* pPage = (CDialogImplBase*)ppsp->lParam;
        AtlWinModuleAddCreateWndData(&_AtlWinModule,&pPage->m_thunk.cd, pPage);
    } 
    return 1;
}

}

STDMETHODIMP [! output CPANEL_NAME]::ShowProperties(int hwnd)
{
    PROPSHEETPAGE psp[1];
    PROPSHEETHEADER psh;

    CPanelProp page;

    psp[0].dwSize       = sizeof(PROPSHEETPAGE);
    psp[0].dwFlags      = PSP_USETITLE|PSP_USECALLBACK;
    psp[0].pszTitle     = "General";
    psp[0].hInstance    = _AtlBaseModule.GetResourceInstance();
    psp[0].lParam       = (LPARAM)&page;
    psp[0].pfnDlgProc   = (DLGPROC)CPanelProp::StartDialogProc;
    psp[0].pfnCallback  = PropPageCallback;
    psp[0].pszTemplate  = MAKEINTRESOURCE(IDD_PANELPROP);
    
    std::string caption("[! output CPANEL_NAME] Properties");
    
    psh.dwSize      = sizeof(PROPSHEETHEADER);
    psh.dwFlags     = PSH_PROPSHEETPAGE | PSH_NOAPPLYNOW;
    psh.hwndParent  = (HWND)hwnd;
    psh.pszCaption  = caption.c_str();
    psh.nPages      = sizeof(psp) / sizeof(PROPSHEETPAGE);
    psh.nStartPage  = 0;
    psh.ppsp        = psp;

    PropertySheet(&psh);

    return S_OK;
}
[!endif]

[!if GENERATE_CONTEXTMENU]
/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP [! output CPANEL_NAME]::GetContextMenu(POINT pt, HMENU* menu)
{
    HMENU hMenu=CreatePopupMenu();
    m_sidebar.GetCommandManager().AppendMenu(hMenu,"[!output PANEL_NAME]_menu");
    *menu=hMenu;
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void [! output CPANEL_NAME]::OnCmdSample()
{
    ::MessageBox(NULL,"Sample command",0,0);
}
[!endif]

