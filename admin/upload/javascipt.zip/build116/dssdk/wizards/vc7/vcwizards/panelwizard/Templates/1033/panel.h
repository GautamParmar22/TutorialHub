#ifndef INC_[! output UCPANEL_NAME]_H
#define INC_[! output UCPANEL_NAME]_H
#pragma once

class [! output CPANEL_NAME] : 
    public CComObjectRootEx<CComSingleThreadModel>,
    [!if APPTYPE_TEXTOUTPUT]
    public CTextOutputParent,
    [!endif]
    [!if APPTYPE_LISTOUTPUT]
    public CListOutputParent,
    [!endif]
    [!if GENERATE_DETAILS]
    public CDetailsWndParent,
    [!endif]
    [!if APPTYPE_CUSTOM]
    public CWindowImpl<[! output CPANEL_NAME]>,
    [!endif]
    [!if GENERATE_PROPERTIES]
    public IDispatchImpl<IPanelProperties, &IID_IPanelProperties, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    [!endif]
    [!if GENERATE_CONTEXTMENU]
    public IDispatchImpl<IPanelContextMenu, &IID_IPanelContextMenu, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public CCommandTargetImpl<[! output CPANEL_NAME]>,
    [!endif]
    public IDispatchImpl<IPanel, &IID_IPanel, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelWindow, &IID_IPanelWindow, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
    
    [!if APPTYPE_CUSTOM]
    BEGIN_MSG_MAP([! output CPANEL_NAME])
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        MESSAGE_HANDLER(WM_PRINTCLIENT, OnPrintClient)
    END_MSG_MAP()
    [!endif]


    BEGIN_COM_MAP([! output CPANEL_NAME])
        COM_INTERFACE_ENTRY(IPanel)
        COM_INTERFACE_ENTRY(IPanelWindow)
    [!if GENERATE_PROPERTIES]
        COM_INTERFACE_ENTRY(IPanelProperties)
    [!endif]
    [!if GENERATE_CONTEXTMENU]
        COM_INTERFACE_ENTRY(IPanelContextMenu)
        COM_INTERFACE_ENTRY(ICommandTarget)
    [!endif]
    [!if APPTYPE_TEXTOUTPUT]
        COM_INTERFACE_ENTRY(ITextOutputParent)
    [!endif]
    [!if APPTYPE_LISTOUTPUT]
        COM_INTERFACE_ENTRY(IListOutputParent)
    [!endif]
    [!if GENERATE_DETAILS]
        COM_INTERFACE_ENTRY(IDetailsWndParent)
    [!endif]
    END_COM_MAP()

    [! output CPANEL_NAME]();
    ~[! output CPANEL_NAME]();

    // Implementation of IPanel
    STDMETHOD(Create)(
        int hwndParent,
        ISidebar* sidebar,
        IPanelParent* parent,
	    IPanelConfig* config,
        ICanvas* canvas,
        IXmlNode* configRoot,
        IXmlNode* panelConfig,
        IXmlNode* settingsRoot,
        IXmlNode* panelSettings,
        int cookie);
    STDMETHOD(Close)();
    
    STDMETHOD(Tick)(VARIANT_BOOL m, VARIANT_BOOL* heightChanged);
    
    STDMETHOD(Save)(IXmlBuilder* settings, IXmlBuilder* globals);

    // IPanelWindow
    STDMETHOD(GetHwnd)(HWND* hwnd);
    STDMETHOD(GetFitHeight)(int width, int* height);

    [!if GENERATE_PROPERTIES]
    // IPanelProperties
    STDMETHOD(ShowProperties)(int hwnd);
    [!endif]

    [!if GENERATE_CONTEXTMENU]
    // IPanelContextMenu
    STDMETHOD(GetContextMenu)(POINT pt, HMENU* menu);
    [!endif]

    [!if APPTYPE_TEXTOUTPUT]
    // Implementation of ITextOutputParent
    virtual void OnDrawBackground(CTextOutput& output, CGraphics graphics);
    virtual void OnClick(CTextOutput& output, bool /*dbclk*/);
    [!if GENERATE_DETAILS]
	virtual void OnShowDetails(CTextOutput& output);
    [!endif]
    [!endif]

    [!if APPTYPE_LISTOUTPUT]
    // Implementation of IGridOutputParent
    virtual void OnDrawBackground(CListOutput& output, CGraphics graphics);
    virtual void OnClick(CListOutput& output, CListRow* row, bool dbclk);
    [!if GENERATE_DETAILS]
	virtual void OnShowDetails(CListOutput& output, CListRow* row);
    [!endif]
    [!endif]

    [!if APPTYPE_CUSTOM]
    LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnPrintClient(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    void OnPaintImpl(HDC hdc);
    [!endif]

    [!if GENERATE_CONTEXTMENU]
    // Command Handler
    void OnCmdSample();
    [!endif]

private:

    CSidebar m_sidebar;
    CPanelParent m_panelParent;
    CPanelConfig m_panelConfig;
    int m_panelCookie;

    [!if APPTYPE_TEXTOUTPUT]
    CTextOutput m_output;
    [!endif]

    [!if APPTYPE_LISTOUTPUT]
    CListOutput m_output;
    [!endif]

};

#endif //INC_CLOCKPANEL_H
