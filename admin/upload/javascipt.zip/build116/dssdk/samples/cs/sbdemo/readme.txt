Please compile project and then copy following file to 
Desktop Sidebar installation directory:
 - *.dsplugin
 - *.dsskin
 - *.dslang
 - btn1.png
 - btn2.png
After sidebar's restart you should be able to add your panel from �Add New Panel� dialog