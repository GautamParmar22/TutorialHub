using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using DesktopSidebar;


namespace sbdemo
{
    public class Plugin : IPlugin, IPanelCreator
    {
        public Plugin()
        {
        }
    
        public void Unload()
        {
        }

        public void OnPluginLoaded(string plugin)
        {
        }

        public void Load(
            out string author, 
            out string authorEMail, 
            out string description, 
            out string homepage, 
            int sidebarBuild,
            Sidebar Sidebar, 
            IXmlNode pluginConfig, 
            int pluginCookie)
        {
            author = "Your name";
            authorEMail = "your@e-mail.adress.com";
            description = "";
            homepage = "www.yourwebsite.com";
        
            Bitmap bmp= new Bitmap(GetType(),"icon.bmp");
            
            ImageList imageList= new ImageList();
            imageList.Images.Add(bmp,Color.FromArgb(0,255,0));

            Sidebar.RegisterPanel(
                "sbdemo",
                "SkinButton Demo",
                "SkinButton Demo",
                (int)imageList.Handle,
                "0",
                "Your panel category",
                "0",
                "",
                "",
                pluginCookie);
        
            imageList.Dispose();
            bmp.Dispose();
        }
        
        public void CreatePanel(ref IPanel panel, string panelClass)
        {
            if (panelClass=="sbdemo")
            {
                panel=new Panel();
            }
        }
    }
}
