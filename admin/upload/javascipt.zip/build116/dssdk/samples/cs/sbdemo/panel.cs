using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using DesktopSidebar;

namespace sbdemo
{
    /// <summary>
    /// Summary description for panel.
    /// </summary>
    public class Panel : 
        System.Windows.Forms.UserControl,
        IPanel, 
        IPanelWindow,
        IPanelContextMenu,
        ICommandTarget,
        ISkinButtonParent
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        ISidebar m_sidebar;
        IPanelParent m_panelParent;
        IPanelConfig m_panelConfig;
        int m_panelCookie;

        ISkinButton m_button;

        public Panel()
        {

        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            // 
            // Panel
            // 
            this.Name = "Panel";
            this.Resize += new System.EventHandler(this.Panel_Resize);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);

        }
        #endregion

        [DllImport("user32.dll", EntryPoint="SetParent")]
        static extern int SetParent(
            int hwndChild,
            int hwndNewParent);
        

        // IPanel implementation
        public void Create(
            int hwndParent, 
            Sidebar sidebar, 
            IPanelParent parent, 
            IPanelConfig config, 
            ICanvas canvas,
            IXmlNode configRoot,
            IXmlNode panelConfig,
            IXmlNode settingsRoot,
            IXmlNode panelSettings,
            int cookie)
        {
            m_sidebar=sidebar;
            m_panelParent=parent;
            m_panelCookie=cookie;
            m_panelConfig=config;

            m_panelParent.SetCaption(m_panelCookie,"SkinButton Demo");

            SetParent((int)Handle,hwndParent);

            ISkinManager sm=m_sidebar.GetSkinManager();
            m_button=m_sidebar.GetControlFactory().CreateSkinButton();
            m_button.Init(
                sm,
                this,
                sm.Name2Id("sbdemo.btn1"),
                sm.Name2Id("sbdemo.btn2"),
                100);
            m_button.Create((int)Handle,true);

            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        public int GetFitHeight(int width)
        {
            return 100;
        }

        public void Close()
        {
        }


        public bool Tick(bool minute)
        {
            return false;
        }

        public void Save(IXmlBuilder panelSettings, IXmlBuilder settingsRoot)
        {
        }

        public System.IntPtr GetHwnd()
        {
            return Handle;
        }

        private void Panel_Resize(object sender, System.EventArgs e)
        {
            m_button.MoveWindow(0,0,32,32);        
        }
        private void Panel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            IntPtr hdc=e.Graphics.GetHdc();
            IGraphics graphics=m_sidebar.CreateGraphics((int)hdc);
            m_panelParent.DrawPanelBackground(graphics,m_panelCookie);
            e.Graphics.ReleaseHdc(hdc);
        }

        #region ISkinButtonParent Members

        public void OnClick(ISkinButton button, int commandId)
        {
            MessageBox.Show("Hello World!");
        }

        public void OnDrawBackground(ISkinButton button, IGraphics graphics)
        {
            m_panelParent.DrawControlBackground(graphics,m_panelCookie,m_button.GetHwnd());
        }

        #endregion
    
        #region IPanelContextMenu Members

        System.IntPtr DesktopSidebar.IPanelContextMenu.GetContextMenu(tagPOINT pt)
        {
            IControlFactory cf=m_sidebar.GetControlFactory();
            System.IntPtr menu=cf.CreatePopupMenu();
            cf.InsertMenuItem((int)menu,0,"Test Command",101);
            cf.InsertMenuSeparator((int)menu,1);
            return menu;
        }

        #endregion
    
        #region ICommandTarget Members

        public void OnUpdatePrivateCommand(int id, IUpdateUI pAction)
        {
            // TODO:  Add Panel.OnUpdatePrivateCommand implementation
        }

        public void OnCommand(string cmdName)
        {
            // TODO:  Add Panel.OnCommand implementation
        }

        public void OnUpdateCommand(string cmdName, IUpdateUI pAction)
        {
            // TODO:  Add Panel.OnUpdateCommand implementation
        }

        public void OnPrivateCommand(int id)
        {
            if (id==101)
            {
                MessageBox.Show("Hello World!");
            }
        }

        public int GetPrivateCommandImage(int id)
        {
            // TODO:  Add Panel.GetPrivateCommandImage implementation
            return -1;
        }

        #endregion
    }
}
