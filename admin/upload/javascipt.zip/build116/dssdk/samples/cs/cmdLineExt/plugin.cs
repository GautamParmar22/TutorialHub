using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using DesktopSidebar;


namespace cmdLineExt
{
    public class Plugin : IPlugin, ICmdLineExtCreator
    {
        public Plugin()
        {
        }
    
        public void Unload()
        {
        }

        public void OnPluginLoaded(string plugin)
        {
        }

        public void Load(
            out string author, 
            out string authorEMail, 
            out string description, 
            out string homepage, 
            int sidebarBuild,
            Sidebar Sidebar, 
            IXmlNode pluginConfig, 
            int pluginCookie)
        {
            author = "Your name";
            authorEMail = "your@e-mail.adress.com";
            description = "";
            homepage = "www.yourwebsite.com";
        
            Sidebar.RegisterCmdLineExtension(
				"wikipedia",
				"w",
				"Wikipedia",
				"Reference/Wikipedia",
				"Wikipedia",
				pluginConfig.GetNode("forms"),
                pluginCookie);
        
        }
        
    
	
		public ICmdLineExtension CreateExtension(string identifier)
		{
			if (identifier=="wikipedia")
			{
				return new extWikipedia();
			}
			else
			{
				return null;
			}
		}
	}
}
