using System;
using DesktopSidebar;

namespace cmdLineExt
{
	/// <summary>
	/// Summary description for extWikipedia.
	/// </summary>
	public class extWikipedia : DesktopSidebar.ICmdLineExtension
	{
		public extWikipedia()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		#region ICmdLineExtension Members

		public bool Match(string cmdLine)
		{
			// TODO:  Add extWikipedia.Match implementation
			return false;
		}

		public void Execute(ICmdLinePanel panel, string cmdLine)
		{
			DesktopSidebar.IForm form=panel.GetForm("searchform");
			form.GetField("search").value=cmdLine;
			panel.SendForm(form);
		}

		public void Init(Sidebar Sidebar, IXmlNode extSettings)
		{
			// TODO:  Add extWikipedia.Init implementation
		}

		public void Close()
		{
			// TODO:  Add extWikipedia.Close implementation
		}

		public void Suggest(ICmdLineSuggestion Fill, string prefix, string cmdLine)
		{
			// TODO:  Add extWikipedia.Suggest implementation
		}

		public void Save(IXmlBuilder extItem)
		{
			// TODO:  Add extWikipedia.Save implementation
		}

		#endregion
	}
}
