Please compile project and then copy �dsplugin� file to 
Desktop Sidebar installation directory. After sidebar's restart 
you should be able to add your panel from �Add New Panel� dialog