using System;

namespace DesktopSidebar
{
	/// <summary>
	/// Summary description for DialogTranslator.
	/// </summary>
	public class DialogTranslator : IDialogTranslator
	{
        private System.Windows.Forms.Control form;

        public DialogTranslator(System.Windows.Forms.Control _form)
		{
            form=_form;
		}
	
        public void SetCaption(string caption)
        {
            form.Text=caption;
        }

        public void SetControl(string control, string caption)
        {
            System.Reflection.FieldInfo field=form.GetType().GetField(
                control,
                System.Reflection.BindingFlags.Instance|
                System.Reflection.BindingFlags.Public|
                System.Reflection.BindingFlags.NonPublic);
            if (field!=null && field.FieldType.IsSubclassOf(typeof(System.Windows.Forms.Control)))
            {
                System.Windows.Forms.Control obj=(System.Windows.Forms.Control)field.GetValue(form);
                obj.Text=caption;
            }
        }
    }
}
