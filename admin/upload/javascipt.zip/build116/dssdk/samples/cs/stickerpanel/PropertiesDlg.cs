using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using DesktopSidebar;


namespace stickerpanel
{
	/// <summary>
	/// Summary description for NoteDlg.
	/// </summary>
	public class CPropertiesDlg : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ppGeneral;
        private System.Windows.Forms.CheckBox chkbShowOutputPanal;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CPropertiesDlg(ISidebar sidebar)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            
            sidebar.GetTranslator().TranslateDialog2(new DialogTranslator(this),"Stickerpanel.Properties");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

        public bool GetShowNotesCounter()
        {
            return chkbShowOutputPanal.Checked;
        }

        public void SetShowNotesCounter(bool bShowNotesCounter)
        {
            chkbShowOutputPanal.Checked = bShowNotesCounter;
        }

        #region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ppGeneral = new System.Windows.Forms.TabPage();
            this.chkbShowOutputPanal = new System.Windows.Forms.CheckBox();
            this.tabControl1.SuspendLayout();
            this.ppGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnOK.Location = new System.Drawing.Point(200, 296);
            this.btnOK.Name = "btnOK";
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCancel.Location = new System.Drawing.Point(284, 296);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ppGeneral);
            this.tabControl1.Location = new System.Drawing.Point(8, 8);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(352, 280);
            this.tabControl1.TabIndex = 4;
            // 
            // ppGeneral
            // 
            this.ppGeneral.Controls.Add(this.chkbShowOutputPanal);
            this.ppGeneral.Location = new System.Drawing.Point(4, 22);
            this.ppGeneral.Name = "ppGeneral";
            this.ppGeneral.Size = new System.Drawing.Size(344, 254);
            this.ppGeneral.TabIndex = 0;
            this.ppGeneral.Text = "General";
            // 
            // chkbShowOutputPanal
            // 
            this.chkbShowOutputPanal.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkbShowOutputPanal.Location = new System.Drawing.Point(8, 8);
            this.chkbShowOutputPanal.Name = "chkbShowOutputPanal";
            this.chkbShowOutputPanal.Size = new System.Drawing.Size(328, 24);
            this.chkbShowOutputPanal.TabIndex = 0;
            this.chkbShowOutputPanal.Text = "Show notes counter";
            // 
            // CPropertiesDlg
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(370, 328);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CPropertiesDlg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stickerpanel";
            this.tabControl1.ResumeLayout(false);
            this.ppGeneral.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

	}
}
