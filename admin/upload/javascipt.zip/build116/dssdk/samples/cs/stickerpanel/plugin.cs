using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using DesktopSidebar;

namespace stickerpanel
{
	public class Plugin : IPlugin, IPanelCreator
	{
		public Plugin()
		{
		}
	
        public void Unload()
        {
        }

        public void OnPluginLoaded(string plugin)
        {
        }

        public void Load(
            out string author, 
            out string authorEMail, 
            out string description, 
            out string homepage, 
            int sidebarBuild,
            Sidebar Sidebar, 
            IXmlNode pluginConfig, 
            int pluginCookie)
        {
            author = "Damian";
            authorEMail = "damian@desktopsidebar.com";
            description = "";
            homepage = "http://www.desktopsidebar.com";
        
            Bitmap bmp= new Bitmap(GetType(),"icon.bmp");
            
            ImageList imageList= new ImageList();
            imageList.Images.Add(bmp,Color.FromArgb(0,255,0));

            Sidebar.RegisterPanel(
                "stickerpanel",
                "Sticker Panel",
                "This panel allows you to store notes",
                (int)imageList.Handle,
                "0",
                "Samples",
                "0",
                "",
                "",
                pluginCookie);

            bmp.Dispose();
            imageList.Dispose();
        }
        
        public void CreatePanel(ref IPanel panel, string panelClass)
        {
            if (panelClass=="stickerpanel")
            {
                panel=new Panel();
            }
        }
    }
}
