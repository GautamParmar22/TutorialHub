using System;
using System.Windows.Forms;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Runtime.InteropServices;
using DesktopSidebar;

namespace stickerpanel
{
    public class Panel : 
        System.Windows.Forms.UserControl,
        IPanel, 
        IPanelWindow, 
        IPanelProperties,
        DesktopSidebar.ITextOutputParent,
        IListOutputParent,
        IDetailsWndParent
    {
        private System.ComponentModel.Container components = null;
        private System.Windows.Forms.Button btnAdd;
        
        bool m_bShowNotesCounter = true;
        ISidebar m_sidebar;
        IPanelParent m_panelParent;
        IPanelConfig m_panelConfig;
        int m_panelCookie;

        ITextOutput m_notesCounter;
        IListOutput m_notes;
        

        public Panel()
        {
            
        }
	
        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }


        #region Component Designer generated code
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAdd.Location = new System.Drawing.Point(0, 16);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add...";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Panel
            // 
            this.Controls.Add(this.btnAdd);
            this.Name = "Panel";
            this.Resize += new System.EventHandler(this.Panel_Resize);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
            this.ResumeLayout(false);

        }
        #endregion
	

        [DllImport("user32.dll", EntryPoint="SetParent")]
        static extern int SetParent(
            int hwndChild,
            int hwndNewParent);
        

        // IPanel implementation
        public void Create(
            int hwndParent, 
            Sidebar sidebar, 
            IPanelParent parent, 
            IPanelConfig config, 
            ICanvas canvas,
            IXmlNode configRoot,
            IXmlNode panelConfig,
            IXmlNode settingsRoot,
            IXmlNode panelSettings,
            int cookie)
        {
            m_sidebar=sidebar;
            m_panelParent=parent;
            m_panelCookie=cookie;
            m_panelConfig=config;

            m_panelParent.SetCaption(m_panelCookie,"Sticker Panel");

            SetParent((int)Handle,hwndParent);

            m_notesCounter=sidebar.GetControlFactory().CreateTextOutput();
            m_notesCounter.Init(sidebar.GetGlobalSettings(),sidebar.GetSkinManager(),this,true);
            m_notesCounter.Create((int)Handle,true);

            m_notes = sidebar.GetControlFactory().CreateListOutput();
            m_notes.Init(sidebar.GetGlobalSettings(),sidebar.GetSkinManager(),this,true);
            m_notes.Create((int)Handle,true);

            InitializeNotes(panelSettings);
           
            sidebar.GetTranslator().TranslateDialog2(new DialogTranslator(this),"Stickerpanel.Panel");

            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();
        }

        private void AddNote(string sNote)
        {
            DesktopSidebar.IListRow newRow = m_notes.AddRow();
            newRow.SetText(sNote);
        }
        
        private void UpdateNoteCounter()
        {
            string cnt = String.Format("Notes ({0})", m_notes.size()); 
            m_notesCounter.SetText(cnt);        
        }
        
        private void InitializeNotes(IXmlNode root)
        {
            if (root != null)
            {
               IXmlNode noteRoot = root.GetNode("notes/");
            
                for(int i=0; i<noteRoot.GetChildCount(); i++)
                {
                    IXmlNode  note = noteRoot.GetChild(i);
                    AddNote(note.GetAttribute("text"));
                }
               
                IXmlNode showCounter = root.GetNode("showcounter/");               
                m_bShowNotesCounter = (showCounter.GetAttribute("value") == "yes");
               
                UpdateNoteCounter();
            }
        }
        
        public int GetFitHeight(int width)
        {
            return 100;
        }

        public void Close()
        {
            m_notesCounter.Close();
            m_notes.Close();
            m_notesCounter=null;
            m_notes = null;
        }


        public bool Tick(bool minute)
        {
            return false;
        }

        public void Save(IXmlBuilder panelSettings, IXmlBuilder settingsRoot)
        {
            IXmlBuilder noteRoot = panelSettings.AddChild("notes");
            for(int i=0; i<m_notes.size(); i++)
            {
                IXmlBuilder note = noteRoot.AddChild("note");
                note.AddAttribute("text", m_notes.GetRow(i).GetText());                       
            }

            IXmlBuilder showCounter = panelSettings.AddChild("showcounter");
            showCounter.AddAttribute("value", m_bShowNotesCounter ? "yes" : "no");
        }

        public System.IntPtr GetHwnd()
        {
            return Handle;
        }
        
        // ITextOutputParent implementation
        public void OnClick(ITextOutput textOutput, bool dblclk)
        {
            MessageBox.Show("Hello!!!");
        }

        public void OnDrawBackground(ITextOutput textOutput, IGraphics graphics)
        {
            m_panelParent.DrawControlBackground(graphics,m_panelCookie,textOutput.GetHwnd());
        }

        public void OnMouseLeave(ITextOutput textOutput)
        {
        }

        public void OnShowDetails(ITextOutput textOutput)
        {
        }

        public void OnMouseHover(ITextOutput textOutput)
        {
        }


        private void ArrangeChildren()
        {
            int counterHeight=0;

            SuspendLayout();

            if (m_bShowNotesCounter)
            {
                counterHeight=m_notesCounter.GetFitHeight();            
            }
            
            m_notesCounter.MoveWindow(0,0,this.Size.Width,counterHeight);
            btnAdd.Location =new System.Drawing.Point(0, counterHeight);
            int iNotesHeight = this.Size.Height - btnAdd.Location.Y - btnAdd.Size.Height;
            m_notes.MoveWindow(0,btnAdd.Location.Y + btnAdd.Size.Height,this.Size.Width, iNotesHeight);
            ResumeLayout(false);
        }
        private void Panel_Resize(object sender, System.EventArgs e)
        {
            ArrangeChildren();
        }

        private void Panel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            IntPtr hdc=e.Graphics.GetHdc();
            IGraphics graphics=m_sidebar.CreateGraphics((int)hdc);
            m_panelParent.DrawPanelBackground(graphics,m_panelCookie);
            e.Graphics.ReleaseHdc(hdc);
        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            m_sidebar.GetControlFactory().HideAllDetails();

            CNoteDlg dlgNote = new CNoteDlg(m_sidebar);
            if (dlgNote.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                AddNote(dlgNote.GetNote());
                m_notes.Invalidate();
                m_panelParent.ArrangePanels();
                UpdateNoteCounter();
            }
            

        }


        #region IListOutputParent Members

        void DesktopSidebar.IListOutputParent.OnClick(IListOutput list, IListRow row, bool dbclk)
        {
            m_sidebar.GetControlFactory().HideAllDetails();

            CNoteDlg dlgNote = new CNoteDlg(m_sidebar);
            dlgNote.SetNote(row.GetText());
            if (dlgNote.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                if (dlgNote.GetNote().Length == 0)
                {
                    m_notes.Delete(row);
                }
                else
                {
                    row.SetText(dlgNote.GetNote());
                }
                m_notes.Invalidate();
                m_panelParent.ArrangePanels();
                UpdateNoteCounter();
            }
        }

        public void OnLeave(IListOutput list, IListRow row)
        {
            // TODO:  Add Panel.OnLeave implementation
        }

        public void OnScrolled(IListOutput list)
        {
            // TODO:  Add Panel.OnScrolled implementation
        }

        public void OnHover(IListOutput list, IListRow row)
        {
            // TODO:  Add Panel.OnHover implementation
        }

        void DesktopSidebar.IListOutputParent.OnShowDetails(IListOutput list, IListRow row)
        {
            ITextDetailsWnd details = m_sidebar.GetControlFactory().CreateTextDetailsWnd2("stickerpanel",false,0);
            if (details!=null)
            {
                ((IDetailsWnd)details).Init(m_sidebar.GetGlobalSettings(), m_sidebar.GetSkinManager(), m_panelConfig, this, "Note");

                tagPOINT origin;
                origin.x = 0;
                origin.y = 0;

                tagSIZE size;
                size.cx = 0;
                size.cy = 0;

                ((IDetailsWnd)details).Create((int)Handle, (int)EDetailFlags.DC_IGNOREORIGIN | (int)EDetailFlags.DC_IGNORESIZE, ref origin, ref size);

                details.Set(row.GetText());

                list.TakeoverDetails(details, row);
            }

        }
        void DesktopSidebar.IListOutputParent.OnDrawBackground(IListOutput list , IGraphics graphics)
        {
            m_panelParent.DrawControlBackground(graphics,m_panelCookie,list.GetHwnd());        
        }

        #endregion
    
        #region IPanelProperties Members

        public void ShowProperties(int hwnd)
        {
            CPropertiesDlg propDlg = new CPropertiesDlg(m_sidebar);
            propDlg.SetShowNotesCounter(m_bShowNotesCounter);
            if (propDlg.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                m_bShowNotesCounter = propDlg.GetShowNotesCounter();
                ArrangeChildren();
            }

        }

        #endregion
    
        #region IDetailsWndParent Members

        public void OnCreateDetailsWnd(object details)
        {
            // TODO:  Add Panel.OnCreateDetailsWnd implementation
        }

        public void OnCloseDetailsWnd(object details)
        {
            // TODO:  Add Panel.OnCloseDetailsWnd implementation
        }

        #endregion
    }
}

