Imports System
Imports DesktopSidebar
Imports System.Windows.Forms
Imports System.Collections
Imports System.ComponentModel
Imports System.Drawing
Imports System.Data
Imports System.Runtime.InteropServices

Public Class Panel
    Inherits System.Windows.Forms.UserControl
    Implements IPanel, IPanelWindow, DesktopSidebar.ITextOutputParent, DesktopSidebar.IListOutputParent, DesktopSidebar.IPanelProperties, DesktopSidebar.IDetailsWndParent

    Dim m_bShowNotesCounter As Boolean = True
    Dim m_sidebar As ISidebar
    Dim m_panelParent As IPanelParent
    Dim m_panelConfig As IPanelConfig
    Dim m_panelCookie As Integer

    Dim m_notesCounter As ITextOutput
    Dim m_notes As IListOutput

    Declare Function SetParent Lib "user32.dll" Alias "SetParent" (ByVal hwndChild As Integer, ByVal hwndNewParent As Integer) As Integer


#Region " Windows Form Designer generated code "

    Public Sub New()
        'MyBase.New()

        ''This call is required by the Windows Form Designer.
        'InitializeComponent()

        ''Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnAdd = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnAdd
        '
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnAdd.Location = New System.Drawing.Point(0, 17)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "Add..."
        '
        'Panel
        '
        Me.Controls.Add(Me.btnAdd)
        Me.Name = "Panel"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' IPanel implementation
    Public Sub Create(ByVal hwndParent As Integer, _
        ByVal Sidebar As Sidebar, _
        ByVal parent As IPanelParent, _
        ByVal config As IPanelConfig, _
        ByVal canvas As ICanvas, _
        ByVal configRoot As IXmlNode, _
        ByVal panelConfig As IXmlNode, _
        ByVal settingsRoot As IXmlNode, _
        ByVal panelSettings As IXmlNode, _
        ByVal cookie As Integer) Implements IPanel.Create
        m_sidebar = Sidebar
        m_panelParent = parent
        m_panelCookie = cookie
        m_panelConfig = config

        m_panelParent.SetCaption(m_panelCookie, "Sticker Panel")

        SetParent(Handle.ToInt32, hwndParent)

        m_notesCounter = Sidebar.GetControlFactory().CreateTextOutput()
        m_notesCounter.Init(Sidebar.GetGlobalSettings(), Sidebar.GetSkinManager(), Me, True)
        m_notesCounter.Create(Handle.ToInt32, True)

        m_notes = Sidebar.GetControlFactory().CreateListOutput()
        m_notes.Init(Sidebar.GetGlobalSettings(), Sidebar.GetSkinManager(), Me, True)
        m_notes.Create(Handle.ToInt32, True)

        InitializeNotes(panelSettings)

        ' This call is required by the Windows.Forms Form Designer.
        InitializeComponent()
    End Sub


    Public Sub Save(ByVal panelSettings As IXmlBuilder, ByVal settingsRoot As IXmlBuilder) Implements IPanel.Save
        Dim noteRoot As IXmlBuilder = panelSettings.AddChild("notes")
        Dim i As Integer
        For i = 0 To (m_notes.size()) - 1
            Dim note As IXmlBuilder = noteRoot.AddChild("note")
            note.AddAttribute("text", m_notes.GetRow(i).GetText())
        Next i

        Dim showCounter As IXmlBuilder = panelSettings.AddChild("showcounter")
        showCounter.AddAttribute("value", (IIf(m_bShowNotesCounter = True, "yes", "no")))
    End Sub 'Save


    Public Sub Close() Implements IPanel.Close
        m_notesCounter.Close()
        m_notes.Close()
        m_notesCounter = Nothing
        m_notes = Nothing
    End Sub 'Close


    Public Function Tick(ByVal minute As Boolean) As Boolean Implements IPanel.Tick
        Return False
    End Function

    Public Function GetHwnd() As System.IntPtr Implements IPanelWindow.GetHwnd
        Return Handle
    End Function

    Public Function GetFitHeight(ByVal width As Integer) As Integer Implements IPanelWindow.GetFitHeight
        Return 100
    End Function

    Private Sub AddNote(ByVal sNote As String)
        Dim newRow As DesktopSidebar.IListRow = m_notes.AddRow()
        newRow.SetText(sNote)
    End Sub


    Private Sub UpdateNoteCounter()
        Dim cnt As String = [String].Format("Notes ({0})", m_notes.size())
        m_notesCounter.SetText(cnt)
    End Sub


    Private Sub InitializeNotes(ByVal root As IXmlNode)
        If Not (root Is Nothing) Then
            Dim noteRoot As IXmlNode = root.GetNode("notes/")

            Dim i As Integer
            For i = 0 To (noteRoot.GetChildCount()) - 1
                Dim note As IXmlNode = noteRoot.GetChild(i)
                AddNote(note.GetAttribute("text"))
            Next i

            Dim showCounter As IXmlNode = root.GetNode("showcounter/")
            m_bShowNotesCounter = showCounter.GetAttribute("value") = "yes"

            UpdateNoteCounter()
        End If
    End Sub 'InitializeNotes

    ' ITextOutputParent implementation
    Public Overloads Sub OnClick(ByVal textOutput As ITextOutput, ByVal dblclk As Boolean) Implements ITextOutputParent.OnClick
    End Sub


    Public Sub OnDrawBackground(ByVal textOutput As ITextOutput, ByVal graphics As IGraphics) Implements ITextOutputParent.OnDrawBackground
        m_panelParent.DrawControlBackground(graphics, m_panelCookie, textOutput.GetHwnd())
    End Sub


    Public Overloads Sub OnMouseLeave(ByVal textOutput As ITextOutput) Implements ITextOutputParent.OnMouseLeave
    End Sub


    Public Sub OnShowDetails(ByVal textOutput As ITextOutput) Implements ITextOutputParent.OnShowDetails
    End Sub


    Public Overloads Sub OnMouseHover(ByVal textOutput As ITextOutput) Implements ITextOutputParent.OnMouseHover
    End Sub

    Private Sub ArrangeChildren()
        Dim counterHeight As Integer = 0

        SuspendLayout()

        If m_bShowNotesCounter Then
            counterHeight = m_notesCounter.GetFitHeight()
        End If

        m_notesCounter.MoveWindow(0, 0, Me.Size.Width, counterHeight)
        btnAdd.Location = New System.Drawing.Point(0, counterHeight)
        Dim iNotesHeight As Integer = Me.Size.Height - btnAdd.Location.Y - btnAdd.Size.Height
        m_notes.MoveWindow(0, btnAdd.Location.Y + btnAdd.Size.Height, Me.Size.Width, iNotesHeight)
        ResumeLayout(False)
    End Sub

    Private Sub Panel_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        ArrangeChildren()
    End Sub

    Private Sub Panel_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim hdc As IntPtr = e.Graphics.GetHdc()
        Dim graphics As IGraphics = m_sidebar.CreateGraphics(hdc.ToInt32)
        m_panelParent.DrawPanelBackground(graphics, m_panelCookie)
        e.Graphics.ReleaseHdc(hdc)
    End Sub


    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        m_sidebar.GetControlFactory().HideAllDetails()

        Dim dlgNote As New CNoteDlg
        If dlgNote.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            AddNote(dlgNote.GetNote())
            m_notes.Invalidate()
            m_panelParent.ArrangePanels()
            UpdateNoteCounter()
        End If
    End Sub

#Region "IListOutputParent Members"

    Public Overloads Sub OnClick(ByVal list As IListOutput, ByVal row As IListRow, ByVal dbclk As Boolean) Implements IListOutputParent.OnClick
        m_sidebar.GetControlFactory().HideAllDetails()

        Dim dlgNote As New CNoteDlg
        dlgNote.SetNote(row.GetText())
        If dlgNote.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            If dlgNote.GetNote().Length = 0 Then
                m_notes.Delete(row)
            Else
                row.SetText(dlgNote.GetNote())
            End If
            m_notes.Invalidate()
            m_panelParent.ArrangePanels()
            UpdateNoteCounter()
        End If
    End Sub


    Public Overloads Sub OnLeave(ByVal list As IListOutput, ByVal row As IListRow) Implements IListOutputParent.OnLeave
    End Sub

    Public Overloads Sub OnScrolled(ByVal list As IListOutput) Implements IListOutputParent.OnScrolled
    End Sub

    Public Overloads Sub OnHover(ByVal list As IListOutput, ByVal row As IListRow) Implements IListOutputParent.OnHover
    End Sub

    Public Sub OnShowDetails(ByVal list As IListOutput, ByVal row As IListRow) Implements IListOutputParent.OnShowDetails
        Dim details As ITextDetailsWnd = m_sidebar.GetControlFactory().CreateTextDetailsWnd2("vbstickerpanel", False, 0)
        If (Not IsNothing(details)) Then
            CType(details, IDetailsWnd).Init(m_sidebar.GetGlobalSettings(), m_sidebar.GetSkinManager(), m_panelConfig, Me, "Note")

            Dim origin As tagPOINT
            origin.x = 0
            origin.y = 0

            Dim size As tagSIZE
            size.cx = 0
            size.cy = 0

            CType(details, IDetailsWnd).Create(Handle.ToInt32, CInt(EDetailFlags.DC_IGNOREORIGIN) Or CInt(EDetailFlags.DC_IGNORESIZE), origin, size)

            details.Set(row.GetText())

            list.TakeoverDetails(details, row)
        End If
    End Sub


    Public Sub OnDrawBackground(ByVal list As IListOutput, ByVal graphics As IGraphics) Implements IListOutputParent.OnDrawBackground
        m_panelParent.DrawControlBackground(graphics, m_panelCookie, list.GetHwnd())
    End Sub
#End Region

#Region "IPanelProperties Members"

    Public Sub ShowProperties(ByVal hwnd As Integer) Implements IPanelProperties.ShowProperties
        Dim propDlg As New PropertiesDlg
        propDlg.SetShowNotesCounter(m_bShowNotesCounter)
        If propDlg.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK Then
            m_bShowNotesCounter = propDlg.GetShowNotesCounter()
            ArrangeChildren()
        End If
    End Sub
#End Region

#Region "IDetailsWndParent Members"

    Public Sub OnCreateDetailsWnd(ByVal details As Object) Implements IDetailsWndParent.OnCreateDetailsWnd
    End Sub

    Public Sub OnCloseDetailsWnd(ByVal details As Object) Implements IDetailsWndParent.OnCloseDetailsWnd
    End Sub
#End Region

End Class
