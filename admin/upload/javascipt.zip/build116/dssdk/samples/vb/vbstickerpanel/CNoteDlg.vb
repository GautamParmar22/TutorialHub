Public Class CNoteDlg
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents m_btnCancel As System.Windows.Forms.Button
    Friend WithEvents m_btnOK As System.Windows.Forms.Button
    Friend WithEvents m_txtNote As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.m_btnCancel = New System.Windows.Forms.Button
        Me.m_btnOK = New System.Windows.Forms.Button
        Me.m_txtNote = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'm_btnCancel
        '
        Me.m_btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.m_btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.m_btnCancel.Location = New System.Drawing.Point(272, 200)
        Me.m_btnCancel.Name = "m_btnCancel"
        Me.m_btnCancel.Size = New System.Drawing.Size(90, 27)
        Me.m_btnCancel.TabIndex = 5
        Me.m_btnCancel.Text = "Cancel"
        '
        'm_btnOK
        '
        Me.m_btnOK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.m_btnOK.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.m_btnOK.Location = New System.Drawing.Point(168, 200)
        Me.m_btnOK.Name = "m_btnOK"
        Me.m_btnOK.Size = New System.Drawing.Size(90, 27)
        Me.m_btnOK.TabIndex = 4
        Me.m_btnOK.Text = "OK"
        '
        'm_txtNote
        '
        Me.m_txtNote.Location = New System.Drawing.Point(8, 8)
        Me.m_txtNote.Multiline = True
        Me.m_txtNote.Name = "m_txtNote"
        Me.m_txtNote.Size = New System.Drawing.Size(356, 185)
        Me.m_txtNote.TabIndex = 3
        Me.m_txtNote.Text = ""
        Me.m_txtNote.WordWrap = False
        '
        'CNoteDlg
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(374, 237)
        Me.Controls.Add(Me.m_btnCancel)
        Me.Controls.Add(Me.m_btnOK)
        Me.Controls.Add(Me.m_txtNote)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CNoteDlg"
        Me.Text = "Note"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Function GetNote() As String
        Return m_txtNote.Text
    End Function

    Public Sub SetNote(ByVal sNote As String)
        m_txtNote.Text = sNote
    End Sub

End Class
