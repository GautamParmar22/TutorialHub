Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports DesktopSidebar

Public Class Plugin
    Implements IPlugin, IPanelCreator

    Public Sub Plugin()
    End Sub

    Public Sub Unload() Implements IPlugin.Unload

    End Sub

    Public Sub OnPluginLoaded(ByVal plugin As String) Implements IPlugin.OnPluginLoaded

    End Sub

    Public Sub Load(ByRef author As String, ByRef authorEMail As String, ByRef description As String, ByRef homepage As String, ByVal sidebarBuild As Integer, ByVal Sidebar As Sidebar, ByVal pluginConfig As IXmlNode, ByVal pluginCookie As Integer) Implements IPlugin.Load
        author = "Damian/Matt"
        authorEMail = "damian@desktopsidebar.com"
        description = ""
        homepage = "http://www.desktopsidebar.com"

        Dim bmp As Bitmap = New Bitmap(Me.GetType(), "icon.bmp")

        Dim imageList As ImageList = New ImageList
        imageList.Images.Add(bmp, Color.FromArgb(0, 255, 0))

        Sidebar.RegisterPanel( _
                "VBStickerPanel", _
                "Sticker Panel", _
                "This panel allows you to store notes", _
                imageList.Handle.ToInt32, _
                "0", _
                "Samples", _
                "0", _
                "", _
                "", _
                pluginCookie)

        imageList.Dispose()
        bmp.Dispose()
    End Sub

    Public Sub CreatePanel(ByRef panel As IPanel, ByVal panelClass As String) Implements IPanelCreator.CreatePanel
        If panelClass = "VBStickerPanel" Then
            panel = New Panel
        End If
    End Sub

End Class