#ifndef INC_RECYCLEBINPANEL_H
#define INC_RECYCLEBINPANEL_H
#pragma once

class CRecycleBinPanel : 
    public CComObjectRootEx<CComSingleThreadModel>,
    public CWindowImpl<CRecycleBinPanel>,
    public IDispatchImpl<IPanel, &IID_IPanel, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelWindow, &IID_IPanelWindow, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelContextMenu, &IID_IPanelContextMenu, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelProperties, &IID_IPanelProperties, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public CCommandTargetImpl<CRecycleBinPanel>,
    public CTextOutputParent
{
public:

    BEGIN_MSG_MAP(CRecycleBinPanel)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        MESSAGE_HANDLER(WM_PRINTCLIENT, OnPrintClient)
        MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkGnd)
        MESSAGE_HANDLER(WM_SIZE, OnSize)
    END_MSG_MAP()

    BEGIN_COM_MAP(CRecycleBinPanel)
        COM_INTERFACE_ENTRY_IID(IID_IPanel,IPanel)
        COM_INTERFACE_ENTRY_IID(IID_IPanelWindow,IPanelWindow)
        COM_INTERFACE_ENTRY_IID(IID_ICommandTarget,ICommandTarget)
        COM_INTERFACE_ENTRY_IID(IID_IPanelContextMenu,IPanelContextMenu)
        COM_INTERFACE_ENTRY_IID(IID_IPanelProperties,IPanelProperties)
        COM_INTERFACE_ENTRY_IID(IID_ITextOutputParent,ITextOutputParent)
    END_COM_MAP()

    CRecycleBinPanel();
    ~CRecycleBinPanel();

    // Implementation of IPanel
    STDMETHOD(Create)(
        int parentWnd, 
        ISidebar* sidebar,
        IPanelParent* parent,
        IPanelConfig* config,
        ICanvas* canvas,
        IXmlNode* configRoot,
        IXmlNode* panelConfig,
        IXmlNode* settingsRoot,
        IXmlNode* panelSettings,
        int cookie);
    STDMETHOD(Close)();

    
    STDMETHOD(Tick)(VARIANT_BOOL m, VARIANT_BOOL* heightChanged);
    
    STDMETHOD(Save)(IXmlBuilder* settings, IXmlBuilder* globals);
    
    // IPanelWindow
    STDMETHOD(GetHwnd)(HWND* hwnd);
    STDMETHOD(GetFitHeight)(int width, int* height);

    // IPanelContextMenu
    STDMETHOD(GetContextMenu)(POINT pt, HMENU* menu);

    // IPanelProperties
    STDMETHOD(ShowProperties)(int hwnd);

    // ITextOutputParent
    virtual void OnDrawBackground(CTextOutput& output, CGraphics graphics);
    virtual void OnClick(CTextOutput& output, bool /*dbclk*/);
    virtual void OnMouseHover(CTextOutput& output);

    // window's messages  
    LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnPrintClient(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnEraseBkGnd(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    void OnPaintImpl(HDC hdc);

    virtual void OnFinalMessage(HWND hWnd);

    // command handler
    void OnCmdOpen();
    void OnCmdEmpty();
    void OnUpdateCmdEmpty(CUpdateUI* pUpdateUI) const;

private:

    CSidebar m_sidebar;
    CPanelParent m_panelParent;
    CPanelConfig m_panelConfig;
    int m_panelCookie;
    bool m_empty;

    CTextOutput m_label;
    
    void update();

    void emptyRecycleBin();
    void openRecycleBin();
};

#endif //INC_CLOCKPANEL_H
