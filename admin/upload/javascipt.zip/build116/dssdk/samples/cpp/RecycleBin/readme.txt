This is Recycle Bin sample.  Please compile this project and then copy:
-	recyclebin.dll
-	recyclebin.dsplugin
-	recyclebin.dsskin
-	recyclebin.dslang
to Desktop Sidebar�s installation directory. 
Then you should be able to add Recycle Bin Panel to Desktop sidebar from �Add New Panel� dialog.
