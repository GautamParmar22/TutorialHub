#include "stdafx.h"
#include "RecycleBinPanel.h"
#include "resource.h"

#include <sstream>
#include <iomanip>
#include <shlobj.h>
#include <windowsx.h>

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
CRecycleBinPanel::CRecycleBinPanel()
:CCommandTargetImpl<CRecycleBinPanel>(this)
{
    addCommand("recyclebin.open",&CRecycleBinPanel::OnCmdOpen);
    addCommand("recyclebin.empty",&CRecycleBinPanel::OnCmdEmpty,&CRecycleBinPanel::OnUpdateCmdEmpty);
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
CRecycleBinPanel::~CRecycleBinPanel()
{
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::Create(
    int parentWnd, 
    ISidebar* sidebar,
    IPanelParent* parent,
    IPanelConfig* config,
    ICanvas* canvas,
    IXmlNode* configRoot,
    IXmlNode* panelConfig,
    IXmlNode* settingsRoot,
    IXmlNode* panelSettings,
    int cookie)
{
    m_sidebar=CSidebar(sidebar);
    m_panelParent=CPanelParent(parent);
    m_panelConfig=CPanelConfig(config);
    m_panelCookie=cookie;

    m_panelParent.SetCaption(cookie,"Recycle Bin");

    CWindowImpl<CRecycleBinPanel>::Create( (HWND)parentWnd, CWindow::rcDefault, _T("RecycleBinPanel"), WS_CHILD );

    m_label=m_sidebar.GetControlFactory().CreateTextOutput();
    m_label.Init(m_sidebar.GetGlobalSettings(),m_sidebar.GetSkinManager(),this,true);
    m_label.Create(m_hWnd,true);
    
    update();
    
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::Close()
{
    m_label.Close();
    m_label.Release();
    
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::GetFitHeight(int width, int* height)
{
    CSkinManager skin=m_sidebar.GetSkinManager();
    CSkinElement element=skin.GetCustom("RecycleBinEmpty");
    SIZE sz=element.GetImageSize();
    int cymargin=element.GetMetrics("cymargin");
    int textheight=m_label.GetFitHeight();

    *height=max(textheight,sz.cy+2*cymargin);
    
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::GetHwnd(HWND* hwnd)
{
    *hwnd=m_hWnd;
    return S_OK;
}

namespace {

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
std::string sizeToHuman(__int64  bytes)
{
    double kb=double(bytes)/1024;
    double mb=kb/1024;
    double gb=mb/1024;

    std::stringstream ss;
    ss<<std::fixed<<std::setprecision(2);
    if (gb>=1)
    {
        ss<<gb<<" GB";
    }
    else if (mb>=1)
    {
        ss<<mb<<" MB";
    }
    else if (kb>=1)
    {
        ss<<kb<<" KB";
    }
    else
    {
        ss<<bytes<<" bytes";
    }
    return ss.str();
}

}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::update()
{
    SHQUERYRBINFO info;
    memset(&info,0,sizeof(info));
    info.cbSize=sizeof(info);
    SHQueryRecycleBin("",&info);

    CMsgBuilder msg(m_sidebar.GetTranslator().msg("recyclebin.1"));
    msg<<info.i64NumItems<<sizeToHuman(info.i64Size);
    m_label.SetText(msg.str());

    bool empty=(info.i64NumItems==0);
    if (empty!=m_empty)
    {
        Invalidate();
    }
    m_empty=empty;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::Tick(VARIANT_BOOL m, VARIANT_BOOL* heightChanged)
{
    if (m==VARIANT_TRUE)
    {
        update();
    }
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::Save(IXmlBuilder* config, IXmlBuilder* globals)
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::GetContextMenu(POINT pt, HMENU* menu)
{
    HMENU hMenu=CreatePopupMenu();
    m_sidebar.GetCommandManager().AppendMenu(hMenu,"RecycleBinPanel_menu");
    *menu=hMenu;
    return S_OK;
}

namespace {

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void Free(LPITEMIDLIST pidl)
{
    CComPtr<IMalloc> pMalloc;
    SHGetMalloc(&pMalloc);
    if (pMalloc)
    {
        pMalloc->Free(pidl);
    }
}

}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CRecycleBinPanel::ShowProperties(int hwnd)
{
    LPITEMIDLIST pidl;
    if (SUCCEEDED(SHGetSpecialFolderLocation(NULL,CSIDL_BITBUCKET,&pidl)))
    {
        SHELLEXECUTEINFO execInfo;
        memset(&execInfo,0,sizeof(execInfo));
        execInfo.cbSize=sizeof(execInfo);
        execInfo.fMask=SEE_MASK_IDLIST|SEE_MASK_INVOKEIDLIST;
        execInfo.hwnd=(HWND)hwnd;
        execInfo.lpVerb="properties";
        execInfo.lpIDList=pidl;
        ShellExecuteEx(&execInfo);
 
        Free(pidl);
    }

    return S_OK;
}

LRESULT CRecycleBinPanel::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    InternalAddRef();
    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnFinalMessage(HWND hWnd)
{
    if (!InternalRelease())
    {
        delete this;
    }
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT CRecycleBinPanel::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    PAINTSTRUCT ps;
    BeginPaint(&ps);
    OnPaintImpl(ps.hdc);
    EndPaint(&ps);
    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT CRecycleBinPanel::OnPrintClient(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    OnPaintImpl((HDC)wParam);
    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT CRecycleBinPanel::OnEraseBkGnd(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    return TRUE;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
LRESULT CRecycleBinPanel::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    if (m_label.m_ptr)
    {
        int cx=LOWORD(lParam);
        int cy=HIWORD(lParam);

        CSkinManager skin=m_sidebar.GetSkinManager();
        CSkinElement element=skin.GetCustom("RecycleBinEmpty");
        SIZE sz=element.GetImageSize();
        int cxmargin=element.GetMetrics("cxmargin");
        int textheight=m_label.GetFitHeight();

        int x=sz.cx+2*cxmargin;
        int y=(cy-textheight)/2;
        ::MoveWindow(m_label.GetHwnd(),x,y,cx-x,textheight,TRUE);
    }

    return 0;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnPaintImpl(HDC hdc)
{
    CGraphics graphics(m_sidebar.CreateGraphics(hdc));

    m_panelParent.DrawBackground(graphics,m_panelCookie);

    RECT rc;
    GetClientRect(&rc);

    CSkinManager skin=m_sidebar.GetSkinManager();
    CSkinElement emptyBin=skin.GetCustom("RecycleBinEmpty");
    CSkinElement fullBin=skin.GetCustom("RecycleBinFull");
    CSkinElement element=m_empty?emptyBin:fullBin;
    
    SIZE sz=emptyBin.GetImageSize();
    rc.left+=emptyBin.GetMetrics("cxmargin");
    rc.top+=emptyBin.GetMetrics("cymargin");
    element.Fill(graphics,rc);
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnCmdEmpty()
{
    emptyRecycleBin();
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnCmdOpen()
{
    openRecycleBin();
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnUpdateCmdEmpty(CUpdateUI* pUpdateUI) const
{
    pUpdateUI->SetEnabled(!m_empty);
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnDrawBackground(CTextOutput& output, CGraphics graphics)
{
    m_panelParent.DrawControlBackground(graphics,m_panelCookie,output.GetHwnd());
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnClick(CTextOutput& output, bool /*dbclk*/)
{
    openRecycleBin();
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::OnMouseHover(CTextOutput& output)
{
    update();
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::emptyRecycleBin()
{
    SHEmptyRecycleBin(NULL,NULL,0);
    update();
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void CRecycleBinPanel::openRecycleBin()
{
    LPITEMIDLIST pidl;
    if (SUCCEEDED(SHGetSpecialFolderLocation(NULL,CSIDL_BITBUCKET,&pidl)))
    {
        SHELLEXECUTEINFO execInfo;
        memset(&execInfo,0,sizeof(execInfo));
        execInfo.cbSize=sizeof(execInfo);
        execInfo.fMask=SEE_MASK_IDLIST;
        execInfo.nShow=SW_SHOWNORMAL;
        execInfo.lpIDList=pidl;
        ShellExecuteEx(&execInfo);
 
        Free(pidl);
    }
}

