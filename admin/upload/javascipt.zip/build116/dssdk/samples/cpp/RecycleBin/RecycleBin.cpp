#include "stdafx.h"
#include "RecycleBinPanel.h"
#include "resource.h"

#include <sstream>


class CPlugin :
    public CComObjectRootEx<CComSingleThreadModel>,
    public IDispatchImpl<IPlugin, &IID_IPlugin, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
    public IDispatchImpl<IPanelCreator, &IID_IPanelCreator, &LIBID_DesktopSidebarLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{

public:

    BEGIN_COM_MAP(CPlugin)
        COM_INTERFACE_ENTRY_IID(IID_IPlugin,IPlugin)
        COM_INTERFACE_ENTRY_IID(IID_IPanelCreator,IPanelCreator)
    END_COM_MAP()

    STDMETHOD(Load)(
        BSTR* author,
        BSTR* authorEMail,
        BSTR* description,
        BSTR* homepage,
        int sidebarBuild,
        ISidebar* sidebar,
        IXmlNode* pluginConfig,
        int pluginCookie);
    STDMETHOD(Unload)();
    STDMETHOD(CreatePanel)(
        IPanel** panel,
        BSTR panelClass);

    STDMETHOD(OnPluginLoaded)(BSTR name);
};

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::OnPluginLoaded(BSTR name)
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::Load(
    BSTR* author,
    BSTR* authorEMail,
    BSTR* description,
    BSTR* homepage,
    int sidebarBuild,
    ISidebar* pSidebar,
    IXmlNode* pPluginConfig,
    int pluginCookie) 
{
    *author=SysAllocString(L"Damian");
    *authorEMail=SysAllocString(L"damian@desktopsidebar.com");
    *description=SysAllocString(L"");
    *homepage=SysAllocString(L"www.desktopsidebar.com");

    char szPath[_MAX_PATH];
    GetModuleFileName(_AtlBaseModule.GetResourceInstance(),szPath,sizeof(szPath));

    std::stringstream panelIcon;
    panelIcon<<szPath<<","<<IDB_ICONS<<",0";

    CSidebar sidebar(pSidebar);
    sidebar.RegisterPanel(
        "RecycleBinPanel",
        "recyclebin", 
        "recyclebin_desc",
        0,
        panelIcon.str(),
        "system_cat",
        ",254,4",
        "",
        "",
        pluginCookie);

    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::Unload()
{
    return S_OK;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
STDMETHODIMP CPlugin::CreatePanel(
    IPanel** panel,
    BSTR panelClass)
{
    if (!wcscmp(panelClass,L"RecycleBinPanel"))
    {
        CComObject<CRecycleBinPanel>* pPanel;
        if (SUCCEEDED(CComObject<CRecycleBinPanel>::CreateInstance(&pPanel)))
        {
            return pPanel->QueryInterface(IID_IPanel,(void**)panel);
        }
    }
    return E_FAIL;
}

/*-----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) HRESULT STDAPICALLTYPE PluginEntryPoint(IPlugin** plugin)
{
	CComObject<CPlugin>* pPlugin;
	if (SUCCEEDED(CComObject<CPlugin>::CreateInstance(&pPlugin)))
	{
		return pPlugin->QueryInterface(IID_IPlugin,(void**)plugin);
	}
	else
	{
		return E_FAIL;
	}
}

class CRecycleBinModule : public CAtlDllModuleT< CRecycleBinModule > {
public :

};

CRecycleBinModule _Module;

// DLL Entry Point
extern "C" BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
    hInstance;
    return _Module.DllMain(dwReason, lpReserved); 
}


// Used to determine whether the DLL can be unloaded by OLE
STDAPI DllCanUnloadNow(void)
{
    return _Module.DllCanUnloadNow();
}


// Returns a class factory to create an object of the requested type
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.DllGetClassObject(rclsid, riid, ppv);
}


// DllRegisterServer - Adds entries to the system registry
STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.DllRegisterServer();
}


// DllUnregisterServer - Removes entries from the system registry
STDAPI DllUnregisterServer(void)
{
    return _Module.DllUnregisterServer();
}
