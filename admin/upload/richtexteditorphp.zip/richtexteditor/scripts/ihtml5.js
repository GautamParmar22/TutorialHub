﻿window._rte_image_cache=new function(){



}
