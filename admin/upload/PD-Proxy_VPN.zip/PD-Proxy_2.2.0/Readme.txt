PD-Proxy - VPN Tunneling Software
Website: http://www.pdproxy.com/
Forum:   http://forum.pdproxy.com/

Instructions:

1. Download and unzip PD-Proxy at http://www.pdproxy.com/download.htm

2. Open PD-Proxy.exe When a message asks you to install a driver press Yes.

3. Press the connect button and wait till it says that you are connected.

4. Enjoy browsing the internet securely...

No additional settings required on you applications (eg: firefox, Yahoo Messenger)

Notes:

1. Make sure the program has administrative privileges when using Vista/7
2. Make sure the TAP-Win32 Driver is enabled.
3. Enable the Show debugs logs setting and upload your logs at http://www.pinoyden.com.ph/index.php?topic=66998.0


For more info visit http://forum.pdproxy.com/
For Premium PD-Proxy Accounts via PayPal signup at https://www.pdproxy.com/signup.htm and Pay your subscription at your control panel
For more information on GCash Payments email me at sales@pdproxy.com with subject "PD-Proxy Inquiry"


Third parties:

1. This product includes software developed by aEDLeng for use by PD-Proxy.

2. The Windows binary distribution includes devcon.exe, a Microsoft DDK sample which is redistributed under the terms of the DDK EULA.

3. The Windows binary distribution includes TAP-Win32/TAP-Win64 Driver. The source and object code of the TAP-Win32/TAP-Win64 driver is copyright (c) 2002-2009 OpenVPN Technologies, Inc., and is released under the GPL version 2 (see gpl.txt or http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt), however due to the extra costs of supporting Windows Vista, OpenVPN Technologies, Inc. reserves the right to change the terms of the TAP-Win32/TAP-Win64 license for versions 9.1 and higher prior to the official release of OpenVPN 2.1.

PS: I love you Anna ;-*